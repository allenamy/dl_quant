# 04 — 完整指标目录（逐条带配置与出处）

> 全部为 OOS、单种子 42（P8 约束：禁 ensemble）。注意尾部的「cross-cutting caveats」：
> 2026-06-01 之前用 per-day 归一化的深模型 raw Pearson 数字带 ~14× 前视泄漏虚高，因果修正后的数字在 1c/1e 表；W1 选择会虚高 ~+0.011。

# Multi-Asset Crypto Project — Exhaustive Headline Metrics Catalog (from memory files, verbatim)

All source files live in `/Users/haosiyu/.claude/projects/-Users-haosiyu-Desktop-multi-asset-crypto/memory/`. "W1–W4" = the four 2025 OOS eval windows (AGG = aggregate); fold7/rl3* OOS = 2025-04-19→2025-05-18. Single seed 42 throughout (P8).

## 1. RAW y_600 per-asset Pearson (market-laden target)

### 1a. Single-asset BTC teacher / reference anchors

| Metric (exact values) | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| Pooled Pearson **0.0664**, Spearman 0.0695, β 1.09, σR 0.061 (ema_best 0.0593, β1.39 worse); fold_1 test q50 Pearson 0.074 | Single-asset teacher `singh_track_reg_arch` fold_{0,1,2} `best_model`, DualPathLOBModelV3 118K params, FiLM-multistage merged config | 991d npz_v4 (2023-01-01→2025-09-30), 700d-style folds | 3-fold pooled test 2025-02→2025-09 (n≈50k) | findings_phase15_btc_fusion_2026-06-03.md |
| **0.0667** = 5-way ENSEMBLE (P8-forbidden); single REG_arch model **0.0646**; σŷ/σy=0.057 ≈ Bayes ceiling | Single-asset production (reference package) | 700d BTC | production val/3-fold pooled, STABLE not window-luck | findings_rawlob3_audit_fixes_2026-06-01.md, findings_norm_lookahead_leak_2026-06-01.md |
| Shipped 5-way CSV scores **P=0.0887** on our exact window (n=9858); standalone REG_arch ~0.085 there; monthly P_live Apr–Jul 2025: 0.072/0.064/0.083/0.075 | Single-asset 5-way ensemble exports/y600_5way_predictions_*.csv | 700d BTC | 2025-04-19→05-18 | findings_rawlob3_audit_fixes_2026-06-01.md |
| Teacher q50-vs-y600 Pearson **+0.0379** on eval window (lower-signal month vs 0.066 pooled); all UTC hours +0.03..+0.08; teacher-unseen evening +0.031 vs seen-morning +0.043 | Frozen fold_1 teacher, full-day generalization check (`btc_hour_generalization.py`) | teacher 991d | 2025-04-19→05-18, 30d, n=14310 | findings_phase15_btc_fusion_2026-06-03.md |
| E93 BTC-only 700d = **0.032** | BTC-only supervised control | 700d | OOS (W-protocol) | findings_multitarget_2026-05-31.md (cited) |

### 1b. Phase 15 BTC-teacher fusion (rl3fuse1, LOBNet3, raw y_600)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| MEAN_ALT(full): base **+0.0319** / q50-ctrl **+0.0475** / multilag **+0.0445**; covMEAN_ALT +0.0282 / +0.0439 / +0.0454; covBTC +0.0172 / +0.0093 / +0.0381; ALT_beta 1.73 / 2.59 / 2.31 | LOBNet3 conv + `use_btc_fusion` (asymmetric cross-attn, h_pred(32)/q50 teacher tokens), `train_rawlob3_fusion.py`, seed42 | 485d | OOS 2025-04-19→05-18 (~41% teacher coverage) | findings_phase15_btc_fusion_2026-06-03.md |
| Per-asset multilag lift (7/9 alts): XRP .026→.056, SOL .041→.058, LINK .025→.050 (ETH/DOT dip) | same (conv multilag = Phase-15 deliverable) | 485d | same | findings_phase15_btc_fusion_2026-06-03.md |
| Future-shift +3600s control: multilag covMEAN_ALT **+0.0307** ≈ base +0.0282 (no leak, causal) | leak control | 485d | same | findings_phase15_btc_fusion_2026-06-03.md |
| Full-coverage preview (cov 0.986): MEAN_ALT(full) **+0.0412** ≤ 41%-cov 0.0445 → coverage NOT bottleneck | existing multilag model + full-day teacher stream | 485d | same | findings_phase15_btc_fusion_2026-06-03.md |
| Phase 15-C transformer: base-tf +0.0329 / multilag-tf **+0.0278** (REGRESSED); covMEAN_ALT +0.0276 / +0.0297; ALT_beta 2.25 / 1.43 | LOBNet3 `--temporal transformer` (2-layer self-attn) | 485d | same | findings_phase15_btc_fusion_2026-06-03.md |
| Phase-15 conclusion: raw y_600 alt-mean INFO-BOUND **~0.045** with fusion; 0.1 unreachable | conv multilag | 485d | same | findings_phase15_btc_fusion_2026-06-03.md |

### 1c. Normalization-leak correction + causal raw numbers (train_cs_ranker_seq.py)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| Per-day `_gz` norm (LOOK-AHEAD leak): rawP10 **+0.1116**; frozen-train causal `--causal_norm`: **+0.0080** (~14× inflation) | deep per-asset d320 L6 + transformer + lobtemporal + per_asset_film, rank_w=0 plain-Huber, MAD-z target, drop_tier4 | fold7 train 20241021→20250418 | OOS 20250419→20250518 | findings_norm_lookahead_leak_2026-06-01.md |
| Causal lever ladder: RevIN rank_w0 170d rawP10 **+0.007** (cs ~0, idio_mag +0.019); RevIN **rank_w0.5** 170d **+0.0312** (cs +0.0465, idio_mag +0.0390); rank_w0 575d +0.0216 (cs +0.0324, idio_mag +0.0338); rank_w0.5+575d **+0.0315** (cs +0.0472, idio_mag **+0.0400**) | same backbone, single-axis | 170d / 575d | fold7 OOS | findings_norm_lookahead_leak_2026-06-01.md |
| 6-axis audit all flat-or-worse vs +0.031: DAQH+5-comp loss +0.005 (HURT −0.026), 575d flat, fine-1s-LOB +0.032, cross-asset attn +0.033, BTC/ETH lead-lag +0.030 | single-axis on joint baseline | fold7 | fold7 OOS | findings_norm_lookahead_leak_2026-06-01.md |
| Calibration (point2 best.pt): SOL β1.05 σP/σA 0.061≈ρ, FIL β1.07, DOT/ETC/XRP/LINK β0.79–0.88; weak TRX 0.13/DOG 0.33/ETH 0.36; bias ~0.01–0.04σ, no σ-collapse | `calib_raw_eval.py` | — | fold7 OOS | findings_norm_lookahead_leak_2026-06-01.md |
| 3-point WF (winner RevIN+rank0.5+Huber+combo-select): rawP10 2024-08 **+0.0338** / 2024-12 **+0.0137** / 2025-04 **+0.0425** (SOL 0.065, FIL 0.064, DOT 0.056, ETC 0.052, BTC 0.048), mean **+0.030**; cs_spear_10 +0.0511/+0.0470/+0.0548 mean +0.051; idio_magP10 +0.0277/+0.0158/+0.0403 mean +0.028 | expanding-window walk-forward | expanding | 3 OOS points | findings_norm_lookahead_leak_2026-06-01.md |
| Converged causal plateau: cs ~0.047, idio per-asset ~0.040, raw per-asset ~0.031; per-asset winners FIL 0.056, ETC 0.051, SOL 0.041, XRP 0.038, BTC 0.036; ETH/DOG/TRX ~0.01 | multiple configs agree | 170–575d | fold7 OOS | findings_norm_lookahead_leak_2026-06-01.md |

### 1d. Snapshot ridge / single-asset feature port (raw y_600)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| Per-asset ridge AGG: PRE-121 (single-asset feats) **0.022** (2024-08 0.008 / 2024-12 0.025 / 2025-04 0.033, BTC **0.070** there) vs OURS-112 **0.044** (0.047 / 0.048 / 0.037, BTC 0.014) — ours beat theirs 2× | `preprocess_vs_ours_ridge.py`, leak-free WF, snapshot ridge | leak-free WF | 3 OOS points | findings_norm_lookahead_leak_2026-06-01.md |
| Snapshot RIDGE (OURS) per-asset: ETC **0.067**, ETH 0.058, XRP 0.056, DOT 0.055, FIL 0.049, SOL 0.047, LINK 0.045, DOG 0.031, BTC 0.022 (idio≈0), TRX 0.008; universe MEAN 0.044 | per-asset snapshot ridge, global-z, NO RevIN/sequence — "snapshot > deep sequence (0.044 > 0.030) bombshell" | leak-free WF | 3-pt WF | findings_norm_lookahead_leak_2026-06-01.md |
| Snapshot model search: ridge meanP10 **0.044** (strong7 0.054, CHAMPION) > gbdt 0.033 (ETH 0.082 but SOL/DOT collapse) >> pooled_mlp **0.005** (σ-COLLAPSED) | `snapshot_models.py` | leak-free 3-pt WF | 3 OOS points | findings_norm_lookahead_leak_2026-06-01.md |

### 1e. RawLOBNet / LOBNet3 raw-magnitude program (rl3*)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| RawLOBNet DAQH base MEAN P **0.0389** vs ridge 0.027 same data (LINK 0.064 / SOL 0.062 / FIL 0.058 / ETC 0.051 / DOT 0.044; BTC 0.017 / ETH 0.014 / TRX 0.012), β 0.46, sign 0.506; +coarse DeepLOB **0.0421** β0.68 gate +0.124; +DCN-V2 0.019 HURT; +sign_w0.4 0.032 HURT; ridge_check 0.0144 (170d) / 0.0271 (575d) | `train_rawlob.py` (DAQH + sign-BCE + mag-focal + rank + per-asset FiLM, no LOB → +LOB) | 575d (leak-free, 20d stable vsel) | single OOS window | findings_redesign_blueprint_2026-06-01.md |
| rl3abl2 micro-dynamics ablation MEAN_P: base 0.0220 (β1.02) → +A1 0.0246 (β1.49) → +A4 0.0296 (β1.59) → **A1+A4 0.0415 (β1.85)** (+89%); beats ridge-OURS-2025-04 0.0365 + foundation 0.0328 (β2.08); sign ~0.497 | LOBNet3 `train_rawlob3.py` fixed (A1=1s pre-temporal conv, A4=flow stream) | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| rl3abl2 A1+A4 per-asset: FIL **0.0667**, SOL 0.0635, ETH 0.0560, ETC 0.0557, LINK 0.0530, DOT 0.0475, XRP 0.0426, DOG 0.0258, BTC 0.0061, TRX −0.0024 | same | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| Wave-1 rl3btc1: C0ref MEAN 0.0445 / β2.15 / BTC 0.0077 / SOL 0.0704; C1deshrink 0.0327 / β1.25 / BTC **0.0278** / SOL 0.0398; C2sigmatch 0.0313 / β0.95 / BTC 0.0244 / SOL 0.0441 (FIL 0.066→0.053→0.042) | per-asset gates + σ / simplified loss / σ_match | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| Wave-2 rl3btc2: S1base 0.0324 (β1.18, BTC 0.0137) / S2regime 0.0318 (β1.23, BTC **0.0024** — regime FiLM HURT BTC) | full-loss + per-asset + σ_match + regime FiLM | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| rl3btc3 basket: BTC OOS 0.0056 → 0.0183 (BasketScalar) → 0.0200 (BasketPA); but SOL 0.067→0.025, XRP 0.055→0.007, MEAN 0.043→0.031; BTC IS 0.0372→**0.0598** w/ basket (mean IS 0.123→0.150); BTC IS Pearson 0.037–0.044 = LOWEST (ETC IS 0.176) | cross-asset basket | 485d (IS diag: 25d slice) | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| rl3rank: RankW30 BTC 0.0255 / MEAN 0.0291 / β1.10 vs RankW0 BTC 0.0143 / MEAN **0.0360** / β0.94 (DOT 0.061, SOL 0.053, LINK 0.053) — rank co-train helps BTC, hurts mid-caps | rank-weight ablation | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| rl3ema: EmaOff BTC 0.0277 / MEAN 0.0326 / β1.25 vs EmaOn BTC 0.0192 / MEAN **0.0386** / β1.09 (DOT 0.040→0.061, TRX 0.008→0.028, FIL 0.051→0.058). MID-CAP DELIVERABLE = per-asset+rank0.3+EMA: **mean 0.039, FIL 0.058 / DOT 0.061 / ETH 0.048, β1.09** | EMA ablation | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |
| rl3feat interaction feats: BTC 0.0218 FLAT. BTC FULL LEVER TABLE: shared 0.006–0.012 → per-asset-gate+rank **0.028 (BEST)** → regime FiLM 0.002 → σ_match 0.014 → basket 0.020 → EMA 0.019 → drop-rank 0.014 → interactions 0.022. **BTC caps ~0.028 OOS / 0.044 IS** (data-access limit, not modeling). Mid-cap ranges: FIL 0.051–0.067 / SOL 0.040–0.066 / ETC 0.036–0.056 / ETH 0.048–0.058 / XRP-DOT 0.043–0.061 / LINK 0.029–0.053 | comprehensive BTC>0.07 program verdict | 485d | OOS 2025-04 | findings_rawlob3_audit_fixes_2026-06-01.md |

### 1f. Other raw-target results

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| E156 raw+Huber light encoder: per-asset P9 **+0.0201** (DOT .036 / FIL .039 / LINK .029 / ETC .023 / XRP .021 / DOG .010 / **BTC .009** / SOL .007 / TRX .006); cs held 0.0503 | `train_cs_ranker_seq.py --raw_target --rank_w 0.2 --huber_w 1.0` (GRU+LOB-CNN, light shared) | E155 protocol (~401d) | W1–W4 AGG | findings_e156_extraction_bottleneck.md |
| E159 deep+FiLM RAW target: per-asset RAW Pearson AGG **0.024** (BTC 0.026 = 3× E156; FIL 0.041, DOT 0.031, LINK 0.033) — raw << idio (E157 0.040) | d320 L6 deep + FiLM, Huber-primary | ~401d | W1–W4 AGG | findings_e157_perasset_breakthrough.md |
| compare_models RAW target: ridge per-asset-P **0.0214**, GBDT **0.0012** (BTC −0.002), DL (e200 conformer) ~0.022 — all ≪ single-asset 0.067 | `compare_models_fullmetrics.py` | same W-protocol | W1–W4 | findings_dl_vs_tree_fullmetrics_2026-05-30.md |
| E227 coarse raw P9 **0.0255**; E228 fine-res (step 10) raw P9 **≈0.004** (W1 0.0040/W2 0.0055/W3 0.0031) — fine resolution HURTS raw | raw target, step 60→10, L60 | 220d | W1–W4 | findings_dl_vs_tree_fullmetrics_2026-05-30.md |
| Magnitude pivot raw: GRU BTC 0.0074 / P9 0.0150 vs **Conformer BTC 0.0376 / P9 0.0214** (~5× BTC) | `--temporal_conformer --raw_target`, mag-primary CCC | 140d | W1–W4 | findings_magnitude_pivot_2026-05-30.md |
| Multi-target E229 family (raw_target, conformer): E229 cs 0.0508 / rawP9 0.021 / BTC 0.026; E229a cs 0.0423 / rawP9 0.0258 / BTC 0.031; E229b 0.0466/0.0246; E229d 0.0472/0.0211; **E229e (DELIVERABLE) cs 0.0480 / rawP9 0.0259 / idio_magP9 0.0376 / F̂_R 0.0247**; E229f strong_mkt F̂ 0.017; E229g mkt_raw F̂ −0.001; E229h uw cs 0.0431/idio-mag 0.0364/F̂ 0.0166; E229e_long 60ep cs 0.0446/idio-mag 0.0370/F̂ 0.0198 (BTC raw 0.0337 best-seen) | `--factor_bridge --raw_target --mkt_ccc --beta_prior 0.001 --head_routing` | 220d recent | W1–W4 AGG | findings_multitarget_2026-05-31.md |
| Market-factor probe: ridge AGG **0.0141** / GBDT **0.0184** predicting cm (W4 −0.061 ridge, sign-flip) — market factor caps ~0.02; earlier diag: F OOS W1 +0.057 / W2 +0.046 / W3 +0.035 / W4 −0.013, AGG **+0.031**; BTC raw AGG +0.027; β·F̂ per-asset ~0.025 | `market_factor_probe.py` / `diag_market_factor.py` | train 2025-01-01→04-05 | W1–W4 | findings_multitarget_2026-05-31.md, findings_market_factor_predictable.md |
| E171 y_3600 RAW target FAILED: per-asset RAW AGG 0.011, BTC −0.018, SOL/FIL/DOG negative | y_3600 + raw_target Huber-primary | ~400d | W1–W4 | findings_longhorizon_tradeable.md |

### 1g. Early-phase pool/val Pearson trajectory (old eval protocol: single val window, online/EMA val_P, 14 assets; pre-leak-fix before E56)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| G1: val_P_avg **0.0089** ep5 (>0.005 floor) | linear baseline, 8 Tier-1 feats | 40d | 10 val days Feb 2024 | findings_gate_g1.md |
| G2 pilot ep1: val_P_avg **0.0344**, σ 0.0171 | Deep Conformer + DAQH, tiers 1–4 | 200d | 20 val days | findings_g2_pilot.md |
| E11 BEST ep1: val_P +0.0001 / ema_P +0.0039 / BTC_LOW +0.017; σ collapse ep7 (0.003) | REG_arch loss + sigma_match 0.5 | ~100d | single val | findings_e11_trajectory.md |
| E13 ep2 BEST: val_P **+0.0149** / ema_P +0.016 / BTC_LOW +0.029 | +6 P0 features (43), sigma_match 1.0, lr 1.5e-4 | ~100d (Jul–Oct 2024) | single val | findings_e13_baseline.md |
| E15: val_P +0.026 / ema_P **+0.025** / BTC_LOW +0.027 | Phase B loss fixes | 100d | val May 2025 (7-mo gap) | findings_e20_failure_analysis.md, findings_experiments_summary |
| Overfit smoking gun: train P **+0.548** vs val +0.025 (22×); BTC train 0.558 / val 0.017 | E15 | Jul–Oct 2024 | val May 2025 | findings_overfit_regime_drift.md |
| E29 BEST: ema_P **+0.027** / val_P +0.018 / BTC_LOW **+0.043** / cs_spear +0.006; train_P ep8 0.103 vs val 0.027 (3.85×) | lookback 600 + stride 180 + patch 5 (REG_arch input shape) | 170d close-gap | 15d val (2025-04-25→05-09) | findings_e29_breakthrough.md, findings_ep3_plateau_root_cause.md |
| E44 (batch128, lr3e-4, wd1e-3): val_P peak 0.023 ep2, ema 0.016 — killed; E41 (290d): ema peak 0.021 — killed | optim/data single-axis | 170d/290d | same val | findings_reg_arch_optim_gap_2026-05-22.md |
| E49 BEST ep8: ema_P **+0.032** (+18%) / val_P +0.026 / BTC_LOW +0.042 | E29 + CSLeadLagAttention (BTC/ETH K/V) | 170d | same val | findings_e49_breakthrough.md |
| E52 ep10: BTC **+0.0761** (RAW-model single-epoch OUTLIER, not reproduced; EMA stable BTC ~0.04–0.05); val_P_avg +0.0426, cs_spear +0.0041, all 14 positive (LTC −0.027→+0.0548) | + PerAssetFiLM output + cs_normalize input | 170d | same val | findings_e52_breakthrough.md |
| E_diag BTC-only: BTC peak +0.040 (vs E52 multi-asset BTC 0.060) — multi-asset HELPS BTC | asset_filter=[0] | 170d | same val | findings_e_diag_root_cause.md |
| E56 (tier4 leak fix): ema_P **+0.0332** / val_P_avg +0.0323 / BTC ep8 peak **+0.0668** (matches 0.067) / all 14 positive / cs_spear +0.0037 | E52 + NPZ v9 leak-free tier4 | 170d | same val | findings_e56_leakfix_breakthrough.md |
| E65 book_mid target: ema_P +0.0104 (vs E56 +0.0332) — FAILED | target = (bid+ask)/2 | 170d | same val | findings_e65_book_mid_failed.md |
| E66 multilag: val_P_avg **+0.0399** (full 14) / val_P_avg_9 +0.0414 / cs_spear_9 +0.0148 / EMA crash ep7 | +13 BTC/ETH lag channels (NPZ v13, 71 feats) | 170d | same val | findings_e66_multilag.md |
| E68 Tier 10: val_P_avg_9 **+0.0402** ep5 / cs_spear_9 +0.0146 / σ 0.91 / BCH −0.007 | +VPIN/Kyle/microprice (74 feats) | 170d | same val | findings_e68_tier10.md |
| E70 stability: online val_P_avg_9 **+0.044** ep10 / composite_9 +0.030 (highest) / EMA cs peak +0.023 (+64%) | wd 1e-3 + batch 64 | 170d | same val | findings_e70_stability.md |
| E72_a_v5 ep7 (FIRST EMA gate pass): EMA val_P_avg_9 **+0.0413** / val_P_avg +0.0381 / BTC **+0.0631** (94% of 0.067) / cs_spear_9 online +0.0204 / ALL 14 positive (BCH +0.0108) | BidAskAsymStream + 34 tier7 raw-LOB ch (108 feats), d_lob=64 | 170d | same val | findings_e72_a_v5_lob_breakthrough.md |

## 2. IDIO / market-neutral per-asset Pearson (+ calibration)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| **E157**: AGG per-asset idio Pearson **0.0399** (2× E156 0.020), cs_spear held 0.0525; per-asset: **FIL 0.084 / DOT 0.074 / ETC 0.060** / LINK 0.034 / TRX 0.032 / XRP 0.029 / BTC 0.027 / SOL 0.013 / DOG 0.006; best.pt ep26 | deep per-asset d320 L6 + PerAssetFiLM (683K), `--use_lobcnn --raw_lob_seq --use_lobtemporal --per_asset_film --layers 6 --d 320 --select combo --huber_w 0.1` | ~401d (E155 backbone) | W1–W4 AGG | findings_e157_perasset_breakthrough.md |
| E157 integrity: honest clean-OOS (W2–W4) per-asset meanP **0.037** (W1-selection leak +0.011); FIL window-wise .069/.095/.092/.081, DOT .090/.053/.078/.075, ETC .075/.048/.066/.053 (5–7σ); eval N=8662/asset non-overlap | `diag_eval_integrity.py` on E157 best.pt | same | W1–W4 per-window | findings_e157_perasset_breakthrough.md |
| E157 CALIBRATION: β-slopes **0.19–0.66 (all <1)**, σ_pred/σ_act **0.06–0.13** — heavy shrinkage; BTC idio-var-share 0.34–0.52, FIL/DOT idio-share 0.67–0.88 | same | same | same | findings_e157_perasset_breakthrough.md |
| E158 (deep, NO FiLM): cs 0.0475 / per-asset idio P9 **0.0421** (FIL 0.082, DOT 0.080, ETC 0.063) — DEPTH is the driver | E157 minus per_asset_film | same | W1–W4 AGG | findings_e157_perasset_breakthrough.md |
| Magnitude-pivot idio: GRU P9 0.0387 (BTC 0.058, FIL 0.069, DOT 0.062) vs Conformer P9 0.0387 (**FIL 0.091**, DOT 0.077, ETC 0.051, BTC 0.036) | `--idio_target` mag-primary CCC | 140d | W1–W4 | findings_magnitude_pivot_2026-05-30.md |
| E205 calibration BROKEN: FIL Pearson 0.086 but σ_pred/σ_act ≈ **4**, β ≈ 0.01, sign-hit ≈ 0.50 | shared-head mag Conformer | 140d | dense | findings_magnitude_pivot_2026-05-30.md |
| E206 (GRU + split_mag + balanced rank1.0/huber1.0 CCC): calibration FIXED — σ_p/a ETC 1.01 / DOT 0.77 / FIL 1.11, **sign-hit 0.53–0.54**, bias ~0; Pearson FIL 0.084 / DOT 0.073 / ETC 0.066; cs 0.042. E207 Conformer joint worse (AGG 0.0285, σ 1.3–1.5) | `--split_mag` | 140d | dense | findings_magnitude_pivot_2026-05-30.md |
| **E210 (two-point-confirmed deliverable)**: per-asset FIL **0.082**, DOT **0.076**, ETC **0.071**, LINK 0.041, BTC 0.029, AGG **0.0406**; σ_p/a all [0.60, 1.04], sign-hit 0.51–0.53 (>0.5 every asset), bias ~0 (e-4/e-5); cs_spear 0.0444 (dense ~0.05) | E206 config + cross_asset + V-REx, cs-demean | 386d (confirmed also 140d) | DENSE N=17263 | findings_magnitude_pivot_2026-05-30.md |
| E211 mag_film: AGG 0.0398 (FIL 0.084 same, DOT 0.059 / ETC 0.059 DOWN) — no help | E206 + mag_film | 140d | dense | findings_magnitude_pivot_2026-05-30.md |
| **E215c transformer scratch**: dense cs **0.0526** / per-asset P9 **0.0440** (beats GRU E210 0.0506/0.0406); FIL 0.091, DOT 0.075, ETC 0.070; BLEMISH σ_pred/σ_act 1.3–2.7 | `--temporal_transformer --transformer_layers 2`, split_mag balanced | 386d | dense | findings_magnitude_pivot_2026-05-30.md |
| E215b transformer+SSL same-data: cs 0.0351 (HURT); E212 GRU+SSL: cs 0.0458 / P9 0.0330 (~flat); E224 570d data-scale: cs 0.0475 / P9 0.0372 (WORSE than 386d 0.0526/0.0440) | SSL / data-scale ablations | 386d / 570d | built-in / dense | findings_magnitude_pivot_2026-05-30.md, findings_signal_bound_ceiling_2026-05-30.md |
| DL-vs-tree IDIO target: ridge cs 0.0454 / per-asset-P 0.0375; GBDT 0.0489 / 0.0426; **DL E215c 0.0526 / 0.0440** (DL−GBDT per-asset = +0.0014); FIL: ridge 0.083 / GBDT 0.090 / DL 0.091; DOT DL 0.072 | `compare_models_fullmetrics.py`, identical W1–W4 | same protocol | W1–W4 | findings_dl_vs_tree_fullmetrics_2026-05-30.md |
| V-REx β-curve (cs / P9): β0 0.0503/0.0344; β0.5 0.0443/0.0346; β0.75 0.0487/0.0356; β1 0.0491/**0.0449**; β1.25 0.0505/0.0404; β2 0.0504/0.0355 — weak-real ~+0.005 P9 at β1–1.25 | E160 config + `--vrex_beta --vrex_k 5` | 386d | W1–W4 AGG | findings_regime_drift_methods.md |
| E164 recency-weighting HURTS: cs 0.0452 / P9 0.0269 vs E160 0.050/0.034 | `--recency 0.3` | 386d | W1–W4 | findings_regime_drift_methods.md |
| Universe audit (GBDT idio, demean over 14): FIL 0.084 (4/4) | **ETH 0.063 (4/4) — DROPPED in error** | LINK 0.056 | XRP 0.052 | ETC 0.051 | TRX 0.047 | DOT 0.047 | BCH 0.028 | LTC 0.026 | DOG 0.021 | BNB 0.020 | SOL 0.019 (2/4) | ADA 0.013 | **BTC 0.002 (kept, market-anchor only)** | `universe_audit.py` | GBDT protocol | W1–W4 AGG | findings_universe_audit_2026-05-31.md |
| E169 y_1800 idio: cs 0.0487 / per-asset P9 **0.0391** (ETC .089, LINK .059, FIL .053, DOT .055) — ~identical to y_600 | DeepPerAsset ranker, horizon 1800 | ~400d | W1–W4 AGG | findings_longhorizon_tradeable.md |
| E170 y_3600 idio: cs 0.0439 / per-asset P9 **0.0470 (highest)**; **BTC 0.070**, ETC 0.095, TRX 0.069, DOG 0.056, LINK 0.054, FIL 0.041, SOL 0.035, DOT 0.026, XRP −0.023 | same arch, horizon 3600 | ~400d | W1–W4 AGG | findings_longhorizon_tradeable.md |
| E229e idio-mag head: **0.0376 calibrated** (CCC-on-residual), co-exists with cs 0.048 + F̂ 0.025 in one model | multi-target factor_bridge | 220d | W1–W4 AGG | findings_multitarget_2026-05-31.md |
| E75 idio single-head: cs_spear_9 on idio +0.0264 ± 0.0034 (vs E72_a +0.0213), per-asset idio +0.0201 (DROPPED), BTC raw +0.0206, σ ratio 0.0277 collapsed | E72_a + idio target + σ_match=0 | 170d | W1–W4 mean | findings_e75_incremental.md |
| E225 FIL idio 0.093 (220d-recent, cited) | per-asset magnitude | 220d | — | findings_new_info_audit_2026-05-30.md |
| CS-IC decomposition: demeaned mean\|CS-IC\| 1.6–1.9× raw (W1 .0075 vs .0045; W2 .0081 vs .0055; W3 .0078 vs .0042; W4 .0133 vs .0084); market PC1 = 65–81% of variance | `diag_cs_ic_fast.py` | — | W1–W4 | findings_cross_sectional_alpha_2026-05-29.md |

## 3. cs_spear cross-sectional rank metrics (y_600 idio unless noted)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| **GBDT LambdaRank 0.0587** (W1 .051 / W2 .053 / W3 .066 / W4 .065) on identical protocol; 6-fold version 0.0489 (6/6 positive) | LightGBM lambdarank, 224-dim cs-z snapshot feats | train Mar2024–Apr2025 | W1–W4 AGG | findings_e142_dl_csranker_breakthrough.md |
| Linear ridge **0.0315** (6 WF folds ALL positive 0.021–0.043, std 0.0075); parallel Mar–Apr-train agent 0.0415 | ~100-param ridge, CS-demeaned feats → CS-demeaned y_600 | train 20250201–20250420 (+6-fold WF Jun2024–Jun2025) | W1–W4 / 6 folds | findings_tradeable_linear_alpha_2026-05-29.md |
| DL chain (all AGG cs_spear_9, W1–W4): old deep arch_v2 0.024 → E142 2-head MLP **0.0349** → E143 +cosine **0.0412** → E144 d256+feat_drop **0.0439** (P9 0.0332) → E145 d384 0.0432 (SATURATED) → E146 GDCN 0.0326 (FAIL) → E147 +temporal GRU **0.0501** → E149 +lead-lag 0.0480 (no gain) → E150 +snapshot LOB-CNN **0.0516** → E152 huber_w0.5 0.0296 (CRASH) → E154 +raw-LOB-seq **0.0529** → **E155 +DeepLOB time×level conv 0.0541** (W1 .055/W2 .054/W3 .055/W4 .053) | `train_cs_ranker.py` / `train_cs_ranker_seq.py`, LambdaRank two-head | 401d (stride 180) | W1–W4 AGG | findings_e142_dl_csranker_breakthrough.md |
| Guarded cross-asset: E160 base dense cs 0.0530/P9 0.0409 → E172 +cross_asset(var-floor) **0.0560** (gate +0.059 ENGAGED) → E173 2-layer 0.049 (overfit) → **E174 +V-REx dense cs 0.0550 / P9 0.0455 (best y_600 arch — rank-primary GRU+cross-asset 谱系，未校准)** → E176 per-asset gate 0.0552/0.0409 → E184 MoE-4 140d 0.0513/0.0416 → E186 MoE 386d **0.0495/0.0420 (REGRESSED)** | E160 backbone + modules, dense eval stride 300 N=17263 | 386d (140d screens) | dense W1–W4 | findings_guarded_crossasset.md |
| 140d screen: E178 base 0.0439/0.0347; E179 rank_w2 0.0420; E180 gru2 0.0413; E181 d_t128 0.0416; E182 layers8 0.0437; E183 finer L20 0.0440; E187 head_norm 0.0423; E188 attnpool 0.0398; E189/E191 dcnv2_csz 0.0492 (386d 0.0543, P9 0.0455→0.0363, 2-pt negative); E192 finer+attnpool 0.0429; E193 finer-noattn 0.0386; E195 fast-only 0.0301; E196/E197 Conformer 0.0392/0.0390; E198 Conformer 386d dense 0.0471/0.0331 | single-axis arch screens | 140d / 386d | built-in / dense | findings_guarded_crossasset.md, findings_arch_critique_2026-05-30.md |
| Fast-horizon DL: e_deliv120 **cs 0.0917 / per-asset 0.0785**; e_deliv300 cs 0.0553 / per-asset 0.0473; e_rawseq300 cs 0.063 > GBDT 0.055 | DL CS-ranker, idio target, per-horizon | ~400d | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md |
| Flagship full-scale: **y_120 cs_spear_9 +0.0902** (rawP9 +0.0469, idio_magP9 +0.0574, windows 0.082–0.096); y_300 cs +0.0630 (rawP9 +0.0292) | flagship B: d320 L6 transformer + un-pool LOBTemporalCNN + 3-head factor_bridge + per_asset_film, raw_target, UNIV10, 40ep | train_start 20240901 (~220d) | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md |
| Single-axis levers (220d base cs 0.0362/per 0.0342): un-pool `--lob_attnpool` cs 0.0380 / per **0.0399** (+0.0057); warm-start `--init_full` (y_300→y_600) cs **0.0409** (+0.0047); COMBINED 0.0360 (did NOT stack → noise) | y_600 idio | 220d | W1–W4 | findings_ic_term_structure_2026-05-31.md |
| Dual-horizon rank_short: point1 220d base 0.0448 vs rh300 0.0482 (Δ+0.0034); point2 386d base 0.0440 vs rh300 0.0450 (Δ+0.0010) → DISCARDED (noise) | `--rank_horizon 300` | 220d + 386d | W1–W4 | findings_ic_term_structure_2026-05-31.md |
| Fine 1s-LOB at y_120: coarse cs_spear_10 +0.0927 / fine60 +0.0932 / fine120 +0.0921 (±0.0006 NOISE → lever CLOSED) | `--fine_lob` 2nd LOBTemporalCNN | train_start 20240901 | W1–W4 | findings_npz_foundation_audit_2026-05-31.md |
| Walk-forward DL y_1800 deliverable: OOS cs_spear mean **0.034, 8/8 folds positive (range .016–.043)** | transformer+lobtemporal+per_asset_film+cross_asset, idio, drop_tier4 | 8 folds × 180d train → 30d OOS | 2023-08→2025-06 | findings_npz_foundation_audit_2026-05-31.md |
| E_deliv1800 dense cs_spear_9 0.0315; E_deliv3600 dense 0.0261 (ETC 0.082 / XRP 0.088 / LINK 0.068; FIL/DOG/TRX negative) | deliverable transformer rankers | train_start 20240901 | dense OOS | findings_deliverable_y1800_backtest_2026-05-31.md |
| Factor gates: book-shape slope_imbalance +0.0170 residual cs-IC (4/4) — then OVERTURNED by corrected dual gate (idio −0.0198 / raw −0.0179, suppressor artifact); multi-level OFI best L3 +0.0064 (<+0.010 gate, REDUNDANT); signed book-event 1s residual +0.0070 (KILLED, <+0.010; ema10 −0.008/ema30 −0.014/agg60 −0.013); net_book_pressure 1s IC +0.0131 but 60s-summed −0.0605 | `book_shape_probe.py`, `factor_gate_dual.py`, `multi_level_ofi_probe.py`, `gate_signed_bookevent.py` | — | W1–W4 / W1 | findings_ic_term_structure_2026-05-31.md, findings_new_info_audit_2026-05-30.md, findings_dl_vs_tree_fullmetrics_2026-05-30.md |
| Signal-bound ceiling verdict: GBDT 0.0587 ≈ best DL E174 0.0550/P9 0.0455 on same 224-dim input → information-bound; realistic best ~0.055–0.059 cs / 0.045–0.050 P9 | 15-agent workflow + E224 | 386–570d | W1–W4 dense | findings_signal_bound_ceiling_2026-05-30.md |

## 4. Tradeable / backtest results (net Sharpe unless noted)

| Metric | Model / config | Train days | Eval window | Source file |
|---|---|---|---|---|
| Linear CS-alpha L/S top2-bot2: 10min gross +13.6 / @1bp −2.6 / @2bp −18.7 / @4bp −50.9; 2h gross +4.3 / +2.8 / +1.3 / −1.7; 4h gross +3.4 / +2.7 / **+1.9** / +0.4; gross edge ~0.9–1.1 bps/trade | ridge ~100 params | train 20250201–20250420 | single 2-mo OOS (8662 obs) | findings_tradeable_linear_alpha_2026-05-29.md |
| Linear WF correction (6 folds): net@2bp mean **~0** (2/6 positive); @1bp +0.72 (2/6); @0.5bp +1.1 (3/6); gross edge ~0–0.9bps, F1/F3/F4 −0.03..−0.08 bps | `linear_cs_walkforward.py` | 6 folds Jun2024–Jun2025 | 6 OOS folds | findings_tradeable_linear_alpha_2026-05-29.md |
| E144 snapshot ranker: 2h @0.5bp **+2.58** / @1bp **+1.58** / @2bp −0.42; 4h @1bp +0.98 / @2bp −0.00; gate mode h24@2bp +0.50, h24@1bp +1.43; linear ref @1bp +0.72 | `bt_csranker.py`, vol-weighted full-CS L/S UNIV9 | 401d | W1–W4 non-overlap stride 600 | findings_e142_dl_csranker_breakthrough.md |
| E150 temporal+LOB: 1h @1bp **+3.58** / @2bp +0.08 / @4bp −6.88; 2h @1bp +1.35; 4h @1bp +0.23; W4 h6@2bp +4.11 (high dispersion) | `bt_csranker_seq.py` | 401d | W1–W4 | findings_e142_dl_csranker_breakthrough.md |
| E155: h2 @1bp +1.65 / @2bp −0.12; h1 @1bp +2.68 / @2bp −0.79 — higher IC did NOT beat 2bp wall | same | 401d | W1–W4 | findings_e142_dl_csranker_breakthrough.md |
| E169 y_1800: hold 60min @2bp **+2.09** / hold 120min @2bp **+1.95**; @1bp +4.9 / +3.4; all 4 windows positive @2bp/1h (W1 +4.3 / W2 +0.5 / W3 +2.3 / W4 +1.4) | DeepPerAsset ranker on y_1800 | ~400d | W1–W4, horizon-correct ann | findings_longhorizon_tradeable.md |
| E170 y_3600: h1 @1bp **+6.62** / @2bp **+4.32** / @4bp −0.26; h2 @2bp +1.45; windows @2bp/h1 +3.0 / +2.7 / +9.4 / +2.1 | same on y_3600, V-REx β1.25 | ~400d | W1–W4 (~1300 periods, CI ±2) | findings_longhorizon_tradeable.md |
| E_deliv1800 portfolio: hold1 @0bp +9.15/@1bp +3.48/@2bp −2.19/@3bp −7.85; hold2 +6.40/+3.43/+0.46/−2.51; **hold3 (90m) +5.62/+3.65/+1.67/−0.31**; hold4 +1.64/+0.14/−1.35/−2.85; **hold6 (180m) +3.69/+2.70/+1.72/+0.73** → **+1.7 @2bp MEETS mission ≥1.5** *(superseded — 见下方 WALK-FORWARD CORRECTION 行)* | temporal transformer CS-ranker, idio, y_1800 (`bt_csranker_seq.py`) | train_start 20240901 | W1–W4 mean | findings_deliverable_y1800_backtest_2026-05-31.md |
| E_deliv3600: hold3 (180min) @0bp +3.55 / @1bp +2.76 / **@2bp +1.98 / @3bp +1.20** (most cost-robust); hold1 @2bp +0.20 | same, horizon 3600 | train_start 20240901 | W1–W4 mean | findings_deliverable_y1800_backtest_2026-05-31.md |
| **WALK-FORWARD CORRECTION (ridge, 8 folds 2023–2025)**: y_1800 @2bp hold30 **−5.97** (1/8+) / hold60 −2.81 (1/8+) / hold90 −2.36; y_3600 hold180 @2bp −0.41; gross positive 8/8; only fold6 (Feb–Mar 2025) clears (h2 @2bp +2.30) → "+1.7 @2bp" = favorable-2025-window artifact | `walkforward_backtest.py`, naive full-rebalance | 8 folds 180d→30d | 2023-08→2025-06 | findings_npz_foundation_audit_2026-05-31.md |
| Proper per-fold DL WF backtest: best naive hold-90min @2bp **−0.52** (3/8+), @1bp +0.74 (5/8+), @0bp +2.01–3.76 (6–8/8+) → DL does NOT clear 2bp either | `wf_train_driver.py` + `wf_backtest.py` | 8 folds | same | findings_npz_foundation_audit_2026-05-31.md |
| De-leaked strategy ladder (e_wf1800, frozen-train σ, BTC excl): S0 naive @1bp +0.03 / @2bp −4.02; +hold-reversal+band @1bp +0.35 (5/8) / @2bp −1.46 / @0bp +2.16; mag-tilt @1bp −0.01 (HURTS, OFF); tail-K ≈ naive | strategy design ablation | 8 folds | same | findings_npz_foundation_audit_2026-05-31.md |
| **Conviction-gate (best lever)**: conv z1.0 hold: turnover 0.27, @0bp +2.51 (6/8) / @1bp **+1.22** (5/8) / @2bp **−0.08** (5/8 folds positive — first ~breakeven @2bp) | per-asset causal running-z gate, hold-until-opposite | 8 folds | same | findings_npz_foundation_audit_2026-05-31.md |
| Directional reframe: idio model conv-z1.0 directional @2bp **+0.91** (6/8) vs SIGN-FLIP control −3.79 vs MOMENTUM control −1.33 vs market-neutral L/S +0.11; net-exposure 0.27; calibrated-raw model FAILED (σ-collapse β=50, σpred/σact=0.00, directional +0.48) | `bt_directional.py` | 8 folds | same | findings_npz_foundation_audit_2026-05-31.md |
| Horizon economics (UNIV10, ridge realizable / oracle, gross bps/trade): h120 IC 0.083 σ_idio 6.0 → ridge **+1.12** / oracle +13.5; h300 0.051/9.3/+0.95/+21.0; h600 0.041/13.1/+1.04/+29.4; h1800 0.023/22.3/+0.80/+50.2; h3600 0.010/31.6/−0.2/+71.1; h7200 0.009/44.3/+0.37/+99.3; h14400 0.007/61.8/−2.8/+139.2. Identity gross/trade ≈ IC×σ_idio. DL frontier: IC_DL y120 0.090 / y600 0.052 / y1800 0.049 → gross_DL ~1.2 / ~1.5 / **~2.5 bps** (clears 2bp only y1800+) | `horizon_economics.py` | dense train stride 180, eval stride=h | W1–W4 | findings_horizon_economics_2026-05-31.md |
| Misc cost-wall datapoints: E20 signal 0.75bps vs 4–5bps cost (net −3.5..−4.2 bps/trade); snapshot-regression L-S @2bp ridge −2.6 / GBDT −1.5; universe audit y_600 @2bp ALL14 −14.4 / UNIV9 −11.6; E15 portfolio Sharpe −97 @5bps | various | various | various | findings_e20_failure_analysis.md, findings_dl_vs_tree_fullmetrics_2026-05-30.md, findings_universe_audit_2026-05-31.md, findings_experiments_summary_2026-05-22.md |

## 5. IC term structure by horizon (cs_spear_9, idio-demeaned target, same 224-dim cs-z features)

| Horizon | ridge | GBDT | DL (where measured) | Eval | Source file |
|---|---|---|---|---|---|
| y_120 (2min) | **+0.0795** | **+0.0840** | DL CS-ranker **0.0917** (per-asset 0.0785); flagship **0.0902** | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md |
| y_300 (5min) | +0.0554 | +0.0547 | DL 0.0553 / flagship 0.0630 / e_rawseq300 0.063 | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md |
| y_600 (10min) | +0.0415 | +0.0417 | best DL 0.0541–0.0550 (E155/E174), GBDT-protocol 0.0587 | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md |
| y_1800 (30min) | +0.0277 | +0.0180 | E169 DL 0.0487 (IC_DL ~0.049 — decays slower than ridge) | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md, findings_longhorizon_tradeable.md |
| y_3600 (1h) | +0.0155 | +0.0115 | E170 DL 0.0439 | W1–W4 AGG | findings_ic_term_structure_2026-05-31.md, findings_longhorizon_tradeable.md |

Supplements:
- Cross-horizon (y_600-trained ridge/gbdt predictor scored vs each y_h): y_120 0.064 / y_300 0.051 / y_600 0.042 / y_1800 0.035 / y_3600 0.028 — the y_600 model predicts y_120 BETTER than its own target. (findings_ic_term_structure_2026-05-31.md)
- MEMORY.md/CLAUDE.md canonical summary numbers: cs_spear y_120=0.084 / y_300=0.055 / y_600=0.042 / y_1800=0.018 / y_3600=0.012. (MEMORY.md, CLAUDE.md)
- Leak-free 8-fold walk-forward ridge re-validation (tier4+cs-z dropped, UNIV10, 22 months): **y_120 mean +0.0664 (std .010, min .049, 8/8 positive); y_300 +0.0428 (8/8); y_600 +0.0367 (std .007, min .020, 8/8)** — term structure REAL, not a leak/window artifact. (findings_npz_foundation_audit_2026-05-31.md, `walkforward_revalidate.py`, 180d train → 30d OOS, step 60d, 2023-08→2025-06)
- Horizon-economics IC column (ridge, denser protocol): y120 0.083 / y300 0.051 / y600 0.041 / y1800 0.023 / y3600 0.010. (findings_horizon_economics_2026-05-31.md)

### Note: E174 vs E215c "best arch" 的口径区分
E174 (cs 0.0550/P9 0.0455) 与 E215c (0.0526/0.0440) 分属两条谱系：E174 = rank-primary GRU+cross-asset+V-REx（magnitude 未校准）；E215c = calibrated split_mag 谱系内的最佳架构（对比同谱系 GRU E210 0.0506/0.0406）。比较 "best DL" 时须先指明谱系。

### Cross-cutting caveats attached to these numbers (from the source files)
- Pre-2026-06-01 deep-model RAW-Pearson numbers that used per-day `_gz` input normalization are LEAK-INFLATED (~14×); causal numbers are the 1c/1e tables. (findings_norm_lookahead_leak_2026-06-01.md)
- NPZ v23 tier4 regime cols 30–40 carried a within-day-quantile leak (bounded, inflates) until rebuilt; `drop_tier4` runs are leak-free. (findings_npz_foundation_audit_2026-05-31.md)
- Early-phase (1g) metrics use a single close-gap val window + online/EMA protocol, 14 assets — not comparable to the later W1–W4 AGG / dense protocols.
- Labels `cs_spear_9`/`P9`/`rawP9` were historically computed over 10 assets once ETH was added; canonical universe = UNIV10 `[0,1,13,4,11,2,12,5,7,9]`. (CLAUDE.md mandatory protocol)
- Single-seed (P8); deltas <~0.005 are noise; W1-selection inflates headlines by ~+0.011 (E157 integrity check).