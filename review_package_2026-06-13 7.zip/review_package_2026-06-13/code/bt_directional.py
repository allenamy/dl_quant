"""PER-ASSET DIRECTIONAL backtest (single-asset recipe transferred to multi-asset).
For each asset independently: predict RAW return -> de-bias (causal trailing mean) -> trade the 5%/95% tail
(causal z-gate) + hold-until-reversal -> vol-weighted DIRECTIONAL portfolio (NOT market-neutral; keeps the
directional move). Reports per-fold CALIBRATION (beta, sigma_pred/sigma_act, sign-hit) — the gate that says
whether the extreme tail can clear the fee. Net Sharpe @ cost sweep across 8 walk-forward folds.
Usage: python bt_directional.py <model_prefix>   (e.g. e_wfcalib1800)
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch
from train_cs_ranker_seq import CSRankerSeq, load_seq
from train_cs_ranker import UNIV10, dr

NPZ=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap")
EXP=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments")
PREF=sys.argv[1] if len(sys.argv)>1 else "e_wfcalib1800"
NTR,NTE,STEP=180,30,60; H=1800; COSTS=[0,1,2,3]; ZS=(1.0,1.5,2.0)
ann=np.sqrt(31536000.0/H); device="cuda" if torch.cuda.is_available() else "cpu"

def dt4(Xs,Xq): Xs=Xs.copy();Xs[...,30:41]=0;Xs[...,142:153]=0;Xq=Xq.copy();Xq[...,30:41]=0;return Xs,Xq

@torch.no_grad()
def predict_mag(model,Xs,Xq,bs=1024):
    model.eval();N=Xs.shape[0];mg=np.zeros((N,Xs.shape[1]),np.float32)
    for i in range(0,N,bs):
        xs=torch.from_numpy(Xs[i:i+bs]).to(device);xq=torch.from_numpy(Xq[i:i+bs]).to(device)
        _,ms,_=model(xs,xq);mg[i:i+bs]=ms.cpu().numpy()
    return mg

def debias(pred):  # causal trailing-mean subtraction per asset (remove DC long/short bias)
    T,Sn=pred.shape; cs=np.cumsum(np.nan_to_num(pred),0); cnt=np.arange(1,T+1)[:,None]
    mean=cs/cnt; mp=np.vstack([np.zeros((1,Sn)),mean[:-1]]); return pred-mp

def calib(pred,y):  # per-asset beta, sigma_pred/sigma_act, sign-hit (DIAGNOSTIC over OOS); pred,y already UNIV10-subset
    bs=[];srs=[];shs=[]
    for a in range(pred.shape[1]):
        p=pred[:,a];r=y[:,a];m=np.isfinite(p)&np.isfinite(r)
        if m.sum()<100 or np.var(p[m])<1e-20: continue
        bs.append(np.cov(r[m],p[m])[0,1]/np.var(p[m])); srs.append(np.std(p[m])/(np.std(r[m])+1e-12))
        shs.append(np.mean(np.sign(p[m])==np.sign(r[m])))
    return np.nanmean(bs),np.nanmean(srs),np.nanmean(shs)

def conv_sig(pred,z,warmup=30):  # causal running-z; +1 if pred > z·trailing-σ above trailing mean
    T,Sn=pred.shape;mg=np.nan_to_num(pred);cnt=np.arange(1,T+1)[:,None]
    cs=np.cumsum(mg,0);cs2=np.cumsum(mg*mg,0);mean=cs/cnt;std=np.sqrt(np.maximum(cs2/cnt-mean*mean,1e-12))
    mp=np.vstack([np.zeros((1,Sn)),mean[:-1]]);sp=np.vstack([np.ones((1,Sn)),std[:-1]])
    z_=(pred-mp)/sp;sig=np.where(z_>z,1.0,np.where(z_<-z,-1.0,0.0));sig[:warmup]=0;return sig

def directional_bt(sig,raw_y,sigma,costs,ann,hold=True):
    T,Sn=sig.shape;pos=np.zeros(Sn);W=np.zeros((T,Sn))
    for t in range(T):
        if hold:
            for s in range(Sn):
                if not np.isfinite(raw_y[t,s]): pos[s]=0
                elif sig[t,s]!=0: pos[s]=sig[t,s]
            cur=pos.copy()
        else: cur=np.where(np.isfinite(raw_y[t]),sig[t],0.0)
        w=cur/sigma; gl=np.abs(w).sum()
        W[t]=w/gl if gl>1e-12 else 0.0   # unit gross; DIRECTIONAL (net exposure != 0)
    pnl=np.nansum(W*np.where(np.isfinite(raw_y),raw_y,0.0),1)
    dW=np.abs(np.diff(W,axis=0,prepend=0)).sum(1);turn=float(dW.mean())
    nets={c:float((pnl-dW*c*1e-4*0.5).mean()/((pnl-dW*c*1e-4*0.5).std()+1e-12)*ann) for c in costs}
    netexp=float(np.abs(W.sum(1)).mean())   # mean |net exposure| — if large, book is DIRECTIONAL (drift-exposed)
    return float(pnl.mean()/(pnl.std()+1e-12)*ann),nets,turn,netexp

def main():
    days=sorted(int(p.name) for p in NPZ.iterdir() if p.name.isdigit() and (p/"X.npy").exists())
    folds=[];i=0
    while i+NTR+NTE<=len(days): folds.append((days[i:i+NTR],days[i+NTR:i+NTR+NTE]));i+=STEP
    print(f"{len(folds)} folds; y_{H}; MODEL={PREF}; DIRECTIONAL per-asset tail+hold\n",flush=True)
    cal=[]; agg={z:{c:[] for c in COSTS} for z in ZS}; turns={z:[] for z in ZS}; fl={1:[]}; nxs=[]; mom=[]
    for k,(tr,te) in enumerate(folds):
        ck=EXP/f"diagnostic_{PREF}_f{k}/best.pt"
        if not ck.exists(): print(f"  fold{k}: no ckpt — skip",flush=True); continue
        sig0=[]
        Xs,Xq,Yw,Vw=load_seq(dr(te[0],te[-1]),H,10,60,raw_lob=True,raw_target=True,horizon=H)
        if Xs is None: print(f"  fold{k}: no OOS",flush=True); continue
        Xs,Xq=dt4(Xs,Xq)
        model=CSRankerSeq(Xs.shape[-1],Xq.shape[-1],d=320,layers=6,use_lobcnn=True,use_lobtemporal=True,
            per_asset_film=True,split_mag=True,temporal_transformer=True,transformer_layers=2).to(device)
        model.load_state_dict(torch.load(ck,map_location=device),strict=False)
        mg=predict_mag(model,Xs,Xq); mgU=mg[:,UNIV10]; yU=Yw[:,UNIV10]
        b,sr,sh=calib(mgU,yU); cal.append((b,sr,sh))
        sigma=np.nanstd(np.where(np.isfinite(yU),yU,np.nan),0)+1e-9
        dbp=debias(mgU)
        line=f"  f{k}: calib β={b:+.2f} σp/σa={sr:.2f} signhit={sh:.3f} | "
        for z in ZS:
            sig=conv_sig(dbp,z); gs,nets,turn,nx=directional_bt(sig,yU,sigma,COSTS,ann,hold=True)
            for c in COSTS: agg[z][c].append(nets[c])
            turns[z].append(turn)
            if z==1.0:
                _,fnets,_,_=directional_bt(-sig,yU,sigma,COSTS,ann,hold=True)   # SIGN-FLIP control
                pastret=np.vstack([np.zeros((1,yU.shape[1])),yU[:-1]])             # MOMENTUM control: lag-1 realized return (causal)
                _,mnets,_,_=directional_bt(conv_sig(pastret,1.0),yU,sigma,COSTS,ann,hold=True)
                fl[1].append(fnets[2]); nxs.append(nx); mom.append(mnets[2])
                line+=f"z1.0[@2bp={nets[2]:+.2f} FLIP@2bp={fnets[2]:+.2f} netexp={nx:.2f}]"
        print(line,flush=True)
    cb=np.array([c for c in cal]); print(f"\n  CALIBRATION (mean): β={np.nanmean(cb[:,0]):+.2f} σpred/σact={np.nanmean(cb[:,1]):.2f} signhit={np.nanmean(cb[:,2]):.3f}",flush=True)
    print(f"  (calibration GATE: β≈1 AND σpred/σact small≈ρ → extreme tail maps to extreme return)\n",flush=True)
    print("=== DIRECTIONAL net Sharpe (mean across folds), @cost(pos/8) ===",flush=True)
    for z in ZS:
        row=" ".join(f"@{c}={np.mean(agg[z][c]):+.2f}({int((np.array(agg[z][c])>0).sum())}/{len(agg[z][c])})" for c in COSTS)
        print(f"  conv z{z} turn={np.mean(turns[z]):.2f}: {row}",flush=True)
    print(f"\n  CONFOUND CHECK: model z1.0 @2bp={np.mean(agg[1.0][2]):+.2f} | FLIP @2bp={np.mean(fl[1]):+.2f} | MOMENTUM(lag-ret) @2bp={np.mean(mom):+.2f} | net-exp={np.mean(nxs):.2f}",flush=True)
    print("  -> If MOMENTUM ~= model: the model just rediscovers trend-following (no microstructure alpha). If model >> momentum & FLIP negative: model adds real directional skill.",flush=True)

if __name__=="__main__":
    main()
