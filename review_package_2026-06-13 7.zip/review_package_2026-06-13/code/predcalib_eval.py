"""Joint-CALIBRATION eval (user's tradeable criterion: rank alone is insufficient; the magnitude
must be calibrated — beta~1, sigma_pred~sigma_act, low bias — to be tradeable per-asset AND to
give a real L-S spread). Reports, per asset (mag head): Pearson, beta=slope(actual~pred),
sigma_pred/sigma_act, bias(mean pred-act), sign-hit. Dense WINDOWS eval. Mirrors predquality_eval flags.
"""
from __future__ import annotations
import argparse, math
import numpy as np
import torch
from train_cs_ranker_seq import CSRankerSeq, load_seq, dr, WINDOWS, UNIV9
ANAME={0:"BTC",13:"ETC",4:"XRP",11:"DOT",2:"SOL",12:"FIL",5:"DOG",7:"LINK",9:"TRX"}
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--ckpt",required=True);ap.add_argument("--horizon",type=int,default=600);ap.add_argument("--eval_stride",type=int,default=300)
    ap.add_argument("--L",type=int,default=10);ap.add_argument("--step",type=int,default=60)
    ap.add_argument("--d",type=int,default=320);ap.add_argument("--layers",type=int,default=6)
    ap.add_argument("--use_lobcnn",action="store_true");ap.add_argument("--raw_lob_seq",action="store_true")
    ap.add_argument("--use_lobtemporal",action="store_true");ap.add_argument("--per_asset_film",action="store_true");ap.add_argument("--use_fm",action="store_true")
    ap.add_argument("--cross_asset",action="store_true");ap.add_argument("--idio_target",action="store_true")
    ap.add_argument("--temporal_conformer",action="store_true");ap.add_argument("--conf_kernel",type=int,default=9);ap.add_argument("--split_mag",action="store_true");ap.add_argument("--temporal_transformer",action="store_true");ap.add_argument("--transformer_layers",type=int,default=2);ap.add_argument("--temporal_hybrid",action="store_true");ap.add_argument("--hybrid_near",type=int,default=30);ap.add_argument("--hybrid_patch",type=int,default=5);ap.add_argument("--mag_film",action="store_true")
    ap.add_argument("--temporal_attnpool",action="store_true");ap.add_argument("--temporal_fast_only",action="store_true")
    a=ap.parse_args(); dev="cuda" if torch.cuda.is_available() else "cpu"
    Xs0,Xq0,_,_=load_seq(dr(20250425,20250426),a.eval_stride,a.L,a.step,raw_lob=a.raw_lob_seq,horizon=a.horizon,idio_target=a.idio_target)
    model=CSRankerSeq(Xs0.shape[-1],Xq0.shape[-1],d=a.d,layers=a.layers,use_lobcnn=a.use_lobcnn,use_lobtemporal=a.use_lobtemporal,per_asset_film=a.per_asset_film,use_fm=a.use_fm,cross_asset=a.cross_asset,temporal_conformer=a.temporal_conformer,conf_kernel=a.conf_kernel,split_mag=a.split_mag,mag_film=a.mag_film,temporal_transformer=a.temporal_transformer,transformer_layers=a.transformer_layers,temporal_hybrid=a.temporal_hybrid,hybrid_near=a.hybrid_near,hybrid_patch=a.hybrid_patch,temporal_attnpool=a.temporal_attnpool,temporal_fast_only=a.temporal_fast_only).to(dev)
    model.load_state_dict(torch.load(a.ckpt,map_location=dev)); model.eval()
    print(f"loaded {a.ckpt} idio={a.idio_target} conformer={a.temporal_conformer}",flush=True)
    agg={s:{"p":[],"a":[]} for s in UNIV9}
    for wn,wa,wb in WINDOWS:
        Xs,Xq,Yw,Vw=load_seq(dr(wa,wb),a.eval_stride,a.L,a.step,raw_lob=a.raw_lob_seq,horizon=a.horizon,idio_target=a.idio_target)
        if Xs is None: continue
        N=Xs.shape[0]; mp=np.zeros((N,14),np.float32)
        with torch.no_grad():
            for i in range(0,N,1024):
                r,m,_=model(torch.from_numpy(Xs[i:i+1024]).to(dev),torch.from_numpy(Xq[i:i+1024]).to(dev))
                mp[i:i+1024]=m.cpu().numpy()
        for s in UNIV9:
            v=Vw[:,s]; agg[s]["p"].append(mp[v,s]); agg[s]["a"].append(Yw[v,s])
    print(f"{'asset':5} {'Pearson':>8} {'beta':>7} {'sig_p/a':>8} {'bias':>9} {'signhit':>8} {'N':>7}")
    Ps=[];Bs=[];SRs=[];SHs=[]
    for s in UNIV9:
        p=np.concatenate(agg[s]["p"]);y=np.concatenate(agg[s]["a"])
        sp,sy=p.std(),y.std()
        pear=np.corrcoef(p,y)[0,1] if sp>1e-12 and sy>1e-12 else float("nan")
        beta=np.cov(y,p)[0,1]/(p.var()+1e-12)          # slope of ACTUAL on PRED (beta=1 calibrated)
        sr=sp/(sy+1e-12); bias=(p-y).mean(); sh=(np.sign(p)==np.sign(y)).mean()
        print(f"{ANAME[s]:5} {pear:+8.4f} {beta:+7.3f} {sr:8.3f} {bias:+9.2e} {sh:8.3f} {len(p):7d}")
        Ps.append(pear);Bs.append(beta);SRs.append(sr);SHs.append(sh)
    print(f"\nAGG  Pearson={np.nanmean(Ps):+.4f}  beta={np.nanmean(Bs):+.3f}  sig_p/a={np.nanmean(SRs):.3f}  signhit={np.nanmean(SHs):.3f}")
    print("INTERP: tradeable per-asset needs Pearson>0, beta~1 (not collapsed/inflated), sig_p/a~0.3-1 (not sigma-collapsed), signhit>0.5",flush=True)
if __name__=="__main__":
    main()
