"""WALK-FORWARD DL backtest — DE-LEAKED, principled strategy + single-axis ABLATION LADDER.
Per fold: frozen-from-TRAIN per-asset idio vol (kills the OOS-window avol leak), predict rank+mag,
run the ladder S0->S4, report net Sharpe + turnover @ cost sweep across folds. BTC excluded from tails (idio~0).
  S0 naive full-rebalance rank-weight   S1 +tail-K   S2 +hold-until-full-reversal   S3 +turnover band   S4 +mag-tilt
Keep a lever only if Δnet@1bp>+0.005 in >=6/8 folds. Maker NOT headlined; report 0/1/2/3 bp + flag taker=4.5bp dead.
Usage: python wf_backtest.py <model_prefix>   (e.g. e_wf1800 | e_wfaux1800)
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch
from scipy.stats import rankdata
from train_cs_ranker_seq import CSRankerSeq, load_seq
from train_cs_ranker import UNIV10, dr

NPZ=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap")
EXP=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments")
PREF=sys.argv[1] if len(sys.argv)>1 else "e_wf1800"
NTR,NTE,STEP=180,30,60; H=1800; COSTS=[0,1,2,3]; K=3; BAND=0.15
ann=np.sqrt(31536000.0/H); device="cuda" if torch.cuda.is_available() else "cpu"
BTC_LOC=UNIV10.index(0)   # BTC position within UNIV10 -> excluded from tail selection (idio~0)

def dt4(Xs,Xq): Xs=Xs.copy();Xs[...,30:41]=0;Xs[...,142:153]=0;Xq=Xq.copy();Xq[...,30:41]=0;return Xs,Xq

def frozen_sigma(train_days):
    """Per-asset idio (cs-demean) vol over UNIV10, from the TRAIN fold only (no OOS look-ahead)."""
    ys=[]
    for d in train_days:
        yp=NPZ/str(d)/f"y_{H}.npy"
        if not yp.exists(): continue
        y=np.asarray(np.load(yp,mmap_mode="r"),np.float32); ys.append(y[::H])  # non-overlap subsample
    if not ys: return np.ones(len(UNIV10))*1e-3
    Y=np.concatenate(ys); m=np.nanmean(np.where(np.isfinite(Y),Y,np.nan),1,keepdims=True); Yi=Y-m
    return np.nanstd(Yi[:,UNIV10],0)+1e-9

@torch.no_grad()
def predict(model,Xs,Xq,bs=1024):
    model.eval();N=Xs.shape[0];rk=np.zeros((N,Xs.shape[1]),np.float32);mg=np.zeros((N,Xs.shape[1]),np.float32)
    for i in range(0,N,bs):
        xs=torch.from_numpy(Xs[i:i+bs]).to(device);xq=torch.from_numpy(Xq[i:i+bs]).to(device)
        rs,ms,_=model(xs,xq);rk[i:i+bs]=rs.cpu().numpy();mg[i:i+bs]=ms.cpu().numpy()
    return rk,mg

def _stats(W,Yd,costs,ann):
    pnl=np.nansum(W*np.where(np.isfinite(Yd),Yd,0.0),1)
    dW=np.abs(np.diff(W,axis=0,prepend=0)).sum(1); turn=float(dW.mean())
    nets={c:float((pnl-dW*c*1e-4*0.5).mean()/((pnl-dW*c*1e-4*0.5).std()+1e-12)*ann) for c in costs}
    return float(pnl.mean()/(pnl.std()+1e-12)*ann),nets,turn

def conv_signal(mag,z,warmup=30):
    """CAUSAL per-asset conviction: +1 if mag_i[t] > z·σ above its OWN trailing mean (extreme up-conviction),
    -1 if below (extreme down), else 0. Uses only past predictions (cumulative stats shifted by 1) -> no leak."""
    T,Sn=mag.shape; mg=np.nan_to_num(mag); cnt=np.arange(1,T+1)[:,None]
    cs=np.cumsum(mg,0); cs2=np.cumsum(mg*mg,0); mean=cs/cnt; std=np.sqrt(np.maximum(cs2/cnt-mean*mean,1e-12))
    mp=np.vstack([np.zeros((1,Sn)),mean[:-1]]); sp=np.vstack([np.ones((1,Sn)),std[:-1]])  # stats up to t-1
    z_=(mag-mp)/sp; sig=np.where(z_>z,1.0,np.where(z_<-z,-1.0,0.0)); sig[:warmup]=0
    return sig

def run(rank,mag,Yd,sigma,K,tail,hold,band,mtilt,costs,ann,conv_z=0.0):
    """tail=tail-K; hold=hold-until-full-reversal; band=no-trade band; mtilt=mag sizing; conv_z>0=per-asset conviction gate."""
    T,Sn=rank.shape; pos=np.zeros(Sn); Wp=np.zeros(Sn); W=np.zeros((T,Sn))
    csig=conv_signal(mag,conv_z) if conv_z>0 else None
    for t in range(T):
        v=np.isfinite(rank[t])&np.isfinite(Yd[t]); v[BTC_LOC]=False   # exclude BTC from selection
        nv=int(v.sum())
        if nv<2*K or np.std(rank[t,v])<=1e-12: W[t]=Wp; continue
        rk=np.full(Sn,np.nan); rk[v]=rankdata(rank[t,v])
        top=(rk>nv-K); bot=(rk<=K)
        if conv_z>0:   # USER'S per-asset magnitude-conviction gate (trade only extreme-prediction assets)
            if hold:   # hold conviction position until OPPOSITE conviction fires
                for s in range(Sn):
                    if not v[s]: pos[s]=0
                    elif csig[t,s]!=0: pos[s]=csig[t,s]   # update on a fresh conviction fire, else hold
                sel=pos.copy()
            else: sel=np.where(v,csig[t],0.0)             # flat when not confident
        elif not tail:  # S0: full cross-section rank-demean (naive)
            r=np.full(Sn,np.nan); r[v]=rk[v]-np.nanmean(rk[v]); sel=np.where(v,r,0.0)
        elif hold:    # tail-K + hold-until-full-reversal
            for s in range(Sn):
                if not v[s]: pos[s]=0
                elif top[s]: pos[s]=1.0
                elif bot[s]: pos[s]=-1.0   # else: hold
            sel=pos.copy()
        else:         # tail-K rebalance (no hold)
            sel=np.zeros(Sn); sel[top]=1.0; sel[bot]=-1.0
        w=np.where(v,sel/sigma,0.0)
        if mtilt: w=w*np.clip(np.abs(mag[t])/sigma,0.5,2.0)
        lp=w[w>0].sum(); ls=-w[w<0].sum()
        if lp>1e-12: w[w>0]=w[w>0]/lp*0.5
        if ls>1e-12: w[w<0]=w[w<0]/ls*0.5
        w=np.clip(w,-2.0/K,2.0/K)
        if band>0: w=np.where(np.abs(w-Wp)>band,w,Wp)
        W[t]=w; Wp=w
    return _stats(W,Yd,costs,ann)

# Levers: full-CS+band (best so far) vs USER's per-asset conviction gate (trade only extreme-prediction assets).
LADDER=([("fullCS band0.25",dict(tail=False,hold=False,band=0.25,mtilt=False))]
        +[(f"conv z{z:.1f} hold",dict(tail=False,hold=True,band=0.10,mtilt=False,conv_z=z)) for z in (0.6,0.8,1.0,1.2)]
        +[(f"conv z1.0 band{b:.2f}",dict(tail=False,hold=True,band=b,mtilt=False,conv_z=1.0)) for b in (0.0,0.20)])

def main():
    days=sorted(int(p.name) for p in NPZ.iterdir() if p.name.isdigit() and (p/"X.npy").exists())
    folds=[]; i=0
    while i+NTR+NTE<=len(days):
        folds.append((days[i:i+NTR],days[i+NTR:i+NTR+NTE])); i+=STEP
    print(f"{len(folds)} folds; y_{H} ann={ann:.1f}; tier4 DROPPED; BTC excl; MODEL={PREF}; K={K} band={BAND}\n",flush=True)
    agg={n:{c:[] for c in COSTS} for n,_ in LADDER}; turns={n:[] for n,_ in LADDER}
    for k,(tr,te) in enumerate(folds):
        ck=EXP/f"diagnostic_{PREF}_f{k}/best.pt"
        if not ck.exists(): print(f"  fold{k}: no ckpt — skip",flush=True); continue
        sigma=frozen_sigma(tr)[:]   # (10,) frozen train idio vol
        Xs,Xq,Yw,Vw=load_seq(dr(te[0],te[-1]),H,10,60,raw_lob=True,horizon=H)
        if Xs is None: print(f"  fold{k}: no OOS",flush=True); continue
        Xs,Xq=dt4(Xs,Xq)
        model=CSRankerSeq(Xs.shape[-1],Xq.shape[-1],d=320,layers=6,use_lobcnn=True,use_lobtemporal=True,
            per_asset_film=True,cross_asset=True,split_mag=True,temporal_transformer=True,transformer_layers=2).to(device)
        model.load_state_dict(torch.load(ck,map_location=device),strict=False)
        rk,mg=predict(model,Xs,Xq); rkU=rk[:,UNIV10]; mgU=mg[:,UNIV10]; yU=Yw[:,UNIV10]
        line=f"  f{k} {te[0]}: "
        for n,kw in LADDER:
            gs,nets,turn=run(rkU,mgU,yU,sigma,K,costs=COSTS,ann=ann,**kw)
            for c in COSTS: agg[n][c].append(nets[c]);
            turns[n].append(turn)
            if n in ("conv z1.0 hold","conv z0.8 hold"): line+=f"{n}[@2bp={nets[2]:+.2f}/@1bp={nets[1]:+.2f}] "
        print(line,flush=True)
    print("\n=== ABLATION LADDER — AGG net Sharpe (mean across folds), @cost(pos/8) ===",flush=True)
    for n,_ in LADDER:
        row=" ".join(f"@{c}={np.mean(agg[n][c]):+.2f}({int((np.array(agg[n][c])>0).sum())}/{len(agg[n][c])})" for c in COSTS)
        print(f"  {n:20s} turn={np.mean(turns[n]):.2f}: {row}",flush=True)
    print("\nKEEP a lever only if Δnet@1bp>+0.005 in >=6/8 folds. Headline @2bp(mission) + @1bp(maker-ish). Taker 4.5bp/side = DEAD.",flush=True)

if __name__=="__main__":
    main()
