"""Phase 15-B3 result recovery: re-evaluate the trained fusion checkpoints directly.

The training run's stdout log was unlinked by shared-box disk pressure, so the final summary may be lost
on process exit. This reconstructs the covered-only GO signal by loading each config's best.pt and
re-running evaluate_fusion on the eval window. Eval-window preload only (~2min); the model carries
hmed/hmad as buffers; Pearson is scale-invariant so ymad/ymed are set to 1/0 (relative GO signal is exact;
absolute beta/sigR are not meaningful here). btc per-channel norm uses train-range stats from the stream
index (the 3 configs share the same eval btc, so the base-vs-q50-vs-multilag comparison is robust to it).

Usage (cwd = multi-asset repo):
  python scripts/eval_fusion_ckpts.py --tag rl3fuse1 --configs base,q50,multilag
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch
from train_rawlob3 import preload, LOBNet3, FALL, S, dev
from train_rawlob3_fusion import build_btc_index, attach_btc, evaluate_fusion, CONFIGS
from train_cs_ranker import UNIV10, UNIV_NAMES, dr, set_seed

EXP = Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="rl3fuse1"); ap.add_argument("--configs", default="base,q50,multilag")
    ap.add_argument("--fold", type=int, default=1)
    ap.add_argument("--train_start", type=int, default=20231201); ap.add_argument("--train_end", type=int, default=20250418)  # for btc norm stats
    ap.add_argument("--eval_start", type=int, default=20250419); ap.add_argument("--eval_end", type=int, default=20250518)
    ap.add_argument("--win", type=int, default=600); ap.add_argument("--sub", type=int, default=1)
    ap.add_argument("--d", type=int, default=96); ap.add_argument("--max_gap_s", type=int, default=600)
    ap.add_argument("--pre_temporal", action="store_true"); ap.add_argument("--use_flow", action="store_true"); ap.add_argument("--per_asset", action="store_true")
    ap.add_argument("--temporal", default="conv", choices=["conv", "transformer"]); ap.add_argument("--n_tlayers", type=int, default=2)
    ap.add_argument("--btc_scramble", action="store_true"); ap.add_argument("--btc_shift_s", type=int, default=0)  # eval-time leak/causality controls
    ap.add_argument("--btc_stream_dir", default=None)  # override stream source (e.g. full-day rebuild) to preview full coverage
    a = ap.parse_args(); set_seed(42)
    want = [c.strip() for c in a.configs.split(",") if c.strip()]
    if a.btc_stream_dir:
        import train_rawlob3_fusion as _trf
        print(f"[btc] eval stream override -> {a.btc_stream_dir} (norm stats still from the ORIGINAL training stream)", flush=True)
    rl_ev, sm_ev = preload(dr(a.eval_start, a.eval_end), a.win, 600)
    import datetime as dt
    import train_rawlob3_fusion as _trf
    Kmax = max(CONFIGS[c]["K"] for c in want)
    # btc per-channel robust-z: ALWAYS from the ORIGINAL training stream's train-range (the stats the model trained with)
    _orig = _trf.BTC_STREAM
    _trf.BTC_STREAM = Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/btc_stream")
    ts0, vec0 = build_btc_index(a.fold)
    daynum0 = np.array([int(dt.datetime.fromtimestamp(int(t), dt.timezone.utc).strftime("%Y%m%d")) for t in ts0])
    tv = vec0[(daynum0 >= a.train_start) & (daynum0 <= a.train_end)]
    bmed = np.median(tv, 0); bmad = 1.4826 * np.median(np.abs(tv - bmed), 0) + 1e-6
    bmad = np.where(bmad > 1e-9, bmad, 1.0)
    # eval attach: from the override stream if given (full-day preview), else original
    _trf.BTC_STREAM = Path(a.btc_stream_dir) if a.btc_stream_dir else _orig
    btc_ts, btc_vec = build_btc_index(a.fold)
    bt_ev, cov = attach_btc(sm_ev, btc_ts, btc_vec, Kmax, a.max_gap_s, shift_s=a.btc_shift_s, scramble=a.btc_scramble)
    if a.btc_scramble or a.btc_shift_s: print(f"[CONTROL] scramble={a.btc_scramble} shift_s={a.btc_shift_s} -> covMEAN_ALT should collapse toward base if the lift is real aligned-BTC signal", flush=True)
    cov_ev = np.any(bt_ev != 0, axis=(1, 2))
    print(f"[eval] {len(sm_ev)} samples, coverage {cov:.3f}", flush=True)
    ymad = np.ones((1, S), np.float32); ymed = np.zeros((1, S), np.float32)

    def norm(b, zero_h):
        bn = np.where(np.any(b != 0, -1, keepdims=True), np.clip((b - bmed) / bmad, -8, 8), 0.0).astype(np.float32)
        if zero_h: bn = bn.copy(); bn[..., :32] = 0.0
        return bn

    R, Rc = {}, {}
    for name in want:
        cfg = CONFIGS[name]; use_f = cfg["use_btc_fusion"]; K = cfg["K"]
        m = LOBNet3(np.zeros(FALL, np.float32), np.ones(FALL, np.float32), d=a.d, use_lob=True,
                    pre_temporal=a.pre_temporal, use_flow=a.use_flow, per_asset=a.per_asset,
                    use_btc_fusion=use_f, btc_lags=K, temporal=a.temporal, n_tlayers=a.n_tlayers).to(dev)
        sd = torch.load(EXP / f"diagnostic_{a.tag}_{name}" / "best.pt", map_location=dev)
        m.load_state_dict(sd)
        if use_f: m.warmup.fill_(1.0)
        bev = norm(bt_ev[:, :K], cfg["zero_hpred"]) if use_f else None
        res, res_cov = evaluate_fusion(m, sm_ev, rl_ev, a.win, a.sub, bev, ymad, ymed, cov_mask=cov_ev)
        R[name] = res; Rc[name] = res_cov
        print(f"  [{name}] loaded + evaluated", flush=True)

    ALT = [x for x in UNIV10 if x != 0]
    print(f"\n===== rl3fuse1 RE-EVAL (OOS {a.eval_start}->{a.eval_end}, cov={cov:.3f}) =====", flush=True)
    print("  asset " + "".join(f"{n:>12s}" for n in want), flush=True)
    for x in UNIV10:
        row = f"  {UNIV_NAMES[x]:5s}"
        for n in want: row += f"{(R[n].get(x,(np.nan,))[0]):>+12.4f}"
        print(row, flush=True)
    print("  " + "-" * (7 + 12 * len(want)), flush=True)

    def mrow(label, dct, sel):
        row = f"  {label:14s}"
        for n in want:
            d = dct[n]; vals = [d[x][0] for x in sel if d and x in d]
            row += f"{(np.nanmean(vals) if vals else np.nan):>+12.4f}"
        print(row, flush=True)
    mrow("MEAN_ALT(full)", R, ALT); mrow("BTC(full)", R, [0])
    mrow("covMEAN_ALT", Rc, ALT); mrow("covBTC", Rc, [0])
    print("  GO if covMEAN_ALT[multilag] >> [base] AND >> [q50-control]", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
