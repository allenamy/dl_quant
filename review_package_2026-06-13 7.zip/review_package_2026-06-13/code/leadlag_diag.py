import numpy as np, json, datetime as dt
from pathlib import Path

NPZ = Path("data/npz_v23_400d_mmap")
FN = json.load(open(NPZ / "_meta.json"))["feature_names"]
FIDX = {f: i for i, f in enumerate(FN)}
LR = FIDX["log_return_1s"]

BTC, ETH = 0, 1
ALTS = {2: "SOL", 12: "FIL", 13: "ETC", 4: "XRP", 5: "DOG"}


def dr(a, b):
    s = dt.date(a // 10000, (a // 100) % 100, a % 100)
    e = dt.date(b // 10000, (b // 100) % 100, b % 100)
    o = []
    d = s
    while d <= e:
        o.append(d.year * 10000 + d.month * 100 + d.day)
        d += dt.timedelta(days=1)
    return o


# lead-lag: correlate BTC return at t with alt return at t+k. Positive k => BTC leads alt.
# Use a coarser return horizon (30s aggregated) to reduce 1s noise, sampled densely.
LAGS = [-120, -60, -30, -10, 0, 10, 30, 60, 120, 300]
AGG = 30  # aggregate returns over 30s windows


def day_series(d, asset):
    xp = NPZ / str(d) / "X.npy"
    if not xp.exists():
        return None
    X = np.load(xp, mmap_mode="r")
    r = np.asarray(X[:, asset, LR], np.float32)  # (T,)
    return r


def agg_ret(r, w):
    # rolling sum of log returns over window w, step 1
    c = np.cumsum(np.insert(r, 0, 0.0))
    return c[w:] - c[:-w]  # (T-w,)


def leadlag_for_alt(dates, alt):
    # accumulate cross-products across days at each lag
    out = {k: [] for k in LAGS}
    for d in dates:
        rb = day_series(d, BTC)
        ra = day_series(d, alt)
        if rb is None or ra is None:
            continue
        rb = np.nan_to_num(rb)
        ra = np.nan_to_num(ra)
        ab = agg_ret(rb, AGG)
        aa = agg_ret(ra, AGG)
        n = min(len(ab), len(aa))
        ab = ab[:n]
        aa = aa[:n]
        for k in LAGS:
            if k >= 0:
                x = ab[: n - k]
                y = aa[k:]
            else:
                x = ab[-k:]
                y = aa[: n + k]
            out[k].append(np.stack([x, y]))
    res = {}
    for k in LAGS:
        M = np.concatenate(out[k], axis=1)
        x, y = M[0], M[1]
        x = x - x.mean()
        y = y - y.mean()
        s = np.sqrt((x * x).sum() * (y * y).sum())
        res[k] = float((x * y).sum() / s) if s > 0 else 0.0
    return res


TRAIN = dr(20240401, 20240430)  # 30 days enough for lead-lag corr
print("AGG window", AGG, "s; lag k>0 => BTC return_t vs alt return_{t+k} (BTC leads)")
for alt, nm in ALTS.items():
    res = leadlag_for_alt(TRAIN, alt)
    best_k = max(res, key=lambda k: res[k])
    print(
        "BTC->%s:" % nm,
        " ".join("k=%+d:%.3f" % (k, res[k]) for k in LAGS),
        "| peak@k=%+d" % best_k,
    )
print("DONE_LEADLAG")
