"""E147: TEMPORAL CS-ranker — the DL edge GBDT structurally cannot use.

GBDT (0.0587) and the snapshot MLP (E144 0.0439) both see only ONE frame per sample.
This adds a per-asset temporal encoder over a downsampled 600s lookback of the
cross-sectionally-normalized features (captures order-flow trajectory / momentum-in-CS),
fused with IDENTITY-INIT gating onto the proven E144 two-head snapshot MLP: the model
STARTS as E144 (alpha_t=0 -> temporal contributes 0) and learns the temporal increment.
Guard vs E140/E141: the temporal encoder is PER-ASSET (no cross-asset mixing), so it
cannot flatten within-snapshot variance -> LambdaRank stays alive.

Usage: python scripts/train_cs_ranker_seq.py --tag e147_seq --epochs 60 --L 10 --step 60
"""
from __future__ import annotations
import argparse, time, sys, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from scipy.stats import rankdata
from train_cs_ranker import (NPZ, UNIV10, UNIV_NAMES, H, S, TRAIN, WINDOWS, set_seed, dr,
                              lambdarank_loss, huber_demean)

def _csz(X):  # per-snapshot cross-asset z-score over S axis (axis=-2). X (...,S,F)
    m=np.nanmean(np.where(np.isfinite(X),X,np.nan),-2,keepdims=True)
    sd=np.nanstd(np.where(np.isfinite(X),X,np.nan),-2,keepdims=True)+1e-6
    return np.nan_to_num((X-m)/sd,nan=0.0)
RAWNORM=False  # RAW-prediction mode: global-z inputs (preserve market) + per-asset MAD-z target (anti σ-collapse)
CAUSALNORM=False  # frozen TRAIN per-(asset,feature) stats (no intra-day look-ahead; matches single-asset global MAD-z)
REVIN=False       # per-window RevIN (causal+adaptive input norm, the single-asset-proven ingredient)
GSTATS=None       # (gmean,gstd) shape (S,F) frozen from TRAIN when CAUSALNORM; else per-call/per-day (look-ahead)
def _gz(X):  # per-(asset,feature) z. CAUSAL: frozen TRAIN stats (GSTATS). Else per-day axis-0 stats (intra-day LOOK-AHEAD).
    if GSTATS is not None:
        gm,gs=GSTATS; return np.nan_to_num(np.clip((X-gm)/gs,-10,10),nan=0.0)  # (S,F) broadcasts against (...,S,F)
    m=np.nanmean(np.where(np.isfinite(X),X,np.nan),0,keepdims=True); sd=np.nanstd(np.where(np.isfinite(X),X,np.nan),0,keepdims=True)+1e-6
    return np.nan_to_num(np.clip((X-m)/sd,-10,10),nan=0.0)
def compute_gstats(dates,stride,L,step,horizon,idio_target):  # frozen global per-(asset,feature) mean/std over TRAIN snapshots (causal)
    off=(L-1)*step; tot=tot2=cnt=None
    for d in dates:
        xp=NPZ/str(d)/"X.npy"; yp=NPZ/str(d)/(f"y_{horizon}_idio.npy" if idio_target else f"y_{horizon}.npy")
        if not xp.exists() or not yp.exists(): continue
        Xf=np.asarray(np.load(xp,mmap_mode="r"),np.float32); T=Xf.shape[0]; idx=np.arange(off,T-horizon,stride)
        if len(idx)==0: continue
        cur=np.where(np.isfinite(Xf[idx]),Xf[idx],np.nan)
        s=np.nansum(cur,0); s2=np.nansum(cur*cur,0); c=np.sum(np.isfinite(cur),0)
        tot=s if tot is None else tot+s; tot2=s2 if tot2 is None else tot2+s2; cnt=c if cnt is None else cnt+c
    cnt=np.maximum(cnt,1); gm=tot/cnt; gs=np.sqrt(np.maximum(tot2/cnt-gm*gm,1e-12))+1e-6
    return gm.astype(np.float32),gs.astype(np.float32)

def ccc_loss(s,y,valid):  # Lin's CCC: pushes mean->mean, var->var (beta->1), corr up. 1-CCC to minimize.
    m=valid.float(); n=m.sum().clamp(min=1.0)
    mp=(s*m).sum()/n; my=(y*m).sum()/n
    vp=(((s-mp)**2)*m).sum()/n; vy=(((y-my)**2)*m).sum()/n
    cov=(((s-mp)*(y-my))*m).sum()/n
    return 1.0-2.0*cov/(vp+vy+(mp-my)**2+1e-8)

class DAQHHead(nn.Module):  # per-asset sign·magnitude quantile head (single-asset REG_arch DAQH transfer; zero-init q50=0)
    def __init__(self,d,dropout=0.1,min_delta=0.01):
        super().__init__()
        def mlp(): return nn.Sequential(nn.Linear(d,d//2),nn.GELU(),nn.Dropout(dropout),nn.Linear(d//2,1))
        self.sign=mlp(); self.magp=mlp(); self.dlo=mlp(); self.dhi=mlp(); self.min_delta=float(min_delta)
        for p in (self.sign,self.magp): nn.init.zeros_(p[-1].weight); nn.init.zeros_(p[-1].bias)  # q50 starts 0, no dir bias
    def forward(self,h):  # h (B,S,d) -> q50,sign_logit,mag_abs,q10,q90 each (B,S)
        sl=self.sign(h).squeeze(-1); ma=F.softplus(self.magp(h).squeeze(-1)); q50=torch.tanh(sl)*ma
        dlo=F.softplus(self.dlo(h).squeeze(-1))+self.min_delta; dhi=F.softplus(self.dhi(h).squeeze(-1))+self.min_delta
        return q50,sl,ma,q50-dlo,q50+dhi
def pinball_loss(q,y,valid):  # q (B,S,3) quantiles [q10,q50,q90], y (B,S)
    taus=torch.tensor([0.1,0.5,0.9],device=q.device,dtype=q.dtype); err=y.unsqueeze(-1)-q
    l=torch.max(taus*err,(taus-1.0)*err); m=valid.float().unsqueeze(-1)
    return (l*m).sum()/(m.sum()*3.0).clamp(min=1.0)
def mag_focal_huber(mag_abs,y,valid,delta=1.0,gamma=1.0):  # predict |y| via Huber, upweight large-|y| (REG_arch mag_focal)
    ay=y.abs(); diff=mag_abs-ay; ad=diff.abs()
    hub=torch.where(ad<=delta,0.5*diff*diff,delta*(ad-0.5*delta)); w=(1.0+ay).pow(gamma); m=valid.float()
    return (hub*w*m).sum()/(w*m).sum().clamp(min=1.0)
def tail_focal_bce(sign_logit,y,valid,thr=0.5,gamma=1.5):  # BCE on sign, weighted only on tails |y|>thr (REG_arch tail_focal_1p5)
    tgt=(y>0).float(); bce=F.binary_cross_entropy_with_logits(sign_logit,tgt,reduction='none')
    w=y.abs().clamp(max=5.0).pow(gamma)*(y.abs()>thr).float()+1e-3; m=valid.float()
    return (bce*w*m).sum()/(w*m).sum().clamp(min=1.0)

RAWLOB=list(range(71,89))+list(range(89,109))  # 38 raw-LOB cols: cumu(18)+detail(20), scale-preserved
# MULTI-RATE: when temporal runs at FINE step, feed it only the 1s-native FAST families (slow
# families are autocorr~1 -> finer = noise). Indices in the Fseq=150 space (112 cs-z + 38 raw-LOB):
# tier1(0-7) + tier3 OFI(24-29) + tier10 VPIN/Kyle(109-111) cs-z + raw-LOB raw(112-149).
FASTSEQ_IDX=[0,1,2,3,4,5,6,7,24,25,26,27,28,29,109,110,111]+list(range(112,150))  # 55 fast channels
import hashlib
SEQCACHE=NPZ.parent/"seqcache"  # cache final windowed arrays per config: reading ~3GB cache >> 208GB raw days (~70x less I/O on the shared disk)
def load_seq(dates,stride,L,step,raw_lob=False,raw_target=False,horizon=600,idio_target=False,rank_horizon=None,fine_lob=False,fine_L=60,fine_step=1,aux_horizons=None):
    """Xsnap (N,S,2F), Xseq (N,L,S,F[+38]), Yd (N,S) [main horizon], valid. If rank_horizon set, ALSO returns
    Yshort (N,S) = raw y at rank_horizon, SAME idx -> for a SHORT-horizon idio-rank head (dual-horizon multi-head)."""
    dk=hashlib.md5((",".join(str(d) for d in dates)).encode()).hexdigest()[:12]
    ck=SEQCACHE/f"{dk}_s{stride}_L{L}_st{step}_rl{int(raw_lob)}_rt{int(raw_target)}_h{horizon}_id{int(idio_target)}_rh{rank_horizon or 0}_fl{int(fine_lob)}_fL{fine_L}_fs{fine_step}_ah{"-".join(map(str,aux_horizons)) if aux_horizons else 0}_rn{int(RAWNORM)}_cn{int(CAUSALNORM)}_rv{int(REVIN)}.npz"
    if ck.exists():
        try:
            z=np.load(ck); print(f"  [seqcache HIT] {ck.name}",flush=True)
            if aux_horizons: return z["Xsnap"],z["Xseq"],z["Yd"],z["valid"],z["Yaux"]
            if fine_lob: return z["Xsnap"],z["Xseq"],z["Yd"],z["valid"],z["Xfine"]
            if rank_horizon: return z["Xsnap"],z["Xseq"],z["Yd"],z["valid"],z["Yshort"]
            return z["Xsnap"],z["Xseq"],z["Yd"],z["valid"]
        except Exception as e: print(f"  [seqcache corrupt, rebuild] {e}",flush=True)
    snap,seq,Ys,Yss,fine,auxL=[],[],[],[],[],[]
    off=max((L-1)*step,(fine_L-1)*fine_step) if fine_lob else (L-1)*step
    for d in dates:
        xp,yp=NPZ/str(d)/"X.npy",NPZ/str(d)/(f"y_{horizon}_idio.npy" if idio_target else f"y_{horizon}.npy")
        if not xp.exists() or not yp.exists(): continue
        ysp=NPZ/str(d)/f"y_{rank_horizon}.npy" if rank_horizon else None
        if rank_horizon and not ysp.exists(): continue
        Xf=np.asarray(np.load(xp,mmap_mode="r"),np.float32)     # full day -> RAM ONCE (sequential, fast)
        Y=np.load(yp,mmap_mode="r");T=Xf.shape[0]
        idx=np.arange(off,T-horizon,stride)
        if len(idx)==0: continue
        cur=Xf[idx]                                             # (n,S,F) in-RAM slice
        sq=np.stack([Xf[idx-(L-1-j)*step] for j in range(L)],1) # (n,L,S,F) in-RAM, no scattered mmap reads
        if RAWNORM and REVIN:  # per-window RevIN: normalize by the L-window's OWN per-(asset,feature) mean/std — CAUSAL (window=[t-(L-1)step..t]) + ADAPTIVE to local regime, no look-ahead
            sqf=np.where(np.isfinite(sq),sq,np.nan)
            wm=np.nanmean(sqf,1,keepdims=True); ws=np.nanstd(sqf,1,keepdims=True)+1e-6  # (n,1,S,F) trailing window stats
            sqz=np.nan_to_num(np.clip((sq-wm)/ws,-10,10),nan=0.0); curz=sqz[:,L-1]  # cur = last window timestep, normed by same window
        else:
            curz=(_gz(cur) if RAWNORM else _csz(cur)); sqz=(_gz(sq) if RAWNORM else _csz(sq))  # global-z (raw) / per-day (look-ahead) / cs-z
        snap.append(np.concatenate([np.nan_to_num(cur,nan=0.0),curz],-1))  # (n,S,2F)
        if raw_lob: sqz=np.concatenate([sqz,np.nan_to_num(sq[...,RAWLOB])],-1)  # + raw scale-preserved LOB ladder over time
        seq.append(sqz)
        if fine_lob: fine.append(np.stack([np.nan_to_num(Xf[idx-(fine_L-1-j)*fine_step][...,RAWLOB]) for j in range(fine_L)],1).astype(np.float32))  # (n,fine_L,S,38) per-second 1s LOB ladder
        Ys.append(np.asarray(Y[idx],np.float32))
        if aux_horizons:
            ax=[np.asarray(np.load(NPZ/str(d)/f"y_{ah}.npy",mmap_mode="r")[idx],np.float32) if (NPZ/str(d)/f"y_{ah}.npy").exists() else np.full((len(idx),Xf.shape[1]),np.nan,np.float32) for ah in aux_horizons]
            auxL.append(np.stack(ax,-1))  # (n,S,nAux) raw y at each aux horizon, same idx
        if rank_horizon: Yss.append(np.asarray(np.load(ysp,mmap_mode="r")[idx],np.float32))  # short-horizon y, same idx
    if not snap: return (None,)*(5 if (rank_horizon or fine_lob or aux_horizons) else 4)
    Xsnap=np.concatenate(snap); Xseq=np.concatenate(seq); Y=np.concatenate(Ys)
    if raw_target or idio_target:
        Yd=Y; valid=np.isfinite(Y)                          # raw y, OR pre-neutralized beta-idio (no further demean)
        if RAWNORM:  # per-asset MAD-z target (σ_y->1) — single-asset trick that prevents Huber σ-collapse
            yv=np.where(valid,Yd,np.nan); med=np.nanmedian(yv,0,keepdims=True); mad=1.4826*np.nanmedian(np.abs(yv-med),0,keepdims=True)+1e-9
            Yd=np.clip((Yd-med)/mad,-5.0,5.0)
    else:
        ym=np.nanmean(np.where(np.isfinite(Y),Y,np.nan),1,keepdims=True)
        Yd=Y-ym; valid=np.isfinite(Yd)                      # CS-demeaned idio (rank)
    Xsnap=Xsnap.astype(np.float32);Xseq=Xseq.astype(np.float32);Yd=np.nan_to_num(Yd,nan=0.0).astype(np.float32)
    Yshort=np.nan_to_num(np.concatenate(Yss),nan=0.0).astype(np.float32) if rank_horizon else None  # raw short y; demean in loss/eval
    Xfine=np.concatenate(fine).astype(np.float32) if fine_lob else None
    Yaux=np.nan_to_num(np.concatenate(auxL),nan=0.0).astype(np.float32) if aux_horizons else None
    try:  # write cache atomically (tmp -> rename) so future runs of this config skip the 208GB raw read
        SEQCACHE.mkdir(parents=True,exist_ok=True); tmp=ck.with_suffix(".tmp.npz")
        if aux_horizons: np.savez(tmp,Xsnap=Xsnap,Xseq=Xseq,Yd=Yd,valid=valid,Yaux=Yaux)
        elif fine_lob: np.savez(tmp,Xsnap=Xsnap,Xseq=Xseq,Yd=Yd,valid=valid,Xfine=Xfine)
        elif rank_horizon: np.savez(tmp,Xsnap=Xsnap,Xseq=Xseq,Yd=Yd,valid=valid,Yshort=Yshort)
        else: np.savez(tmp,Xsnap=Xsnap,Xseq=Xseq,Yd=Yd,valid=valid)
        tmp.rename(ck); print(f"  [seqcache WROTE] {ck.name}",flush=True)
    except Exception as e: print(f"  [seqcache write fail] {e}",flush=True)
    if aux_horizons: return Xsnap,Xseq,Yd,valid,Yaux
    if fine_lob: return Xsnap,Xseq,Yd,valid,Xfine
    if rank_horizon: return Xsnap,Xseq,Yd,valid,Yshort
    return Xsnap,Xseq,Yd,valid

class LOBCNN(nn.Module):
    """Structured raw-LOB encoder (DeepLOB-style): convolve over the LEVEL axis of the
    bid/ask ladder to model micro-adversarial book geometry that flat features destroy.
    DETAIL = cols 89..108 of raw-112 -> (5 levels, 4 ch=[ask_dbps,ask_logsz,bid_dbps,bid_logsz]).
    CUMU   = cols 71..88            -> (9 depths, 2 ch=[asksz,bidsz]). Uses RAW (un-norm) values
    so cross-level scale (the ladder shape) is preserved; per-block LayerNorm stabilizes."""
    DET=list(range(89,109)); CUM=list(range(71,89))
    def __init__(self,d,dropout=0.3):
        super().__init__()
        self.dnorm=nn.LayerNorm(20); self.cnorm=nn.LayerNorm(18)
        self.dconv=nn.Sequential(nn.Conv1d(4,16,2),nn.GELU(),nn.Conv1d(16,16,2),nn.GELU())  # over 5 levels
        self.cconv=nn.Sequential(nn.Conv1d(2,8,2),nn.GELU(),nn.Conv1d(8,8,2),nn.GELU())     # over 9 depths
        self.proj=nn.Sequential(nn.Linear(24,d),nn.Dropout(dropout)); self.norm=nn.LayerNorm(d)
        self.alpha=nn.Parameter(torch.zeros(1))
    def forward(self,h,xraw):  # h (B,S,d); xraw (B,S,112) raw feature half
        B,S,_=xraw.shape
        det=self.dnorm(torch.nan_to_num(xraw[...,self.DET])).reshape(B*S,5,4).permute(0,2,1)  # (BS,4,5)
        cum=self.cnorm(torch.nan_to_num(xraw[...,self.CUM])).reshape(B*S,9,2).permute(0,2,1)  # (BS,2,9)
        e=torch.cat([self.dconv(det).mean(-1),self.cconv(cum).mean(-1)],-1)                   # (BS,24)
        e=self.norm(self.proj(e)).reshape(B,S,-1)
        return h+torch.tanh(self.alpha)*e

class LOBTemporalCNN(nn.Module):
    """Full DeepLOB-style: conv over (TIME x ladder-LEVEL) of the raw-LOB sequence.
    Operates on the last 38 dims of Xseq (raw LOB appended by --raw_lob_seq): cumu(18)=9depth×2,
    detail(20)=5level×4ch. Conv2d over (L_time, level) captures how the book SHAPE evolves —
    the micro-adversarial dynamics flat features + per-frame CNN both miss. Identity-init gated."""
    def __init__(self,d,dropout=0.3,attnpool=False):
        super().__init__()
        self.attnpool=attnpool
        self.cconv=nn.Sequential(nn.Conv2d(2,8,(3,2)),nn.GELU())     # (time,depth) -> grid
        self.dconv=nn.Sequential(nn.Conv2d(4,16,(3,2)),nn.GELU())    # (time,level) -> grid
        if attnpool:                                                 # attention-pool over the (time x level) grid (vs avg crush)
            self.cw=nn.Linear(8,1); self.dw=nn.Linear(16,1)
        else:
            self.cpool=nn.AdaptiveAvgPool2d(1); self.dpool=nn.AdaptiveAvgPool2d(1)
        self.proj=nn.Sequential(nn.Linear(24,d),nn.Dropout(dropout)); self.norm=nn.LayerNorm(d)
        self.alpha=nn.Parameter(torch.zeros(1))
    def _pool(self,x,w):  # x (BS,C,H,W) -> (BS,C) via learned attention over H*W grid positions
        B,C,H,W=x.shape; xf=x.flatten(2).transpose(1,2)             # (BS,HW,C)
        a=torch.softmax(w(xf).squeeze(-1),1)                        # (BS,HW)
        return (xf*a.unsqueeze(-1)).sum(1)                          # (BS,C)
    def forward(self,h,rawlob):  # rawlob (B,L,S,38) = cumu18 + detail20
        B,L,Sn,_=rawlob.shape
        cum=rawlob[...,:18].reshape(B,L,Sn,9,2).permute(0,2,4,1,3).reshape(B*Sn,2,L,9)   # (BS,2,L,9)
        det=rawlob[...,18:].reshape(B,L,Sn,5,4).permute(0,2,4,1,3).reshape(B*Sn,4,L,5)   # (BS,4,L,5)
        if self.attnpool:
            e=torch.cat([self._pool(self.dconv(det),self.dw),self._pool(self.cconv(cum),self.cw)],-1)
        else:
            e=torch.cat([self.dpool(self.dconv(det)).reshape(B*Sn,16),self.cpool(self.cconv(cum)).reshape(B*Sn,8)],-1)
        e=self.norm(self.proj(e)).reshape(B,Sn,-1)
        return h+torch.tanh(self.alpha)*e

class LeadLag(nn.Module):
    """Asymmetric BTC/ETH lead-lag. ALL assets QUERY the leaders (BTC=0,ETH=1) as K/V.
    Each asset's query is its OWN state -> attention output differs per asset -> within-
    snapshot variance preserved (the E140/E141 collapse came from SYMMETRIC mixing that
    flattened scores to a per-snapshot constant). Identity-init gated (alpha=0)."""
    def __init__(self,d,leaders=(0,1),heads=4,dropout=0.3):
        super().__init__()
        self.leaders=list(leaders)
        self.attn=nn.MultiheadAttention(d,heads,dropout=dropout,batch_first=True)
        self.norm=nn.LayerNorm(d); self.alpha=nn.Parameter(torch.zeros(1))
    def forward(self,h):  # h (B,S,d)
        kv=h[:,self.leaders]                       # (B,n_lead,d) market-context leaders
        a,_=self.attn(h,kv,kv)                     # each asset attends to leaders only
        return h+torch.tanh(self.alpha)*self.norm(a)

class CrossAssetAttn(nn.Module):
    """Within-snapshot cross-asset attention (S=14 asset-tokens) — the RIGHT structure for
    cross-sectional ranking, but naive versions ln2-COLLAPSED (within-snapshot variance->0).
    THIS time guarded by an explicit variance-floor penalty in the loss (see train loop).
    Gated identity-init (alpha=0 -> off at start)."""
    def __init__(self,d,heads=4,dropout=0.3,n_layers=1,per_asset_gate=False,S=14):
        super().__init__()
        self.attn=nn.ModuleList([nn.MultiheadAttention(d,heads,dropout=dropout,batch_first=True) for _ in range(n_layers)])
        self.norm=nn.ModuleList([nn.LayerNorm(d) for _ in range(n_layers)])
        self.ff=nn.ModuleList([nn.Sequential(nn.Linear(d,2*d),nn.GELU(),nn.Dropout(dropout),nn.Linear(2*d,d)) for _ in range(n_layers)])
        self.ffn=nn.ModuleList([nn.LayerNorm(d) for _ in range(n_layers)])
        # PER-ASSET gate: leaders (BTC) contribute as K/V but gate their OWN residual -> 0 (keep
        # per-asset signal), followers absorb the cross-section. Asymmetric lead-lag for free.
        self.alpha=nn.Parameter(torch.zeros(S if per_asset_gate else 1))
    def forward(self,h):  # h (B,S,d) — assets as tokens within snapshot
        e=h
        for attn,n1,ff,n2 in zip(self.attn,self.norm,self.ff,self.ffn):
            a,_=attn(e,e,e); e=n1(e+a); e=n2(e+ff(e))
        return h+torch.tanh(self.alpha).view(1,-1,1)*(e-h)   # gated residual (identity-init alpha=0; per-asset or scalar)

class FMInteraction(nn.Module):
    """Low-rank Factorization-Machine 2nd-order feature interactions (the GBDT-gap lever).
    fm_k = 0.5*((xV)^2 - (x^2)(V^2)) captures ALL pairwise feature crosses in rank-k form —
    inherently regularized (unlike free GDCN which overfit, E146). Per-asset (last-dim only,
    no cross-asset -> no ln2-collapse). Identity-init gated (alpha=0 -> off at start)."""
    def __init__(self,Fin,d,k=16,dropout=0.4):
        super().__init__()
        self.V=nn.Parameter(torch.randn(Fin,k)*0.01)
        self.proj=nn.Sequential(nn.Linear(k,d),nn.Dropout(dropout)); self.norm=nn.LayerNorm(d)
        self.alpha=nn.Parameter(torch.zeros(1))
    def forward(self,h,x):  # h (B,S,d); x (B,S,Fin) raw input
        xv=x@self.V; x2v2=(x*x)@(self.V*self.V)
        fm=0.5*(xv*xv-x2v2)                                  # (B,S,k) pairwise interactions
        return h+torch.tanh(self.alpha)*self.norm(self.proj(fm))

class RegimeMoE(nn.Module):
    """Regime-conditional Mixture-of-Experts: an INPUT-dependent gate routes each
    (sample,asset) state to a soft mixture of E expert MLPs, so different market REGIMES
    use different computation (P6 regime-awareness; the LLM/recsys MoE paradigm). Unlike
    PerAssetFiLM (fixed per-asset affine) the routing is STATE-dependent. Identity-init
    gated (alpha=0 -> off at start); load-balance via gate entropy is left to SGD."""
    def __init__(self,d,n_exp=4,dropout=0.3):
        super().__init__()
        self.experts=nn.ModuleList([nn.Sequential(nn.Linear(d,d),nn.GELU(),nn.Dropout(dropout),nn.Linear(d,d)) for _ in range(n_exp)])
        self.gate=nn.Linear(d,n_exp); self.norm=nn.LayerNorm(d); self.alpha=nn.Parameter(torch.zeros(1))
    def forward(self,h):  # h (B,S,d)
        w=torch.softmax(self.gate(h),-1)                     # (B,S,E) state-dependent routing
        outs=torch.stack([e(h) for e in self.experts],-1)    # (B,S,d,E)
        moe=(outs*w.unsqueeze(2)).sum(-1)                    # (B,S,d) soft mixture
        return h+torch.tanh(self.alpha)*self.norm(moe)

class PerAssetFiLM(nn.Module):
    """Per-asset gamma/beta from a learned per-asset embedding — re-introduces ASSET
    SPECIALIZATION into the shared channel-independent encoder (E156: shared encoder
    can't specialize -> BTC raw-P 0.009 vs single-asset 0.067). Identity-init: gamma=1,
    beta=0 -> z unchanged at init, learns per-asset deviation."""
    def __init__(self,S,d,emb=16):
        super().__init__()
        self.emb=nn.Embedding(S,emb)
        self.g=nn.Linear(emb,d); self.b=nn.Linear(emb,d)
        nn.init.zeros_(self.g.weight); nn.init.zeros_(self.g.bias)   # gamma=1+0
        nn.init.zeros_(self.b.weight); nn.init.zeros_(self.b.bias)   # beta=0
    def forward(self,z):  # z (B,S,d)
        e=self.emb(torch.arange(z.shape[1],device=z.device))         # (S,emb)
        return z*(1.0+self.g(e)).unsqueeze(0)+self.b(e).unsqueeze(0)

class TransformerTemporal(nn.Module):
    """Per-asset Transformer temporal encoder — the RIGHT paradigm for SSL PRETRAINING
    (masked-patch / MAE: bidirectional self-attention reconstructs masked timesteps; a GRU
    can't attend bidirectionally). The same expressivity that OVERFITS supervised-from-scratch
    (Conformer lost to GRU) becomes an ASSET once pretrained on a large unlabeled corpus.
    pool=False -> per-timestep reps (B,L,d) for SSL reconstruction; pool=True -> attention-pooled
    summary (B,d) for the ranker. inp+pos+blocks transfer; the SSL decoder is pretrain-only."""
    def __init__(self,Fin,d,heads=4,layers=2,dropout=0.3,pool=True,maxL=64):
        super().__init__()
        self.inp=nn.Linear(Fin,d); self.pos=nn.Parameter(torch.randn(1,maxL,d)*0.02)
        self.blocks=nn.ModuleList([nn.ModuleDict({
            "n1":nn.LayerNorm(d),"attn":nn.MultiheadAttention(d,heads,dropout=dropout,batch_first=True),
            "n2":nn.LayerNorm(d),"ff":nn.Sequential(nn.Linear(d,2*d),nn.GELU(),nn.Dropout(dropout),nn.Linear(2*d,d))}) for _ in range(layers)])
        self.pool=pool
        if pool: self.pq=nn.Linear(d,1)
    def forward(self,x):  # x (B,L,Fin)
        h=self.inp(x)+self.pos[:,:x.shape[1]]
        for b in self.blocks:
            hn=b["n1"](h); a,_=b["attn"](hn,hn,hn); h=h+a; h=h+b["ff"](b["n2"](h))
        if self.pool:
            w=torch.softmax(self.pq(h).squeeze(-1),1); return (h*w.unsqueeze(-1)).sum(1)  # (B,d)
        return h                                                                          # (B,L,d)

class HybridTemporal(nn.Module):
    """User's division of labor: CONV attends the NEAR-END (recent `near` frames — fast local
    microstructure bursts, where conv locality is right and matters most for the prediction point);
    TRANSFORMER attends the FULL window via PATCHES (patch_size p so L frames -> L/p tokens,
    tractable global/regime attention). Fuse both summaries. Right inductive bias per temporal
    region — the proper way to use a per-second 600s lookback."""
    def __init__(self,Fin,d,near=30,patch=5,heads=4,layers=2,dropout=0.3,maxL=600):
        super().__init__()
        self.near=near; self.patch=patch
        self.cin=nn.Linear(Fin,d); self.conv=nn.Conv1d(d,d,7,padding=6,groups=d); self.cn=nn.LayerNorm(d)  # depthwise causal, k=7
        self.pin=nn.Linear(Fin*patch,d); self.pos=nn.Parameter(torch.randn(1,maxL//patch+1,d)*0.02)
        self.blocks=nn.ModuleList([nn.ModuleDict({
            "n1":nn.LayerNorm(d),"attn":nn.MultiheadAttention(d,heads,dropout=dropout,batch_first=True),
            "n2":nn.LayerNorm(d),"ff":nn.Sequential(nn.Linear(d,2*d),nn.GELU(),nn.Dropout(dropout),nn.Linear(2*d,d))}) for _ in range(layers)])
        self.tpool=nn.Linear(d,1); self.fuse=nn.Linear(2*d,d)
    def forward(self,xs):  # xs (B, L, Fin)
        B,L,Fin=xs.shape
        near=xs[:,-self.near:,:] if L>=self.near else xs
        c=self.cin(near).transpose(1,2); c=torch.relu(self.conv(c)[...,:near.shape[1]]).mean(-1)  # (B,d) recent local summary
        c=self.cn(c)
        npn=L//self.patch
        p=xs[:,:npn*self.patch,:].reshape(B,npn,self.patch*Fin)
        h=self.pin(p)+self.pos[:,:npn]
        for b in self.blocks:
            hn=b["n1"](h); a,_=b["attn"](hn,hn,hn); h=h+a; h=h+b["ff"](b["n2"](h))
        w=torch.softmax(self.tpool(h).squeeze(-1),1); t=(h*w.unsqueeze(-1)).sum(1)              # (B,d) global
        return self.fuse(torch.cat([c,t],-1))                                                  # (B,d)

class CrossCSZ(nn.Module):
    """Low-rank DCN-V2 explicit feature-crossing — done RIGHT vs the failed GDCN(E146).
    KEY FIX: cross the cs-z HALF ONLY (scale-normalized; the raw half + its own z-score are
    near-collinear and blew GDCN up). Single cross layer, LOW-RANK W=U(V^T x) (r<=8) to
    bottleneck capacity (the E146 lesson: expressive cross overfits weak-SNR tabular). DCN-V2
    cross: x1 = x0 ⊙ (U V^T x0) + x0 -> bottlenecked 2nd-order interactions. Identity-init gated."""
    def __init__(self,Fcsz,d,r=8,dropout=0.5):
        super().__init__()
        self.V=nn.Linear(Fcsz,r,bias=False); self.U=nn.Linear(r,Fcsz)
        nn.init.zeros_(self.U.weight); nn.init.zeros_(self.U.bias)    # cross term starts 0 (x1=x0)
        self.proj=nn.Sequential(nn.Dropout(dropout),nn.Linear(Fcsz,d)); self.norm=nn.LayerNorm(d)
        self.alpha=nn.Parameter(torch.zeros(1))
    def forward(self,h,xcsz):  # h (B,S,d); xcsz (B,S,Fcsz) cs-z half only
        cross=xcsz*self.U(self.V(xcsz))+xcsz                          # low-rank DCN-V2 2nd-order cross
        return h+torch.tanh(self.alpha)*self.norm(self.proj(cross))

class ConformerTemporal(nn.Module):
    """Per-asset Conformer temporal encoder (vs GRU last-state) — the single-asset reference's
    design (BTC 0.067 existence proof): macaron-FFN + multi-head self-attention (global, content
    -based, preserves which-step-mattered) + DEPTHWISE CAUSAL CONV kernel=k (local micro-burst
    over k frames, which 60s-GRU & flat features miss) + FFN, then ATTENTION-POOL over time.
    Per-asset (B*S,L,Fin) — no cross-asset mixing -> no ln2-collapse. Output d_t, gated by alpha_t."""
    def __init__(self,Fin,d_t,heads=4,kernel=9,dropout=0.3):
        super().__init__()
        self.inp=nn.Linear(Fin,d_t); self.k=kernel
        self.f1=nn.Sequential(nn.LayerNorm(d_t),nn.Linear(d_t,2*d_t),nn.GELU(),nn.Dropout(dropout),nn.Linear(2*d_t,d_t),nn.Dropout(dropout))
        self.na=nn.LayerNorm(d_t); self.attn=nn.MultiheadAttention(d_t,heads,dropout=dropout,batch_first=True)
        self.nc=nn.LayerNorm(d_t); self.conv=nn.Conv1d(d_t,d_t,kernel,padding=kernel-1,groups=d_t); self.pw=nn.Conv1d(d_t,d_t,1)
        self.f2=nn.Sequential(nn.LayerNorm(d_t),nn.Linear(d_t,2*d_t),nn.GELU(),nn.Dropout(dropout),nn.Linear(2*d_t,d_t),nn.Dropout(dropout))
        self.no=nn.LayerNorm(d_t); self.pq=nn.Linear(d_t,1)
    def forward(self,xs):  # xs (B*S, L, Fin)
        h=self.inp(xs); L=h.shape[1]
        h=h+0.5*self.f1(h)
        a,_=self.attn(self.na(h),self.na(h),self.na(h)); h=h+a
        c=self.nc(h).transpose(1,2); c=self.pw(torch.relu(self.conv(c)[...,:L])).transpose(1,2); h=h+c  # depthwise CAUSAL conv
        h=h+0.5*self.f2(h); h=self.no(h)
        w=torch.softmax(self.pq(h).squeeze(-1),1)                     # attention-pool over time
        return (h*w.unsqueeze(-1)).sum(1)                            # (B*S, d_t)

class CSRankerSeq(nn.Module):
    def __init__(self,Fsnap,Fseq,d=256,layers=4,dropout=0.4,feat_drop=0.3,d_t=64,gru_layers=1,
                 use_leadlag=False,use_lobcnn=False,use_lobtemporal=False,per_asset_film=False,factor_bridge=False,use_fm=False,cross_asset=False,xattn_layers=1,xattn_per_asset_gate=False,use_moe=False,n_exp=4,head_norm=False,temporal_attnpool=False,dcnv2_csz=False,cross_rank=8,temporal_fast_only=False,temporal_conformer=False,conf_kernel=9,split_mag=False,mag_film=False,temporal_transformer=False,transformer_layers=2,temporal_hybrid=False,hybrid_near=30,hybrid_patch=5,head_routing=False,strong_mkt=False,mkt_raw=False,lob_attnpool=False,fine_lob=False,aux_horizons=None,daqh=False):
        super().__init__()
        self.feat_drop=feat_drop; self.Fraw=Fsnap//2  # raw half (cs-z is the other half)
        blocks=[]; din=Fsnap
        for _ in range(layers):
            blocks += [nn.Linear(din,d),nn.LayerNorm(d),nn.GELU(),nn.Dropout(dropout)]; din=d
        self.backbone=nn.Sequential(*blocks)
        self.pa_film=PerAssetFiLM(14,d) if per_asset_film else None
        self.moe=RegimeMoE(d,n_exp=n_exp,dropout=dropout) if use_moe else None
        self.fm=FMInteraction(Fsnap,d) if use_fm else None
        self.factor_bridge=factor_bridge
        if factor_bridge:  # market factor F_hat from cross-asset pooled rep; per-asset beta; identity-init gate
            self.strong_mkt=strong_mkt; self.mkt_raw=mkt_raw
            self.mkt_in=nn.Linear(Fsnap//2,d) if mkt_raw else None  # market head reads RAW (market-laden) features, NOT the cs-z trunk
            self.mkt_pool=nn.Linear(d,1) if strong_mkt else None  # learned attention-pool over assets (focus BTC/ETH) vs flat mean
            self.mkt_head=(nn.Sequential(nn.Linear(d,d),nn.GELU(),nn.Dropout(dropout),nn.Linear(d,1)) if strong_mkt
                           else nn.Sequential(nn.Linear(d,d//2),nn.GELU(),nn.Linear(d//2,1)))
            self.beta=nn.Parameter(torch.ones(14))            # per-asset loading to F (init 1)
            self.alpha_F=nn.Parameter(torch.zeros(1))         # identity-init gate: market term off at start
        self.temporal_fast_only=temporal_fast_only               # multi-rate: temporal sees only FAST channels (fine res)
        gru_in=len(FASTSEQ_IDX) if temporal_fast_only else Fseq
        self.conformer=ConformerTemporal(gru_in,d_t,kernel=conf_kernel,dropout=dropout) if temporal_conformer else None
        self.transformer=TransformerTemporal(gru_in,d_t,layers=transformer_layers,dropout=dropout,pool=True) if temporal_transformer else None
        self.hybrid=HybridTemporal(gru_in,d_t,near=hybrid_near,patch=hybrid_patch,layers=transformer_layers,dropout=dropout) if temporal_hybrid else None
        self.gru=nn.GRU(gru_in,d_t,num_layers=gru_layers,batch_first=True,dropout=dropout if gru_layers>1 else 0.0)
        self.tq=nn.Linear(d_t,1) if temporal_attnpool else None  # learned attention-pool over GRU states (vs lossy last-state)
        self.t_proj=nn.Linear(d_t,d); self.t_norm=nn.LayerNorm(d)
        self.alpha_t=nn.Parameter(torch.zeros(1))   # identity-init: start = E144 snapshot model
        self.crosscsz=CrossCSZ(Fsnap//2,d,r=cross_rank,dropout=dropout) if dcnv2_csz else None
        self.lobcnn=LOBCNN(d,dropout=dropout) if use_lobcnn else None
        self.lobtemporal=LOBTemporalCNN(d,dropout=dropout,attnpool=lob_attnpool) if use_lobtemporal else None
        self.lobfine=LOBTemporalCNN(d,dropout=dropout,attnpool=True) if fine_lob else None  # 2nd DeepLOB on FINE per-second 1s-LOB stream (identity-init)
        self.aux_heads=nn.ModuleList([nn.Linear(d,1) for _ in aux_horizons]) if aux_horizons else None  # MULTI-HORIZON-AUX: short-horizon rank heads shape the shared encoder
        self.leadlag=LeadLag(d,dropout=dropout) if use_leadlag else None
        self.xattn=CrossAssetAttn(d,dropout=dropout,n_layers=xattn_layers,per_asset_gate=xattn_per_asset_gate,S=14) if cross_asset else None
        self.head_norm=nn.LayerNorm(d) if head_norm else None  # stabilize h after 6+ residual adds before heads
        self.rank_head=nn.Linear(d,1)
        self.log_sig_rank=nn.Parameter(torch.zeros(())); self.log_sig_mag=nn.Parameter(torch.zeros(()))  # Kendall uncertainty weighting (used w/ --uw)
        # split_mag: give the MAGNITUDE head its OWN MLP branch so rank & magnitude don't fight on the
        # shared trunk (huber_w up crashed cs_spear on the shared Linear heads). Lets both be strong.
        self.mag_head=nn.Sequential(nn.Linear(d,d//2),nn.GELU(),nn.Dropout(dropout),nn.Linear(d//2,1)) if split_mag else nn.Linear(d,1)
        self.mag_film=PerAssetFiLM(14,d) if mag_film else None  # per-asset magnitude specialization (own gamma/beta for the mag branch)
        self.daqh_head=DAQHHead(d,dropout=dropout) if daqh else None  # single-asset DAQH: q50=tanh(sign)·softplus(mag)
        # head_routing: feed the cs-z (market-neutral) half to the RANK head via identity-init increment,
        # so the magnitude/market gradients on the shared trunk cannot pull the rank input (non-interference).
        self.head_routing=head_routing
        self.csz_proj=nn.Linear(Fsnap//2,d) if head_routing else None
        self.alpha_route=nn.Parameter(torch.zeros(1)) if head_routing else None
    def forward(self,xsnap,xseq,xfine=None):  # xsnap (B,S,Fsnap), xseq (B,L,S,Fseq), xfine (B,Lf,S,38) per-second LOB
        xraw=xsnap[...,:self.Fraw]                          # raw feature half (LOB ladder lives here)
        xcsz=xsnap[...,self.Fraw:]                          # cs-z half (clean, pre-dropout) for explicit crossing
        if self.training and self.feat_drop>0:
            keep=(torch.rand(xsnap.shape[-1],device=xsnap.device)>self.feat_drop).float()
            xsnap=xsnap*keep/(1-self.feat_drop)
        h=self.backbone(xsnap)                              # (B,S,d)
        if self.pa_film is not None: h=self.pa_film(h)      # per-asset specialization (identity-init)
        if self.moe is not None: h=self.moe(h)              # regime-conditional MoE routing (identity-init)
        if self.fm is not None: h=self.fm(h,xsnap)          # low-rank FM 2nd-order feature interactions (identity-init)
        if self.crosscsz is not None: h=self.crosscsz(h,xcsz)  # low-rank DCN-V2 cross on cs-z half (identity-init)
        xseq_t=xseq[...,FASTSEQ_IDX] if self.temporal_fast_only else xseq  # multi-rate: fast channels only at fine res
        B,L,Sn,Fq=xseq_t.shape
        xs=xseq_t.permute(0,2,1,3).reshape(B*Sn,L,Fq)       # per-asset sequences (no cross-asset mixing)
        if self.hybrid is not None:                          # conv-near + transformer-global (user's division of labor)
            tt=self.hybrid(xs)
        elif self.transformer is not None:                   # per-asset Transformer (SSL-pretrainable, masked-modeling native)
            tt=self.transformer(xs)
        elif self.conformer is not None:                     # per-asset Conformer (conv+attn+pool) — richest temporal
            tt=self.conformer(xs)
        elif self.tq is not None:                            # attention-pool over ALL GRU states (keep which-step-mattered)
            out,_=self.gru(xs); w=torch.softmax(self.tq(out).squeeze(-1),1)
            tt=(out*w.unsqueeze(-1)).sum(1)
        else:
            _,hn=self.gru(xs); tt=hn[-1]                      # default: lossy last-state
        t=self.t_proj(tt).reshape(B,Sn,-1)
        h=h+torch.tanh(self.alpha_t)*self.t_norm(t)         # identity-init temporal increment
        if self.lobcnn is not None: h=self.lobcnn(h,xraw)   # structured raw-LOB ladder CNN (current frame)
        if self.lobtemporal is not None: h=self.lobtemporal(h,xseq[...,-38:])  # DeepLOB conv over time×levels (coarse 60s)
        if self.lobfine is not None and xfine is not None: h=self.lobfine(h,xfine)  # DeepLOB conv over FINE per-second 1s-LOB trajectory
        if self.leadlag is not None: h=self.leadlag(h)      # asymmetric BTC/ETH lead-lag
        if self.xattn is not None: h=self.xattn(h)          # guarded within-snapshot cross-asset attention
        if self.head_norm is not None: h=self.head_norm(h)   # stabilize h scale after residual stack
        rh=h+torch.tanh(self.alpha_route)*self.csz_proj(xcsz) if self.head_routing else h  # cs-z increment isolates rank
        rank=self.rank_head(rh).squeeze(-1)
        self._aux_out=[head(rh).squeeze(-1) for head in self.aux_heads] if self.aux_heads is not None else None  # aux short-horizon rank preds
        mh=self.mag_film(h) if self.mag_film is not None else h  # per-asset magnitude specialization
        if self.daqh_head is not None:
            mag,self._sign_logit,self._mag_abs,self._q10,self._q90=self.daqh_head(mh)  # DAQH q50 as point pred
        else:
            mag=self.mag_head(mh).squeeze(-1)
        if self.factor_bridge:                               # raw = idio_mag + gate*beta*F_hat (market guidance)
            mbase=self.mkt_in(xraw) if self.mkt_raw else h   # market head reads RAW market-laden features when mkt_raw
            if self.strong_mkt:                              # attention-pool over assets (learns to weight BTC/ETH market leaders)
                w=torch.softmax(self.mkt_pool(mbase).squeeze(-1),1); mpool=(mbase*w.unsqueeze(-1)).sum(1)
            else: mpool=mbase.mean(1)
            fhat=self.mkt_head(mpool).squeeze(-1)            # (B,) market factor from cross-asset pool
            mag=mag+torch.tanh(self.alpha_F)*self.beta.unsqueeze(0)*fhat.unsqueeze(1)
            return rank,mag,fhat
        return rank,mag,None

@torch.no_grad()
def evaluate(model,Xsnap,Xseq,Yd,valid,device,bs=1024,Xfine=None):
    model.eval(); N=Xsnap.shape[0]; rpred=np.zeros((N,S),np.float32); mpred=np.zeros((N,S),np.float32); fpred=np.zeros(N,np.float32)
    fb=getattr(model,'factor_bridge',False)
    aF=float(torch.tanh(model.alpha_F).item()) if fb else 0.0
    beta=model.beta.detach().cpu().numpy().astype(np.float32) if fb else None
    for i in range(0,N,bs):
        xs=torch.from_numpy(Xsnap[i:i+bs]).to(device); xq=torch.from_numpy(Xseq[i:i+bs]).to(device)
        xf=torch.from_numpy(Xfine[i:i+bs]).to(device) if Xfine is not None else None
        r,m,fh=model(xs,xq,xf); rpred[i:i+bs]=r.cpu().numpy(); mpred[i:i+bs]=m.cpu().numpy()
        if fb and fh is not None: fpred[i:i+bs]=fh.cpu().numpy()
    cmean=np.nanmean(np.where(valid,Yd,np.nan),1,keepdims=True)        # market factor per snapshot
    idio_res=Yd-np.nan_to_num(cmean)                                   # idio residual target
    idio_mag=mpred-aF*beta[None,:]*fpred[:,None] if fb else mpred      # recover idio_mag from derived raw
    cs=[]; pa={s:([],[]) for s in range(S)}; ipa={s:([],[]) for s in range(S)}
    for t in range(N):
        row=rpred[t,UNIV10];yr=Yd[t,UNIV10];v=valid[t,UNIV10]
        if v.sum()>=5 and np.std(row[v])>1e-12: cs.append(np.corrcoef(rankdata(row[v]),rankdata(yr[v]))[0,1])
        for s in range(S):
            if valid[t,s]:
                pa[s][0].append(mpred[t,s]); pa[s][1].append(Yd[t,s])
                ipa[s][0].append(idio_mag[t,s]); ipa[s][1].append(idio_res[t,s])
    def _p9(d):
        out=[]; per={}
        for s in UNIV10:
            ph,yy=np.array(d[s][0]),np.array(d[s][1])
            if len(ph)>100 and np.std(ph)>1e-12 and np.std(yy)>1e-12: pc=np.corrcoef(ph,yy)[0,1]; out.append(pc); per[s]=pc
        return (np.nanmean(out) if out else np.nan),per
    p9,per=_p9(pa); ip9,_=_p9(ipa)                                     # raw per-asset / idio-mag per-asset
    cmv=cmean.squeeze(1); fok=np.isfinite(cmv)&(np.std(fpred)>1e-12)   # F_hat vs market factor (pooled)
    fp=np.corrcoef(fpred[fok],cmv[fok])[0,1] if fb and fok.sum()>100 else np.nan
    return (np.nanmean(cs) if cs else np.nan),p9,per,ip9,fp

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tag",required=True);ap.add_argument("--epochs",type=int,default=60)
    ap.add_argument("--stride",type=int,default=360);ap.add_argument("--L",type=int,default=10);ap.add_argument("--step",type=int,default=60)
    ap.add_argument("--d",type=int,default=256);ap.add_argument("--layers",type=int,default=4);ap.add_argument("--d_t",type=int,default=64)
    ap.add_argument("--gru_layers",type=int,default=1)
    ap.add_argument("--dropout",type=float,default=0.4);ap.add_argument("--feat_drop",type=float,default=0.3)
    ap.add_argument("--lr",type=float,default=1e-3);ap.add_argument("--bs",type=int,default=512);ap.add_argument("--wd",type=float,default=1e-3)
    ap.add_argument("--huber_w",type=float,default=0.1);ap.add_argument("--warmup",type=int,default=3);ap.add_argument("--smoke",action="store_true")
    ap.add_argument("--use_leadlag",action="store_true");ap.add_argument("--use_lobcnn",action="store_true")
    ap.add_argument("--select",default="cs",choices=["cs","combo"])  # combo = cs_spear + P9 (balance both heads)
    ap.add_argument("--raw_lob_seq",action="store_true")  # append raw scale-preserved LOB ladder to GRU sequence
    ap.add_argument("--use_lobtemporal",action="store_true")  # DeepLOB conv over time×levels (needs --raw_lob_seq)
    ap.add_argument("--raw_target",action="store_true")  # predict RAW y_600 (per-asset Pearson) instead of CS-demeaned idio
    ap.add_argument("--rank_w",type=float,default=1.0)   # LambdaRank weight (lower it when raw_target -> Huber primary)
    ap.add_argument("--per_asset_film",action="store_true")  # per-asset gamma/beta specialization (identity-init)
    ap.add_argument("--mag_loss",default="huber",choices=["huber","ccc"])  # ccc pushes beta->1, sigma_pred->sigma_act
    ap.add_argument("--inner_val",action="store_true")  # select on inner train slice disjoint from W1-W4 (no W1 leak)
    ap.add_argument("--factor_bridge",action="store_true")  # raw = idio_mag + gate*beta*F_hat (market guidance, needs raw_target)
    ap.add_argument("--f_w",type=float,default=0.3)         # market-factor F_hat supervision weight
    ap.add_argument("--mkt_ccc",action="store_true")        # F_hat loss MSE->CCC (pins F_hat scale to cm, anti sigma-inflation)
    ap.add_argument("--beta_prior",type=float,default=0.0)  # soft (beta-1)^2 prior on per-asset market loadings
    ap.add_argument("--head_routing",action="store_true")   # rank head reads cs-z increment (identity-init) to isolate it from mag/market grads
    ap.add_argument("--strong_mkt",action="store_true")     # market head: attention-pool over assets + deeper MLP (vs flat mean)
    ap.add_argument("--mkt_raw",action="store_true")        # market head reads RAW market-laden features (not cs-z trunk)
    ap.add_argument("--lob_attnpool",action="store_true")   # DeepLOB: attention-pool over (time x level) grid vs AdaptiveAvgPool crush
    ap.add_argument("--uw",action="store_true")             # Kendall uncertainty weighting over rank+idio-mag losses
    ap.add_argument("--train_start",type=int,default=20240316)  # extend training history (with --inner_val)
    ap.add_argument("--train_end",type=int,default=0)         # WALK-FORWARD: train end date (0=legacy 20250405)
    ap.add_argument("--eval_start",type=int,default=0)        # WALK-FORWARD: single OOS window start (0=fixed W1-W4)
    ap.add_argument("--eval_end",type=int,default=0)          # WALK-FORWARD: single OOS window end
    ap.add_argument("--drop_tier4",action="store_true")       # zero tier4 leaked regime cols 30-40(+cs-z 142-152) -> leak-free
    ap.add_argument("--raw_norm",action="store_true")        # RAW mode: global-z inputs (keep market) + per-asset MAD-z target (anti σ-collapse) — for raw Pearson
    ap.add_argument("--causal_norm",action="store_true")     # frozen TRAIN gstats (no intra-day look-ahead) — the HONEST deployable normalization
    ap.add_argument("--revin",action="store_true")           # per-window RevIN (causal+adaptive) — single-asset-proven input norm
    ap.add_argument("--aux_horizons",default="")              # MULTI-HORIZON-AUX: comma short horizons (e.g. 120,300,600) as aux rank heads shaping encoder for primary --horizon
    ap.add_argument("--aux_w",type=float,default=0.3)         # weight per aux-horizon rank loss
    ap.add_argument("--recency",type=float,default=0.0)         # >0: recency-weighted sampling, half-life=recency*span (regime drift)
    ap.add_argument("--vrex_beta",type=float,default=0.0)       # V-REx worst-block variance penalty (regime robustness); 0=ERM
    ap.add_argument("--vrex_k",type=int,default=5)              # number of contiguous chronological blocks (proxy regimes)
    ap.add_argument("--use_fm",action="store_true")            # low-rank FM 2nd-order feature interactions (GBDT-gap lever)
    ap.add_argument("--horizon",type=int,default=600)          # prediction horizon (120/300/600/1800/3600)
    ap.add_argument("--rank_horizon",type=int,default=0)       # DUAL-HORIZON: rank head on SHORT idio horizon; mag head on --horizon(long) raw. 0=off
    ap.add_argument("--fine_lob",action="store_true")         # MULTI-RATE: add FINE per-second 1s-LOB stream + 2nd DeepLOB encoder (identity-init)
    ap.add_argument("--fine_L",type=int,default=60)           # fine stream length (frames)
    ap.add_argument("--fine_step",type=int,default=1)         # fine stream resolution (s/frame); 1=per-second
    ap.add_argument("--idio_target",action="store_true")       # beta-neutral idio target y_{h}_idio (cleaner alpha, no inline demean)
    ap.add_argument("--cross_asset",action="store_true")       # guarded within-snapshot cross-asset attention
    ap.add_argument("--var_floor",type=float,default=0.3)      # min within-snapshot rank-score std (anti ln2-collapse)
    ap.add_argument("--var_w",type=float,default=0.0)          # weight of the variance-floor penalty (set >0 with cross_asset)
    ap.add_argument("--xattn_layers",type=int,default=1)       # cross-asset attention depth
    ap.add_argument("--xattn_per_asset_gate",action="store_true")  # per-asset cross-asset gate: leaders (BTC) opt out, keep per-asset signal
    ap.add_argument("--use_moe",action="store_true")           # regime-conditional MoE routing (state-dependent expert mixture)
    ap.add_argument("--n_exp",type=int,default=4)              # number of MoE experts
    ap.add_argument("--head_norm",action="store_true")         # final LayerNorm before heads (stabilize h after residual stack)
    ap.add_argument("--temporal_attnpool",action="store_true") # attention-pool over GRU states vs lossy last-state
    ap.add_argument("--dcnv2_csz",action="store_true")         # low-rank DCN-V2 cross on cs-z half (crossing done right)
    ap.add_argument("--cross_rank",type=int,default=8)         # DCN-V2 low-rank r (capacity bottleneck)
    ap.add_argument("--temporal_fast_only",action="store_true")# multi-rate: temporal encoder sees only fast channels (use w/ fine step)
    ap.add_argument("--temporal_conformer",action="store_true")# per-asset Conformer temporal encoder (conv+attn+pool, single-asset 0.067 design)
    ap.add_argument("--conf_kernel",type=int,default=9)        # Conformer depthwise causal conv kernel
    ap.add_argument("--split_mag",action="store_true")
    ap.add_argument("--mag_film",action="store_true")         # magnitude head gets own MLP branch (rank & mag don't fight)
    ap.add_argument("--daqh",action="store_true")            # single-asset DAQH head (q50=tanh(sign)·softplus(mag), zero-init)
    ap.add_argument("--reg_loss",action="store_true")        # REG_arch 5-component magnitude loss (pinball+huber+mag_focal+tail_focal_bce)
    ap.add_argument("--init_gru",default="")                   # SSL-pretrained GRU weights to warm-start the temporal tower
    ap.add_argument("--temporal_transformer",action="store_true")  # Transformer temporal encoder (SSL-pretrainable, masked-modeling native)
    ap.add_argument("--transformer_layers",type=int,default=2)
    ap.add_argument("--init_transformer",default="")           # SSL-pretrained Transformer encoder weights (inp+pos+blocks)
    ap.add_argument("--init_full",default="")              # warm-start WHOLE model state_dict (e.g. fast-horizon pretrain -> y_600)
    ap.add_argument("--temporal_hybrid",action="store_true")  # conv-near + transformer-global hybrid temporal encoder
    ap.add_argument("--hybrid_near",type=int,default=30); ap.add_argument("--hybrid_patch",type=int,default=5)
    a=ap.parse_args(); set_seed(42)
    global RAWNORM,CAUSALNORM,GSTATS,REVIN; RAWNORM=a.raw_norm; CAUSALNORM=a.causal_norm; REVIN=a.revin
    device="cuda" if torch.cuda.is_available() else "cpu"
    ANAME=UNIV_NAMES
    WIN_USE=[("OOS",a.eval_start,a.eval_end)] if a.eval_start>0 else WINDOWS  # walk-forward: single OOS window override
    tr_days=dr(*TRAIN)
    vsel=dr(20250425,20250509)  # default selection = W1 (legacy; leaks into W1-in-AGG)
    if a.inner_val:             # leakage-free: hold out last ~10 train days for selection (disjoint from OOS)
        TE=a.train_end if a.train_end>0 else 20250405; tr_days=dr(a.train_start,TE); vsel=tr_days[-10:]; tr_days=tr_days[:-10]  # fold-parameterized train + leak-free selection
    if a.smoke: tr_days=tr_days[:8]; a.epochs=2
    if RAWNORM and CAUSALNORM:  # freeze global-z stats on TRAIN only (causal; no intra-day/OOS look-ahead)
        GSTATS=compute_gstats(tr_days,a.stride,a.L,a.step,a.horizon,a.idio_target); print(f"[causal_norm] frozen TRAIN gstats shape={GSTATS[0].shape}",flush=True)
    print(f"E147 temporal CS-ranker | train {len(tr_days)}d stride={a.stride} L={a.L} step={a.step} inner_val={a.inner_val} mag_loss={a.mag_loss}...",flush=True)
    RH=a.rank_horizon if a.rank_horizon>0 else None
    FL=a.fine_lob
    AUX=[int(x) for x in a.aux_horizons.split(",")] if a.aux_horizons else None
    Ytr_a=None
    if AUX: Xsnap,Xseq,Ytr,Vtr,Ytr_a=load_seq(tr_days,a.stride,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target,aux_horizons=AUX); Ytr_s=None; Xtr_f=None
    elif FL: Xsnap,Xseq,Ytr,Vtr,Xtr_f=load_seq(tr_days,a.stride,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target,fine_lob=True,fine_L=a.fine_L,fine_step=a.fine_step); Ytr_s=None
    elif RH: Xsnap,Xseq,Ytr,Vtr,Ytr_s=load_seq(tr_days,a.stride,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target,rank_horizon=RH); Xtr_f=None
    else: Xsnap,Xseq,Ytr,Vtr=load_seq(tr_days,a.stride,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target); Ytr_s=None; Xtr_f=None
    if a.drop_tier4: Xsnap[...,30:41]=0.0; Xsnap[...,142:153]=0.0; Xseq[...,30:41]=0.0  # leak-free: zero tier4 regime cols
    Fsnap=Xsnap.shape[-1]; Fseq=Xseq.shape[-1]; N=Xsnap.shape[0]
    print(f"train snapshots={N} Fsnap={Fsnap} Fseq={Fseq} raw_target={a.raw_target} rank_w={a.rank_w} horizon={a.horizon}",flush=True)
    if FL: Xs_v,Xq_v,Yv,Vv,Xv_f=load_seq(vsel,a.horizon,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target,fine_lob=True,fine_L=a.fine_L,fine_step=a.fine_step)
    else: Xs_v,Xq_v,Yv,Vv=load_seq(vsel,a.horizon,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target); Xv_f=None  # selection slice
    if a.drop_tier4: Xs_v[...,30:41]=0.0; Xs_v[...,142:153]=0.0; Xq_v[...,30:41]=0.0
    model=CSRankerSeq(Fsnap,Fseq,d=a.d,layers=a.layers,dropout=a.dropout,feat_drop=a.feat_drop,d_t=a.d_t,gru_layers=a.gru_layers,use_leadlag=a.use_leadlag,use_lobcnn=a.use_lobcnn,use_lobtemporal=a.use_lobtemporal,per_asset_film=a.per_asset_film,factor_bridge=a.factor_bridge,use_fm=a.use_fm,cross_asset=a.cross_asset,xattn_layers=a.xattn_layers,xattn_per_asset_gate=a.xattn_per_asset_gate,use_moe=a.use_moe,n_exp=a.n_exp,head_norm=a.head_norm,temporal_attnpool=a.temporal_attnpool,dcnv2_csz=a.dcnv2_csz,cross_rank=a.cross_rank,temporal_fast_only=a.temporal_fast_only,temporal_conformer=a.temporal_conformer,conf_kernel=a.conf_kernel,split_mag=a.split_mag,mag_film=a.mag_film,temporal_transformer=a.temporal_transformer,transformer_layers=a.transformer_layers,temporal_hybrid=a.temporal_hybrid,hybrid_near=a.hybrid_near,hybrid_patch=a.hybrid_patch,head_routing=a.head_routing,strong_mkt=a.strong_mkt,mkt_raw=a.mkt_raw,lob_attnpool=a.lob_attnpool,fine_lob=a.fine_lob,aux_horizons=AUX,daqh=a.daqh).to(device)
    if a.init_gru:  # warm-start the temporal GRU from SSL pretraining (the data lever)
        sd=torch.load(a.init_gru,map_location=device); model.gru.load_state_dict(sd)
        print(f"  [SSL] loaded pretrained GRU from {a.init_gru}",flush=True)
    if a.init_transformer:  # warm-start the Transformer temporal encoder from MASKED-MODELING SSL
        sd=torch.load(a.init_transformer,map_location=device)
        miss,unexp=model.transformer.load_state_dict(sd,strict=False)  # pool head pq is new (random); blocks/inp/pos transfer
        print(f"  [SSL] loaded pretrained Transformer from {a.init_transformer} (missing={list(miss)})",flush=True)
    if a.init_full:  # warm-start the ENTIRE model (multi-horizon curriculum: fast-horizon pretrain -> y_600 finetune)
        sd=torch.load(a.init_full,map_location=device); miss,unexp=model.load_state_dict(sd,strict=False)
        print(f"  [warm-start] loaded full model from {a.init_full} (missing={len(miss)} unexpected={len(unexp)})",flush=True)
    print(f"params={sum(p.numel() for p in model.parameters()):,}",flush=True)
    opt=torch.optim.AdamW(model.parameters(),lr=a.lr,weight_decay=a.wd)
    def cos_lr(ep):
        if ep<=a.warmup: return a.lr*ep/max(1,a.warmup)
        prog=(ep-a.warmup)/max(1,a.epochs-a.warmup); return a.lr*(0.05+0.95*0.5*(1+math.cos(math.pi*prog)))
    outdir=Path(f"/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments/diagnostic_{a.tag}");outdir.mkdir(parents=True,exist_ok=True)
    best=-1e9
    Xs=torch.from_numpy(Xsnap); Xq=torch.from_numpy(Xseq); Yt=torch.from_numpy(Ytr); Vt=torch.from_numpy(Vtr)
    Xf=torch.from_numpy(Xtr_f) if FL else None
    Ya=torch.from_numpy(Ytr_a) if AUX else None
    Ysh=torch.from_numpy(Ytr_s) if RH else None
    # recency weighting: samples are chronological (day-ordered); weight recent more (near-val sweet spot)
    blk=(torch.arange(N)*a.vrex_k//max(N,1)).clamp(max=a.vrex_k-1)  # chronological block label per sample (day-ordered)
    rec_w=None
    if a.recency>0:
        pos=torch.arange(N,dtype=torch.float32)/max(N-1,1)        # 0=oldest, 1=newest
        rec_w=torch.pow(0.5,(1.0-pos)/a.recency)                  # half-life = recency*span
        print(f"recency weighting on: hl_frac={a.recency} (oldest weight={float(rec_w[0]):.3f})",flush=True)
    for ep in range(1,a.epochs+1):
        for g in opt.param_groups: g['lr']=cos_lr(ep)
        model.train(); t0=time.perf_counter()
        perm=torch.multinomial(rec_w,N,replacement=True) if rec_w is not None else torch.randperm(N)
        losses=[]
        for i in range(0,N,a.bs):
            idx=perm[i:i+a.bs]
            xs=Xs[idx].to(device); xq=Xq[idx].to(device); yb=Yt[idx].to(device); vb=Vt[idx].to(device)
            xf=Xf[idx].to(device) if Xf is not None else None
            ya=Ya[idx].to(device) if Ya is not None else None
            ysh=Ysh[idx].to(device) if Ysh is not None else None
            opt.zero_grad(set_to_none=True)
            rs,ms,fh=model(xs,xq,xf)
            if RH and not a.factor_bridge:  # DUAL-HORIZON (2-head): rank on SHORT idio (demean ysh), mag on LONG raw (yb)
                cmS=(ysh*vb.float()).sum(1,keepdim=True)/vb.float().sum(1,keepdim=True).clamp(min=1.0)
                yrS=torch.where(vb,ysh-cmS,torch.zeros_like(ysh))
                magl=ccc_loss(ms,yb,vb) if a.mag_loss=="ccc" else huber_demean(ms,yb,vb)
                loss=a.rank_w*lambdarank_loss(rs,yrS,vb)+a.huber_w*magl
            elif a.factor_bridge:  # rank+idio-mag on IDIO residual (orthogonal subspaces); F_hat on market mean; RAW=ms DERIVED (no own loss)
                cm=(yb*vb.float()).sum(1,keepdim=True)/vb.float().sum(1,keepdim=True).clamp(min=1.0)
                yr=torch.where(vb,yb-cm,torch.zeros_like(yb))
                im=ms-torch.tanh(model.alpha_F)*model.beta.unsqueeze(0)*fh.unsqueeze(1)   # recover pre-bridge idio_mag (raw - market term)
                magl=ccc_loss(im,yr,vb) if a.mag_loss=="ccc" else huber_demean(im,yr,vb)   # idio-mag supervised on DEMEANED residual (not raw)
                fl=ccc_loss(fh,cm.squeeze(1),torch.ones_like(fh,dtype=torch.bool)) if a.mkt_ccc else ((fh-cm.squeeze(1))**2).mean()
                bprior=a.beta_prior*((model.beta-1.0)**2).mean()
                yr_rank=yr if ysh is None else torch.where(vb,ysh-(ysh*vb.float()).sum(1,keepdim=True)/vb.float().sum(1,keepdim=True).clamp(min=1.0),torch.zeros_like(ysh))  # DUAL-HORIZON: rank head on SHORT idio
                lr=lambdarank_loss(rs,yr_rank,vb)
                if a.uw:  # Kendall homoscedastic uncertainty weighting (rank+idio-mag only; market stays static)
                    loss=torch.exp(-model.log_sig_rank)*lr+0.5*model.log_sig_rank+torch.exp(-model.log_sig_mag)*magl+0.5*model.log_sig_mag+a.f_w*fl+bprior
                else: loss=a.rank_w*lr+a.huber_w*magl+a.f_w*fl+bprior
            elif a.vrex_beta>0:  # V-REx: penalize variance of per-block composite risk -> regime-robust
                bb=blk[idx].to(device); rks=[]
                for e in range(a.vrex_k):
                    m=(bb==e)
                    if m.sum()<2: continue
                    ml=ccc_loss(ms[m],yb[m],vb[m]) if a.mag_loss=="ccc" else huber_demean(ms[m],yb[m],vb[m])
                    rks.append(a.rank_w*lambdarank_loss(rs[m],yb[m],vb[m])+a.huber_w*ml)
                rks=torch.stack(rks)
                bw=a.vrex_beta*min(1.0,ep/max(1,3*a.warmup))   # ramp penalty over ~3*warmup epochs (identity-init delay guard)
                loss=rks.mean()+bw*rks.var()
            else:
                if a.reg_loss and model.daqh_head is not None:  # REG_arch 5-component magnitude recipe on DAQH head
                    q=torch.stack([model._q10,ms,model._q90],-1)
                    loss=(a.rank_w*lambdarank_loss(rs,yb,vb)+0.10*pinball_loss(q,yb,vb)
                          +a.huber_w*huber_demean(ms,yb,vb)+0.30*mag_focal_huber(model._mag_abs,yb,vb)
                          +0.10*tail_focal_bce(model._sign_logit,yb,vb))
                else:
                    magl=ccc_loss(ms,yb,vb) if a.mag_loss=="ccc" else huber_demean(ms,yb,vb)
                    loss=a.rank_w*lambdarank_loss(rs,yb,vb)+a.huber_w*magl
            if AUX and ya is not None:  # auxiliary short-horizon rank heads shape the shared encoder (deliverable=main head)
                for hi in range(len(AUX)):
                    yax=ya[...,hi]; cmA=(yax*vb.float()).sum(1,keepdim=True)/vb.float().sum(1,keepdim=True).clamp(min=1.0)
                    yaxd=torch.where(vb,yax-cmA,torch.zeros_like(yax)); loss=loss+a.aux_w*lambdarank_loss(model._aux_out[hi],yaxd,vb)
            if a.var_w>0:  # within-snapshot variance-floor: keep rank-score dispersion (anti ln2-collapse for cross_asset)
                vmf=vb.float(); nv=vmf.sum(1,keepdim=True).clamp(min=1.0)
                mu=(rs*vmf).sum(1,keepdim=True)/nv
                wvar=((rs-mu)**2*vmf).sum(1)/nv.squeeze(1)
                loss=loss+a.var_w*torch.relu(a.var_floor-torch.sqrt(wvar+1e-8)).mean()
            if not torch.isfinite(loss): continue
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
            losses.append(loss.item())
        cs9,p9,_,ip9,fp=evaluate(model,Xs_v,Xq_v,Yv,Vv,device,Xfine=Xv_f)
        mark=""; al=torch.tanh(model.alpha_t).item()
        if a.raw_target:  # joint raw: select on combo (cs9 is stable + reads same trunk as mag) > noisy vsel raw-P alone
            sel=(cs9+(p9 if np.isfinite(p9) else 0.0)) if (a.rank_w>0 and a.select=="combo") else (p9 if np.isfinite(p9) else -1)
        else: sel=cs9 if a.select=="cs" else (cs9+(p9 if np.isfinite(p9) else 0.0))
        if np.isfinite(sel) and sel>best: best=sel; torch.save(model.state_dict(),outdir/"best.pt"); mark="★"
        ixt=f" iP10={ip9:+.4f} F={fp:+.3f}" if a.factor_bridge else ""
        print(f"ep{ep:02d}/{a.epochs} loss={np.mean(losses):.4f} W1_cs={cs9:+.4f} W1_P10={p9:+.4f}{ixt} a_t={al:+.3f} ({time.perf_counter()-t0:.0f}s){mark}",flush=True)
    if (outdir/"best.pt").exists():
        model.load_state_dict(torch.load(outdir/"best.pt",map_location=device))
        print("\n=== MULTI-WINDOW (best.pt) vs E144 MLP 0.0439 / GBDT 0.0587 ===",flush=True)
        print(f"  EVAL UNIVERSE N={len(UNIV10)}: "+" ".join(UNIV_NAMES[a] for a in UNIV10),flush=True)
        csa=[];pa=[];ipaa=[];fpa=[];peragg={s:[] for s in UNIV10}
        for wn,wa,wb in WIN_USE:
            if FL: Xs_w,Xq_w,Yw,Vw,Xw_f=load_seq(dr(wa,wb),a.horizon,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target,fine_lob=True,fine_L=a.fine_L,fine_step=a.fine_step)
            else: Xs_w,Xq_w,Yw,Vw=load_seq(dr(wa,wb),a.horizon,a.L,a.step,raw_lob=a.raw_lob_seq,raw_target=a.raw_target,horizon=a.horizon,idio_target=a.idio_target); Xw_f=None
            if Xs_w is None: continue
            if a.drop_tier4: Xs_w[...,30:41]=0.0; Xs_w[...,142:153]=0.0; Xq_w[...,30:41]=0.0
            cs9,p9,per,ip9,fp=evaluate(model,Xs_w,Xq_w,Yw,Vw,device,Xfine=Xw_f); csa.append(cs9);pa.append(p9);ipaa.append(ip9);fpa.append(fp)
            for s,v in per.items(): peragg[s].append(v)
            print(f"  {wn}: cs_spear_10={cs9:+.4f} rawP10={p9:+.4f} idio_magP10={ip9:+.4f} F_hat_R={fp:+.3f}",flush=True)
        print(f"  AGG: cs_spear_10={np.nanmean(csa):+.4f} rawP10={np.nanmean(pa):+.4f} idio_magP10={np.nanmean(ipaa):+.4f} F_hat_R={np.nanmean(fpa):+.4f}",flush=True)
        print("  per-asset Pearson (AGG over windows):",{ANAME[s]:round(float(np.nanmean(v)),4) for s,v in peragg.items() if v},flush=True)
    print("DONE",flush=True)

if __name__=="__main__":
    main()
