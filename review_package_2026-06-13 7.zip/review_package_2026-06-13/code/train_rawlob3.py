"""STAGE-2 EFFICIENT (in-RAM) — full 1s LOB, single-asset-style data organization.
Per user: data loading was unoptimized (single-asset 700d=5min/epoch). FIX: preload the raw-LOB (38ch, the part
that needs 1s) into RAM ONCE (per-day dict, ~91GB for 500d), slice 1s windows in-memory each batch (RAM-speed,
no per-epoch disk I/O). Handcrafted as a SNAPSHOT (frozen-train robust-z). Model: per-asset DeepLOB on the raw-LOB
1s window (spatial-per-timestep -> dilated-causal temporal -> attn-pool) + handcrafted-snapshot MLP -> fuse ->
per-asset FiLM -> DAQH anti-collapse + rank co-train. RAW target, explicit valid mask, leak-free (tier4 dropped,
causal window, frozen-train stats). Per-asset eval P/beta/sigR/sign-acc.
Usage: python scripts/train_rawlob3.py --tag e_lob3 --win 600 --sub 1 --train_start 20230828 ...
"""
from __future__ import annotations
import argparse, time, math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from train_cs_ranker import UNIV10, UNIV_NAMES, dr, set_seed, lambdarank_loss
dev = "cuda" if torch.cuda.is_available() else "cpu"
NPZ = Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap")
S = 14; FALL = 112; H = 600
RLO = list(range(71, 89)) + list(range(89, 109))  # 38 raw-LOB cols = cumu18(9depth x2)+detail20(5level x4)
CUMU = slice(0, 18); DETAIL = slice(18, 38)
FLOW = [1, 20, 21, 24, 61, 62, 63, 67, 70]; NFLOW = len(FLOW)  # A4: 9 signed order-flow cols (excl kyle 111 = intra-day const)
RLOF = RLO + FLOW  # per-day stored seq = 38 book + 9 flow = 47 channels
REGIME = [3, 17, 28, 29, 60, 65]; NREG = len(REGIME)  # STEP2 FiLM regime prior: bar_range/rollvol/volz/rangecompress/cs_vol/spread_z (CAUSAL; NOT the leaky 30:41 one-hots)
INTERACT = [(21, 64), (21, 17), (63, 64), (61, 109), (67, 21)]; NINT = len(INTERACT)  # Rank1 ridge-informed flow interactions: net_flow×spread, net_flow×vol, obi×spread, ofi×vpin, aggr×net_flow

def preload(days, win, stride, need_samples=True, use_interact=False):
    """Load each day ONCE; keep raw-LOB (T,14,47) in RAM + per-sample handcrafted-snapshot(14,112[+NINT])+y(14)+mask(14)."""
    rawlob = {}; samples = []
    for k, d in enumerate(days):
        xp = NPZ / str(d) / "X.npy"; yp = NPZ / str(d) / "y_600.npy"
        if not xp.exists() or not yp.exists(): continue
        X = np.array(np.load(xp, mmap_mode="r"), np.float32); Y = np.array(np.load(yp, mmap_mode="r"), np.float32)
        X[..., 30:41] = 0.0  # drop tier4 (leak)
        rawlob[d] = np.ascontiguousarray(X[:, :, RLOF])  # (T,14,47) raw-scale book(38)+flow(9) in RAM (from original cols)
        if use_interact:  # Rank1: append ridge-informed flow-interaction features to the snapshot
            extra = np.stack([np.nan_to_num(X[:, :, a] * X[:, :, b]) for a, b in INTERACT], axis=-1)  # (T,14,NINT)
            X = np.concatenate([X, extra], axis=-1)  # (T,14,112+NINT)
        T = X.shape[0]
        for t in range(win, T - H, stride):
            samples.append((d, t, X[t, :, :].copy(), Y[t].copy(), np.isfinite(Y[t])))
        del X, Y
        if (k + 1) % 80 == 0: print(f"  preload {k+1}/{len(days)} days, {len(samples)} samples", flush=True)
    return rawlob, samples

def robust_revin_seq(x):  # x (N,L,F) per-(N,F) median/MAD over L (causal window)
    med = x.median(1, keepdim=True).values
    mad = (x - med).abs().median(1, keepdim=True).values * 1.4826 + 1e-6
    return torch.clamp((x - med) / mad, -8, 8)

class LOBSpatial(nn.Module):  # per-timestep spatial conv over price-levels + LEVEL-ATTENTION-POOL -> d_raw
    """A2/A3 fix: NO cross-channel LayerNorm (it mixed delta_bps with logsz + erased book magnitude).
    Input is already per-channel causal robust-RevIN'd over time (robust_revin_seq in LOBNet3.forward)."""
    def __init__(self, d_raw=32):
        super().__init__()
        self.dconv = nn.Sequential(nn.Conv1d(4, 16, 2), nn.GELU(), nn.Conv1d(16, 32, 2), nn.GELU())
        self.cconv = nn.Sequential(nn.Conv1d(2, 8, 2), nn.GELU(), nn.Conv1d(8, 16, 2), nn.GELU())
        self.dq = nn.Linear(32, 1); self.cq = nn.Linear(16, 1)   # learned level-importance (vs mean = preserve book shape)
        self.proj = nn.Sequential(nn.Linear(48, d_raw), nn.GELU())
    @staticmethod
    def _ap(e, q):  # e (M,C,Lv) -> level-attention-pool over Lv -> (M,C)
        et = e.transpose(1, 2); w = torch.softmax(q(et).squeeze(-1), 1); return (et * w.unsqueeze(-1)).sum(1)
    def forward(self, x):  # x (M, 38) already revin'd per-channel
        det = x[..., DETAIL].reshape(-1, 5, 4).permute(0, 2, 1)   # (M, fields=4, levels=5) -> conv across levels
        cum = x[..., CUMU].reshape(-1, 9, 2).permute(0, 2, 1)     # (M, sides=2, bins=9)   -> conv across depth bins
        return self.proj(torch.cat([self._ap(self.dconv(det), self.dq), self._ap(self.cconv(cum), self.cq)], -1))

class CausalConv1d(nn.Module):
    def __init__(self, ci, co, k, d=1):
        super().__init__(); self.pad = (k - 1) * d; self.c = nn.Conv1d(ci, co, k, dilation=d)
    def forward(self, x): return self.c(F.pad(x, (self.pad, 0)))

class TemporalTransformer(nn.Module):
    """E215c finding (deep-idio line): plain multi-layer self-attention over patch tokens BEATS dilated-conv/GRU
    for the per-asset temporal encoder — the conv-heavy Conformer OVERFIT, pure attention won (cs 0.0526, idio P9
    0.044, FIL 0.091). Pre-norm blocks; the window ends at t so full (non-causal) attention over patch tokens has
    NO look-ahead. Output-projs default-init so residuals start small (model ~= patched input at init)."""
    def __init__(self, d, n_layers=2, heads=4, dropout=0.1):
        super().__init__()
        self.blocks = nn.ModuleList([nn.ModuleDict(dict(
            ln1=nn.LayerNorm(d), attn=nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True),
            ln2=nn.LayerNorm(d), ff=nn.Sequential(nn.Linear(d, 2 * d), nn.GELU(), nn.Dropout(dropout), nn.Linear(2 * d, d)),
        )) for _ in range(n_layers)])
    def forward(self, h):  # h (M, K, d) patch tokens
        for b in self.blocks:
            x = b['ln1'](h); a, _ = b['attn'](x, x, x, need_weights=False); h = h + a
            h = h + b['ff'](b['ln2'](h))
        return h

class DAQH(nn.Module):
    def __init__(self, d):
        super().__init__()
        mk = lambda: nn.Sequential(nn.Linear(d, d // 2), nn.GELU(), nn.Linear(d // 2, 1))
        self.sign = mk(); self.mag = mk()
        for p in (self.sign, self.mag): nn.init.zeros_(p[-1].weight); nn.init.zeros_(p[-1].bias)
    def forward(self, h):
        sl = self.sign(h).squeeze(-1); ma = F.softplus(self.mag(h).squeeze(-1)); return torch.tanh(sl) * ma, sl, ma

class FiLMGate(nn.Module):  # STEP2: regime-conditioned gamma*z+beta, zero-init proj -> gamma=1,beta=0 identity at start
    def __init__(self, d_prior, d, dropout=0.1):
        super().__init__()
        self.trunk = nn.Sequential(nn.Linear(d_prior, d), nn.GELU(), nn.Dropout(dropout), nn.Linear(d, d), nn.GELU(), nn.Dropout(dropout))  # deeper: regimes are combinations
        self.gp = nn.Linear(d, d); self.bp = nn.Linear(d, d)
        for p in (self.gp, self.bp): nn.init.zeros_(p.weight); nn.init.zeros_(p.bias)
    def forward(self, z, r):  # z (M,d), r (M,d_prior)
        t = self.trunk(r); return (1 + self.gp(t)) * z + self.bp(t)

class LOBNet3(nn.Module):
    """FIXED per investigation: FUSE handcrafted (broadcast) + LOB-spatial per-timestep -> SHARED dilated-causal
    temporal (handcrafted anchors the LOB, not an isolated side-channel) -> attn-pool. PATCH the 1s window (denoise
    + fast). NO trunk LayerNorm + learnable sigma_scale (anti beta=2 magnitude collapse). Level-attn-pool in LOBSpatial."""
    def __init__(self, hmed, hmad, d=96, d_raw=32, d_flow=24, patch=10, dils=(1, 2, 4, 8, 16, 32),
                 use_lob=True, patch_agg='mean', pre_temporal=False, use_flow=False, per_asset=False, use_regime_film=False, use_basket=False,
                 use_btc_fusion=False, btc_lags=4, temporal='conv', n_tlayers=2):
        super().__init__()
        assert d % 8 == 0; self.patch = patch; self.patch_agg = patch_agg
        self.pre_temporal = pre_temporal; self.use_flow = use_flow; self.use_regime_film = use_regime_film; self.use_basket = use_basket
        self.use_btc_fusion = use_btc_fusion; self.temporal = temporal
        self.per_asset = per_asset; gdim = S if per_asset else 1   # per-asset gates+sigma: BTC opts out of flow; per-asset beta calib
        self.register_buffer('hmed', torch.from_numpy(hmed.astype(np.float32)))
        self.register_buffer('hmad', torch.from_numpy(hmad.astype(np.float32)))
        self.n_hand = hmed.shape[0]  # snapshot width (112, or 112+NINT with --use_interact)
        self.hand = nn.Sequential(nn.Linear(self.n_hand, d), nn.GELU(), nn.Dropout(0.2), nn.Linear(d, d), nn.GELU())  # NO LayerNorm (free scale)
        self.use_lob = use_lob
        if use_lob:
            self.lob = LOBSpatial(d_raw)
            if use_flow:                                                    # A4: per-second signed order-flow trajectory stream
                self.flowin = CausalConv1d(NFLOW, d_flow, 1)
                self.flowconv = nn.ModuleList([CausalConv1d(d_flow, d_flow, 3, dd) for dd in (1, 2, 4, 8)])
                self.flowproj = nn.Linear(d_flow, d_raw); self.gflow = nn.Parameter(torch.zeros(gdim))  # identity-init: no flow at start (per-asset: BTC can shut it)
            self.fuse = nn.Sequential(nn.Linear(d + d_raw, d), nn.GELU())   # FUSE handcrafted(broadcast)+LOB per-timestep
            if pre_temporal:                                               # A1: dilated-causal temporal at FULL 1s BEFORE patch
                self.temp1s = nn.ModuleList([CausalConv1d(d, d, 3, dd) for dd in (1, 2, 4)])
                self.g1s = nn.Parameter(torch.zeros(gdim))                  # identity-init gate (per-asset)
            if temporal == 'transformer':                                  # deep-idio upgrade: E215c-proven self-attention temporal (vs dilated-conv)
                self.ttr = TemporalTransformer(d, n_layers=n_tlayers)
            else:
                self.temp = nn.ModuleList([CausalConv1d(d, d, 3, dd) for dd in dils])
                self.tn = nn.ModuleList([nn.GroupNorm(8, d) for _ in dils])
            self.qpool = nn.Linear(d, 1); self.ldrop = nn.Dropout(0.1)     # LOB path dropout (was the least-regularized)
            self.al = nn.Parameter(torch.zeros(1))                          # identity-init gate: start as handcrafted-only
            if patch_agg == 'stats':                                       # mean+std+last+slope -> recover intra-patch micro moments
                self.patch_proj = nn.Linear(4 * d, d)
                with torch.no_grad():                                      # IDENTITY-INIT to mean: W=[I,0,0,0], b=0 -> starts == mean-patch
                    self.patch_proj.weight.zero_(); self.patch_proj.weight[:, :d].copy_(torch.eye(d)); self.patch_proj.bias.zero_()
            elif patch_agg == 'conv':                                      # learned depthwise strided downsample (>= mean)
                self.patch_conv = nn.Conv1d(d, d, patch, stride=patch, groups=d)
                with torch.no_grad():                                      # IDENTITY-INIT to mean: per-channel uniform 1/patch
                    self.patch_conv.weight.fill_(1.0 / patch); self.patch_conv.bias.zero_()
        self.sigma_scale = nn.Parameter(torch.ones(gdim))                   # output-gain beta knob (per-asset: heterogeneous calibration)
        self.pfilm = nn.Embedding(S, 2 * d); nn.init.zeros_(self.pfilm.weight)
        if use_regime_film: self.regime_film = FiLMGate(NREG, d)   # STEP2: regime-conditional gamma/beta (BTC predictability is regime-dependent)
        if use_basket:                                             # STEP3: asymmetric basket-context token (weak assets query the 13-asset market; the lever single-asset CAN'T have)
            self.bq = nn.Linear(d, 1); self.bproj = nn.Linear(d, d)   # NORMAL init: ctx!=0 so the zero-init gate gb RECEIVES gradient (fix double-zero dead-zone)
            self.bdrop = nn.Dropout(0.2)                            # regularize the basket context (anti-overfit: IS 0.06 -> OOS 0.02)
            self.gb = nn.Parameter(torch.zeros(S))                  # gate zero-init -> identity at start (gate=0); identity held by gate alone, not bproj
            self.register_buffer('warmup', torch.tensor(1.0))      # base converges first: set to (ep-1)/3 in train loop; 1.0 at eval
            self.register_buffer('strong_mask', torch.tensor([1., 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0]))  # 1=open weak (BTC0,XRP4,DOG5,TRX9); 0=pin strong+nonUNIV shut (protect FIL/SOL/ETH/ETC/LINK/DOT)
        if use_btc_fusion:                                         # Phase 15: frozen-BTC-teacher fusion (imports the 0.066-quality market/lead-lag signal bar_1s caps at ~0.025)
            self.btc_in = nn.Linear(34, d)                         # project each lag's [h_pred(32), q50, sigma] -> d
            self.btc_q = nn.Linear(d, d); self.btc_k = nn.Linear(d, d); self.btc_v = nn.Linear(d, d)  # asymmetric: alt zt=query, BTC-lag tokens=K/V (each alt picks WHICH lag of BTC leads it)
            self.btc_drop = nn.Dropout(0.2)
            self.gf_btc = nn.Parameter(torch.zeros(S))             # per-asset fusion gate (identity-init 0 -> baseline; each alt opens iff BTC helps it)
            self.btc_self = nn.Linear(d, d)                        # BTC OWN slice (idx0): direct h_pred residual -> lifts multi-asset BTC 0.028 toward teacher ~0.066 (makes ">BTC" the honest harder bar)
            self.g_btc_self = nn.Parameter(torch.zeros(1))
            self.register_buffer('btc_alt_mask', torch.tensor([0.] + [1.] * (S - 1)))  # cross-attn context applied to alts only (BTC=idx0 excluded)
            self.register_buffer('btc_self_mask', torch.tensor([1.] + [0.] * (S - 1)))  # direct residual applied to BTC slice only
            if not use_basket: self.register_buffer('warmup', torch.tensor(1.0))  # base converges first: set (ep-1)/3 in train loop; 1.0 at eval
        self.head = DAQH(d); self.rank = nn.Linear(d, 1)
    def _patch(self, f, L):  # f (M,L,d) -> (M,K,d). All variants identity-init to mean -> clean single-axis ablation.
        M, _, d = f.shape; p = self.patch; Lp = (L // p) * p
        if self.patch_agg == 'conv': return self.patch_conv(f[:, :Lp].transpose(1, 2)).transpose(1, 2)
        fp = f[:, :Lp].reshape(M, Lp // p, p, d)
        if self.patch_agg == 'stats':
            return self.patch_proj(torch.cat([fp.mean(2), fp.std(2), fp[:, :, -1], fp[:, :, -1] - fp[:, :, 0]], -1))
        return fp.mean(2)                                                   # 'mean' (default / reference)
    def forward(self, hand, lobseq, btc_tok=None):  # hand (B,S,112); lobseq (B,L,S,47=book38+flow9) or None; btc_tok (B,K,34) frozen-teacher
        B = hand.shape[0]
        aid = torch.arange(S, device=hand.device).view(1, S).expand(B, S).reshape(-1)  # (B*S,) asset-inner layout (matches reshape(B*S))
        pa = (lambda p: p[aid].view(-1, 1, 1)) if self.per_asset else (lambda p: p)     # per-asset (BS,1,1) vs scalar broadcast for seq gates
        hz = torch.clamp((hand - self.hmed) / self.hmad, -8, 8)
        hb = self.hand(hz).reshape(B * S, -1)                              # (BS,d) handcrafted base (no LN, free scale)
        z = hb
        if self.use_lob and lobseq is not None:
            L = lobseq.shape[1]
            xs = robust_revin_seq(lobseq.permute(0, 2, 1, 3).reshape(B * S, L, -1))  # (BS,L,47) A2/A3 causal per-channel RevIN over time
            e = self.lob(xs[..., :38].reshape(B * S * L, 38)).reshape(B * S, L, -1)  # (BS,L,d_raw) spatial book (no cross-channel LN)
            if self.use_flow:                                             # A4: integrate the per-second signed order-flow trajectory
                fh = self.flowin(xs[..., 38:].transpose(1, 2))            # (BS,d_flow,L)
                for c in self.flowconv: fh = fh + F.gelu(c(fh))           # dilated-causal flow temporal
                e = e + pa(torch.tanh(self.gflow)) * self.flowproj(fh.transpose(1, 2))  # per-asset gated flow (BTC can shut it)
            f = self.fuse(torch.cat([e, hb.unsqueeze(1).expand(B * S, L, hb.shape[-1])], -1))      # fuse w/ broadcast handcrafted (ANCHOR)
            if self.pre_temporal:                                         # A1: mix sub-10s dynamics at FULL 1s BEFORE the patch
                hh = f.transpose(1, 2)
                for c in self.temp1s: hh = hh + F.gelu(c(hh))
                f = f + pa(torch.tanh(self.g1s)) * (hh.transpose(1, 2) - f)  # per-asset gated (g1s=0 -> identity at init)
            f = self._patch(f, L)                                          # PATCH: aggregate 1s -> patch tokens (denoise + faster temporal)
            if self.temporal == 'transformer':
                h = self.ttr(f)                                            # (M,K,d) self-attention temporal (E215c best arch)
            else:
                h = f.transpose(1, 2)
                for c, n in zip(self.temp, self.tn): h = n(F.gelu(c(h)) + h)  # SHARED dilated-causal temporal (anchored)
                h = h.transpose(1, 2)
            w = torch.softmax(self.qpool(h).squeeze(-1), 1)
            z = hb + torch.tanh(self.al) * self.ldrop((h * w.unsqueeze(-1)).sum(1))  # gated LOB increment onto base
        if self.use_basket:                                               # STEP3: EXOGENOUS market-context token (diagonal-masked; warmup-gated; weak assets only)
            zt = z.reshape(B, S, -1)
            ztd = zt.detach()                                             # stop-grad: basket READS the market for the weak asset but does NOT pull other assets' training (protects mid-caps + regularizes)
            sc = self.bq(ztd).squeeze(-1)                                  # (B,S) per-asset key score (on exogenous context)
            attn = sc.unsqueeze(1).expand(B, S, S).clone()                # (B,query,key) -> each asset sees the market
            di = torch.arange(S, device=z.device); attn[:, di, di] = float('-inf')   # mask self -> strictly exogenous
            ctx = self.bdrop(self.bproj(torch.bmm(torch.softmax(attn, -1), ztd)))    # (B,S,d) market-direction context (detached + dropout)
            gate = (torch.tanh(self.gb) * self.strong_mask * self.warmup).view(1, S, 1)
            z = (zt + gate * ctx).reshape(B * S, -1)                       # query's OWN zt keeps gradient; only the context is detached
            self._varpen = F.relu(0.3 - ztd.std(1)).mean()               # anti-collapse guard (read by loss if basket on)
        if self.use_btc_fusion and btc_tok is not None:                   # Phase 15: inject frozen-BTC-teacher signal (btc_tok is exogenous data -> NO teacher gradient; only the projections train)
            zt = z.reshape(B, S, -1)                                       # (B,S,d)
            bt = self.btc_in(btc_tok)                                      # (B,K,34) -> (B,K,d) per-lag projected token
            q = self.btc_q(zt); k = self.btc_k(bt); v = self.btc_v(bt)     # asymmetric: alt zt=query, BTC-lag tokens=K/V
            attn = torch.softmax(torch.bmm(q, k.transpose(1, 2)) / (q.shape[-1] ** 0.5), -1)  # (B,S,K) each alt weights WHICH lag of BTC leads it
            ctx = self.btc_drop(torch.bmm(attn, v))                        # (B,S,d) lead-lag-selected BTC context
            gate = (torch.tanh(self.gf_btc) * self.btc_alt_mask * self.warmup).view(1, S, 1)  # alts only (BTC excluded), identity-init, warmup-ramped
            bself = self.btc_self(bt[:, 0])                                # (B,d) BTC own-slice direct h_pred residual from lag0
            gs = torch.tanh(self.g_btc_self) * self.warmup
            z = (zt + gate * ctx + self.btc_self_mask.view(1, S, 1) * (gs * bself).unsqueeze(1)).reshape(B * S, -1)  # alts get gated BTC context; BTC slice gets gated direct residual
        if self.use_regime_film:                                          # STEP2: condition on causal regime prior BEFORE per-asset FiLM
            z = self.regime_film(z, hz.reshape(B * S, self.n_hand)[:, REGIME])
        g, bta = self.pfilm(aid).chunk(2, -1); z = z * (1 + g) + bta
        q50, sl, ma = self.head(z)
        ss = self.sigma_scale[aid] if self.per_asset else self.sigma_scale  # per-asset output-gain beta knob
        q50 = q50 * ss
        return q50.reshape(B, S), sl.reshape(B, S), ma.reshape(B, S), self.rank(z).squeeze(-1).reshape(B, S)

def huber(p, y, d=1.0):
    e = (p - y).abs(); return torch.where(e <= d, 0.5 * e * e, d * (e - 0.5 * d))

def make_batch(samples, idx, rawlob, win, sub, use_lob):
    hs = np.stack([samples[i][2] for i in idx]); ys = np.stack([samples[i][3] for i in idx]); vs = np.stack([samples[i][4] for i in idx])
    hand = torch.from_numpy(np.nan_to_num(hs)); y = torch.from_numpy(np.nan_to_num(ys)); v = torch.from_numpy(vs)
    lob = None
    if use_lob:
        L = win // sub
        arr = np.empty((len(idx), L, S, len(RLOF)), np.float32)  # book38+flow9
        for j, i in enumerate(idx):
            d, t, *_ = samples[i]; arr[j] = np.nan_to_num(rawlob[d][t - win + 1: t + 1: sub])
        lob = torch.from_numpy(arr)
    return hand, lob, y, v

@torch.no_grad()
def evaluate(model, samples, rawlob, win, sub, use_lob, ymad, ymed, bs=192):
    model.eval(); P = np.zeros((len(samples), S), np.float32); Y = np.zeros((len(samples), S), np.float32); V = np.zeros((len(samples), S), bool)
    for i in range(0, len(samples), bs):
        idx = list(range(i, min(i + bs, len(samples))))
        hand, lob, y, v = make_batch(samples, idx, rawlob, win, sub, use_lob)
        q, _, _, _ = model(hand.to(dev), lob.to(dev) if lob is not None else None)
        P[idx] = q.cpu().numpy(); Y[idx] = y.numpy(); V[idx] = v.numpy()
    P = P * ymad + ymed; res = {}
    for a in UNIV10:
        p = P[:, a]; yy = Y[:, a]; m = V[:, a] & np.isfinite(p) & np.isfinite(yy)
        if m.sum() < 100 or np.std(p[m]) < 1e-12: continue
        pc = np.corrcoef(p[m], yy[m])[0, 1]; beta = np.cov(yy[m], p[m])[0, 1] / np.var(p[m])
        sr = np.std(p[m]) / (np.std(yy[m]) + 1e-12); sh = np.mean(np.sign(p[m]) == np.sign(yy[m]))
        res[a] = (pc, beta, sr, sh)
    return res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--train_start", type=int, default=20230828); ap.add_argument("--train_end", type=int, default=20250418)
    ap.add_argument("--eval_start", type=int, default=20250419); ap.add_argument("--eval_end", type=int, default=20250518)
    ap.add_argument("--win", type=int, default=600); ap.add_argument("--sub", type=int, default=1)
    ap.add_argument("--stride", type=int, default=360); ap.add_argument("--epochs", type=int, default=14)
    ap.add_argument("--bs", type=int, default=96); ap.add_argument("--lr", type=float, default=8e-4)
    ap.add_argument("--wd", type=float, default=1e-3); ap.add_argument("--d", type=int, default=96)
    ap.add_argument("--sign_w", type=float, default=0.1); ap.add_argument("--rank_w", type=float, default=0.3)
    ap.add_argument("--magf_w", type=float, default=0.3); ap.add_argument("--no_lob", action="store_true")  # restored to foundation recipe
    ap.add_argument("--patience", type=int, default=4)  # early stop: stop if vselP has not improved for N epochs
    ap.add_argument("--patch_agg", choices=["mean", "stats", "conv"], default="mean")
    ap.add_argument("--pre_temporal", action="store_true")  # A1: 1s dilated-causal temporal BEFORE patch
    ap.add_argument("--use_flow", action="store_true")      # A4: per-second signed order-flow stream
    ap.add_argument("--per_asset", action="store_true")     # per-asset gates+sigma (BTC opts out of flow; per-asset beta)
    ap.add_argument("--use_regime_film", action="store_true")  # STEP2: regime-prior FiLM
    ap.add_argument("--use_basket", action="store_true")    # STEP3: asymmetric cross-asset basket token
    ap.add_argument("--smoke", action="store_true")
    a = ap.parse_args(); set_seed(42); use_lob = not a.no_lob
    tr = dr(a.train_start, a.train_end); vsel = tr[-20:]; tr = tr[:-20]
    if a.smoke: tr = tr[:8]; vsel = vsel[:3]; a.epochs = 2
    t0 = time.perf_counter()
    print(f"[preload] train {len(tr)}d ...", flush=True)
    rl_tr, sm_tr = preload(tr, a.win, a.stride)
    rl_vs, sm_vs = preload(vsel, a.win, 600); rl_ev, sm_ev = preload(dr(a.eval_start, a.eval_end), a.win, 600)
    print(f"  preloaded train={len(sm_tr)} vsel={len(sm_vs)} eval={len(sm_ev)} in {time.perf_counter()-t0:.0f}s", flush=True)
    # frozen-train per-feature robust-z (handcrafted) + target MAD-z, from train samples
    hf = np.stack([sm_tr[i][2] for i in range(0, len(sm_tr), max(1, len(sm_tr)//6000))]).reshape(-1, FALL)
    hmed = np.nan_to_num(np.median(hf, 0)); hmad = 1.4826 * np.median(np.abs(hf - hmed), 0) + 1e-6
    hmad = np.where(np.isfinite(hmad) & (hmad > 1e-9), hmad, 1.0)
    yt = np.stack([sm_tr[i][3] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))]); vt = np.stack([sm_tr[i][4] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))])
    yv = np.where(vt, yt, np.nan); ymed = np.nan_to_num(np.nanmedian(yv, 0, keepdims=True))
    ymad = 1.4826 * np.nanmedian(np.abs(yv - ymed), 0, keepdims=True); ymad = np.where(np.isfinite(ymad) & (ymad > 1e-12), ymad, 1.0) + 1e-12
    model = LOBNet3(hmed, hmad, d=a.d, use_lob=use_lob, patch_agg=a.patch_agg, pre_temporal=a.pre_temporal, use_flow=a.use_flow,
                    per_asset=a.per_asset, use_regime_film=a.use_regime_film, use_basket=a.use_basket).to(dev)
    print(f"  params={sum(p.numel() for p in model.parameters()):,} pre_temporal={a.pre_temporal} use_flow={a.use_flow} per_asset={a.per_asset} regime_film={a.use_regime_film}", flush=True)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    outdir = Path(f"/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments/diagnostic_{a.tag}"); outdir.mkdir(parents=True, exist_ok=True)
    ym = torch.from_numpy(ymed.astype(np.float32)).to(dev); yd = torch.from_numpy(ymad.astype(np.float32)).to(dev)
    rng = np.random.default_rng(42); N = len(sm_tr); best = -1e9; bad = 0
    def cos(ep): return a.lr * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * ep / a.epochs))) if ep > 2 else a.lr * ep / 2
    for ep in range(1, a.epochs + 1):
        for g in opt.param_groups: g['lr'] = cos(ep)
        model.train(); perm = rng.permutation(N); losses = []; te = time.perf_counter()
        for i in range(0, N - a.bs + 1, a.bs):
            idx = perm[i:i + a.bs]
            hand, lob, yraw, vb = make_batch(sm_tr, idx, rl_tr, a.win, a.sub, use_lob)
            hand = hand.to(dev); yraw = yraw.to(dev); vb = vb.to(dev); vf = vb.float()
            if vf.sum() < 1: continue
            yz = torch.clamp((yraw - ym) / yd, -6, 6)
            opt.zero_grad(set_to_none=True)
            q, slog, ma, rk = model(hand, lob.to(dev) if lob is not None else None)
            magl = (huber(q, yz) * vf).sum() / vf.sum().clamp(min=1)
            wsign = (yz.abs().clamp(max=5).pow(1.5) * (yz.abs() > 0.5).float() + 1e-3) * vf
            sign = (F.binary_cross_entropy_with_logits(slog, (yz > 0).float(), reduction='none') * wsign).sum() / wsign.sum().clamp(min=1)
            magf = (huber(ma, yz.abs()) * (1 + yz.abs()) * vf).sum() / ((1 + yz.abs()) * vf).sum().clamp(min=1)
            ydem = yz - (yz * vf).sum(1, keepdim=True) / vf.sum(1, keepdim=True).clamp(min=1)  # B1: rank the CS-demeaned (idio) target, not market-laden raw
            rankl = lambdarank_loss(rk, ydem, vb)
            loss = magl + a.sign_w * sign + a.magf_w * magf + a.rank_w * rankl
            if not torch.isfinite(loss): continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); losses.append(loss.item())
        rv = evaluate(model, sm_vs, rl_vs, a.win, a.sub, use_lob, ymad, ymed); pv = np.nanmean([rv[x][0] for x in rv]) if rv else np.nan
        mark = ""
        if np.isfinite(pv) and pv > best + 1e-5: best = pv; bad = 0; torch.save(model.state_dict(), outdir / "best.pt"); mark = "★"
        else: bad += 1
        print(f"ep{ep:02d}/{a.epochs} loss={np.mean(losses):.4f} vselP={pv:+.4f} bad={bad} ({time.perf_counter()-te:.0f}s){mark}", flush=True)
        if bad >= a.patience and ep >= 5: print(f"[early-stop] vselP no improvement for {bad} epochs", flush=True); break
    if not (outdir / "best.pt").exists(): torch.save(model.state_dict(), outdir / "best.pt")
    model.load_state_dict(torch.load(outdir / "best.pt", map_location=dev))
    res = evaluate(model, sm_ev, rl_ev, a.win, a.sub, use_lob, ymad, ymed)
    print(f"\n=== OOS {a.eval_start}->{a.eval_end} (full {a.win}s@{a.sub}s LOB, in-RAM) per-asset ===", flush=True)
    ps, bs_, srs, shs = [], [], [], []
    for x in UNIV10:
        if x not in res: continue
        pc, be, sr, sh = res[x]; ps.append(pc); bs_.append(be); srs.append(sr); shs.append(sh)
        print(f"  {UNIV_NAMES[x]:5s} P={pc:+.4f} beta={be:+.2f} sigR={sr:.3f} sign={sh:.3f}", flush=True)
    print(f"  MEAN  P={np.nanmean(ps):+.4f} beta={np.nanmean(bs_):+.2f} sigR={np.nanmean(srs):.3f} sign={np.nanmean(shs):.3f}", flush=True)
    print(f"  vs stage1 coarse-LOB 0.0421 / ridge 0.027 | GOAL P>0.07 beta≈1 sign>0.53", flush=True)
    print("DONE", flush=True)

if __name__ == "__main__":
    main()
