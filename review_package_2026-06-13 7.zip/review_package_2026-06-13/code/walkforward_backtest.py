"""HARDEN the y_1800 tradeable deliverable: walk-forward L/S portfolio backtest across 2023-2025.
Ridge (conservative lower bound; the DL deliverable does >=). Per fold: fit ridge on train idio-y_1800,
rank-weight vol-scaled dollar-neutral L/S on OOS, net Sharpe @ cost sweep + turnover. Leak-free (tier4 dropped).
Mission gate: net Sharpe >= 1.5 @2bp, robust across folds. Mirrors bt_csranker_seq portfolio+cost+ann.
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from scipy.stats import rankdata
from sklearn.linear_model import Ridge
from gbdt_cs_alpha import csd
from train_cs_ranker import UNIV10
from walkforward_revalidate import load, NTR, NTE, STEP
from gbdt_cs_alpha import NPZ

HS=[1800,3600]; HOLDS=[1,2,3]; COSTS=[0,1,2,3]

def bt(pred,Yd,avol,hold,costs,ann):
    T,Sn=pred.shape; W=np.zeros((T,Sn))
    for t in range(T):
        v=np.isfinite(pred[t])&np.isfinite(Yd[t])
        if v.sum()<4: continue
        r=np.full(Sn,np.nan); r[v]=rankdata(pred[t,v]); r=r-np.nanmean(r)
        raw=np.where(v,r/avol,0.0); gl=np.abs(raw).sum()
        if gl>1e-12: W[t]=raw/gl
    for t in range(T):
        if t%hold!=0: W[t]=W[t-1]
    pnl=np.nansum(W*np.where(np.isfinite(Yd),Yd,0.0),1)
    dW=np.abs(np.diff(W,axis=0,prepend=0)).sum(1); turn=float(dW.mean())
    nets={c:float((pnl-dW*c*1e-4*0.5).mean()/((pnl-dW*c*1e-4*0.5).std()+1e-12)*ann) for c in costs}
    return float(pnl.mean()/(pnl.std()+1e-12)*ann), nets, turn

def main():
    days=sorted([int(p.name) for p in NPZ.iterdir() if p.name.isdigit() and (p/"X.npy").exists()])
    folds=[]; i=0
    while i+NTR+NTE<=len(days):
        folds.append((days[i:i+NTR],days[i+NTR:i+NTR+NTE])); i+=STEP
    print(f"{len(days)} days; {len(folds)} folds; HOLDS={HOLDS} COSTS={COSTS}; tier4 DROPPED, ridge L/S\n",flush=True)
    for H in HS:
        ann=np.sqrt(31536000.0/H)
        agg={(h,c):[] for h in HOLDS for c in COSTS}; turns={h:[] for h in HOLDS}
        print(f"===== y_{H} (ann={ann:.1f}) =====",flush=True)
        for fi,(tr,te) in enumerate(folds):
            Xtr,ytr=load(tr,H,360)
            if Xtr is None: continue
            Xte,yte=load(te,H,H)
            if Xte is None: continue
            t,S,F=Xtr.shape; xr=Xtr.reshape(t*S,F); yi=csd(ytr).reshape(t*S); v=np.isfinite(yi)&np.all(np.isfinite(xr),1)
            rg=Ridge(alpha=100.0).fit(xr[v],yi[v])
            tw,Sw,_=Xte.shape; xw=Xte.reshape(tw*Sw,F); ok=np.all(np.isfinite(xw),1)
            pr=np.where(ok,rg.predict(np.nan_to_num(xw)),np.nan).reshape(tw,Sw)
            prU=pr[:,UNIV10]; yU=yte[:,UNIV10]; avol=np.nanstd(ytr[:,UNIV10],0)+1e-9
            line=f"  fold{fi} OOS {te[0]}..{te[-1]}: "
            for h in HOLDS:
                gs,nets,turn=bt(prU,yU,avol,h,COSTS,ann); turns[h].append(turn)
                for c in COSTS: agg[(h,c)].append(nets[c])
                line+=f"h{h}[gross={gs:+.1f} @2bp={nets[2]:+.2f}] "
            print(line,flush=True)
        print(f"  --- AGG net Sharpe (mean across {len(folds)} folds) ---",flush=True)
        for h in HOLDS:
            row=" ".join(f"@{c}bp={np.mean(agg[(h,c)]):+.2f}(min {np.min(agg[(h,c)]):+.2f},{int((np.array(agg[(h,c)])>0).sum())}/{len(agg[(h,c)])}+)" for c in COSTS)
            print(f"  hold={h} ({h*H//60}min) turn={np.mean(turns[h]):.3f}: {row}",flush=True)
        print(flush=True)
    print("MISSION GATE: net Sharpe >=1.5 @2bp robust across folds. Ridge=lower bound; DL deliverable >=.",flush=True)

if __name__=="__main__":
    main()
