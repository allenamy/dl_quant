"""COMPLETE metric comparison: ridge vs GBDT vs DL, ALL metrics, same W1-W4 windows.

Answers "you only showed cs-rank where DL=tree; where are the other metrics?".
For BOTH targets (IDIO=cs-demeaned, RAW=market-laden) reports, AGG over W1-W4:
  - cs_spear_9 (cross-sectional rank)            <- the rank metric
  - per-asset Pearson (each + mean)              <- the MAGNITUDE metric (DL's raw-LOB edge should show here)
  - L-S net Sharpe @2bp                          <- the money metric
Ridge/GBDT see only the SNAPSHOT (224-dim raw+csz). DL (E215c) additionally sees the raw-LOB
TEMPORAL SEQUENCE. So DL-minus-GBDT per-asset Pearson = the measured value of the temporal/raw-LOB edge.
DL reference rows are pasted from the diagnostic logs (idio target).
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from scipy.stats import rankdata
import lightgbm as lgb
from sklearn.linear_model import Ridge
from gbdt_cs_alpha import load, csfeat, csd, dr, UNIV9, NPZ, H, eval_pred, flatten

ANAME = {0:"BTC",13:"ETC",4:"XRP",11:"DOT",2:"SOL",12:"FIL",5:"DOG",7:"LINK",9:"TRX"}
WINDOWS = [("W1",20250425,20250509),("W2",20250510,20250524),("W3",20250525,20250608),("W4",20250609,20250624)]
TRAIN = (20240316,20250420)

def prep(X, Y, demean):
    Xf = csfeat(X)                                  # (t,S,2F=224)
    Yt = csd(Y) if demean else np.where(np.isfinite(Y), Y, np.nan)
    t, S, F2 = Xf.shape
    xr = Xf.reshape(t*S, F2); yr = Yt.reshape(t*S)
    valid = np.isfinite(yr) & np.isfinite(xr).all(1)
    return xr, yr, valid, t, S

def per_asset_pearson(pred, yv):                    # (t,S) -> {asset: corr}
    out = {}
    for a in UNIV9:
        p, y = pred[:, a], yv[:, a]; m = np.isfinite(p) & np.isfinite(y)
        out[ANAME[a]] = (np.corrcoef(p[m], y[m])[0,1]
                         if m.sum() > 50 and p[m].std() > 1e-12 and y[m].std() > 1e-12 else np.nan)
    return out

def cs_spear(pred, yv, t):
    cs = []
    for ti in range(t):
        row, yr = pred[ti, UNIV9], yv[ti, UNIV9]; v = np.isfinite(row) & np.isfinite(yr)
        if v.sum() >= 5 and np.std(row[v]) > 1e-12: cs.append(np.corrcoef(rankdata(row[v]), rankdata(yr[v]))[0,1])
    return np.nanmean(cs) if cs else np.nan

def fit_models(demean):
    Xtr, Ytr, _ = load(dr(*TRAIN), 180)
    xtr, ytr, vtr, _, _ = prep(Xtr, Ytr, demean)
    print(f"  train snapshots*assets={vtr.sum()} feat={xtr.shape[1]}", flush=True)
    ridge = Ridge(alpha=100.0).fit(xtr[vtr], ytr[vtr])
    gbdt = lgb.LGBMRegressor(objective="regression_l2", num_leaves=15, min_child_samples=2000,
        learning_rate=0.03, feature_fraction=0.5, bagging_fraction=0.7, bagging_freq=1,
        lambda_l2=5.0, n_estimators=300, verbose=-1, n_jobs=8).fit(xtr[vtr], ytr[vtr])
    return ridge, gbdt

def eval_window_agg(model, demean):
    pa_acc = {ANAME[a]: [] for a in UNIV9}; css = []; nets = []
    for wn, wa, wb in WINDOWS:
        Xv, Yv, Tv = load(dr(wa, wb), 600)
        if Xv is None: continue
        xte, yte, vte, t, S = prep(Xv, Yv, demean)
        pr = model.predict(xte); pr = np.where(vte, pr, np.nan)
        pred = pr.reshape(t, S); yvv = np.where(vte, yte, np.nan).reshape(t, S)
        for k, v in per_asset_pearson(pred, yvv).items(): pa_acc[k].append(v)
        css.append(cs_spear(pred, yvv, t))
        # L-S net Sharpe @2bp via the shared harness (always on demeaned y for the trade)
        _, _, _ = 0, 0, 0
        xf2, yf2, gf2, af2, vf2, t2, S2 = flatten(Xv, Yv, Tv)
        cs2, net2, _ = eval_pred(np.where(vf2, model.predict(xf2), np.nan), np.where(vf2, yf2, np.nan), gf2, af2, t2, S2)
        nets.append(net2)
    pa = {k: np.nanmean(v) for k, v in pa_acc.items()}
    return np.nanmean(css), pa, np.nanmean(nets)

def report(name, demean):
    print(f"\n{'='*70}\n{name}\n{'='*70}", flush=True)
    ridge, gbdt = fit_models(demean)
    for mname, m in [("ridge", ridge), ("GBDT", gbdt)]:
        cs, pa, net = eval_window_agg(m, demean)
        pam = np.nanmean(list(pa.values()))
        pastr = " ".join(f"{k}:{v:+.3f}" for k, v in pa.items())
        print(f"\n[{mname}] cs_spear_9={cs:+.4f}  per-asset Pearson mean={pam:+.4f}  L-S net@2bp Sharpe={net:+.2f}", flush=True)
        print(f"   {pastr}", flush=True)

def main():
    report("TARGET = IDIO (cross-sectionally demeaned) — the market-neutral metric", demean=True)
    report("TARGET = RAW (market-laden return) — the directional metric (single-asset analog)", demean=False)
    print(f"\n{'='*70}\nDL REFERENCE (E215c transformer, idio target, raw-LOB temporal seq, W1-W4 AGG):")
    print("  cs_spear_9=+0.0526  per-asset mean=+0.0440")
    print("  BTC:+0.024 ETC:+0.063 XRP:+0.040 DOT:+0.072 SOL:+0.013 FIL:+0.091 DOG:+0.015 LINK:+0.044 TRX:+0.010")
    print("  (single-asset REG_arch BTC RAW return Pearson = 0.067, DL >> ridge/tree)")
    print("INTERP: DL-minus-GBDT on per-asset Pearson = measured value of the temporal/raw-LOB edge on MAGNITUDE.")

if __name__ == "__main__":
    main()
