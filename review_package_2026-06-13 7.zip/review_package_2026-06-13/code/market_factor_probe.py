"""DECISIVE PROBE: is the MARKET FACTOR (cross-sectional mean of raw y_600) under-extracted or at ceiling?

Puzzle: averaging 14 correlated assets REDUCES idio noise, so the market factor should be MORE
predictable than any single asset. Yet F̂ (the multi-target market head) caps at ~0.025 while
single-asset BTC raw = 0.067. If a simple ridge/GBDT on MARKET-AGGREGATE features predicts the
market factor >> 0.025, then F̂ is UNDER-EXTRACTING (a dedicated market model is a real lever);
if it also caps ~0.025, the market factor genuinely caps in our features and 0.067 is BTC-specific.

Market-aggregate feature = mean over UNIV9 of the raw-half features per snapshot (the market state).
Target = cm[t] = mean over UNIV9 of raw y_600[t] (the market move). Ridge + GBDT, walk-forward W1-W4.
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from sklearn.linear_model import Ridge
import lightgbm as lgb
from gbdt_cs_alpha import load, dr, UNIV9, NPZ, H

WINDOWS=[("W1",20250425,20250509),("W2",20250510,20250524),("W3",20250525,20250608),("W4",20250609,20250624)]
TRAIN=(20240901,20250420)
FRAW=112  # raw feature half

def agg(X,Y):
    # market-aggregate features (mean over UNIV9 of raw half) + market target (mean over UNIV9 of raw y)
    Xu=X[:,UNIV9,:FRAW]                      # (T,9,112) raw half
    fm=np.nanmean(np.where(np.isfinite(Xu),Xu,np.nan),1)   # (T,112) market-avg feature state
    ym=np.nanmean(np.where(np.isfinite(Y[:,UNIV9]),Y[:,UNIV9],np.nan),1)  # (T,) market factor
    v=np.isfinite(ym)&np.all(np.isfinite(fm),1)
    return np.nan_to_num(fm),ym,v

def pear(a,b):
    m=np.isfinite(a)&np.isfinite(b)
    return np.corrcoef(a[m],b[m])[0,1] if m.sum()>50 and np.std(a[m])>1e-12 and np.std(b[m])>1e-12 else np.nan

def main():
    Xt,Yt,_=load(dr(*TRAIN),180)
    ftr,ytr,vtr=agg(Xt,Yt)
    print(f"train market snapshots={vtr.sum()} feat={ftr.shape[1]}",flush=True)
    ridge=Ridge(alpha=50.0).fit(ftr[vtr],ytr[vtr])
    gbdt=lgb.LGBMRegressor(objective="regression_l2",num_leaves=15,min_child_samples=500,learning_rate=0.03,
        feature_fraction=0.6,bagging_fraction=0.7,bagging_freq=1,lambda_l2=5.0,n_estimators=300,verbose=-1,n_jobs=8).fit(ftr[vtr],ytr[vtr])
    rp,gp=[],[]
    for wn,wa,wb in WINDOWS:
        Xv,Yv,_=load(dr(wa,wb),600)
        if Xv is None: continue
        fv,yv,vv=agg(Xv,Yv)
        rpr=pear(np.where(vv,ridge.predict(fv),np.nan),np.where(vv,yv,np.nan))
        gpr=pear(np.where(vv,gbdt.predict(fv),np.nan),np.where(vv,yv,np.nan))
        rp.append(rpr);gp.append(gpr)
        print(f"  {wn}: ridge_R={rpr:+.4f} gbdt_R={gpr:+.4f}",flush=True)
    print(f"\n=== MARKET-FACTOR predictability (AGG) ===",flush=True)
    print(f"  ridge: {np.nanmean(rp):+.4f}   gbdt: {np.nanmean(gp):+.4f}",flush=True)
    print(f"  vs multi-target F̂=0.025, single-asset BTC raw=0.067",flush=True)
    best=max(np.nanmean(rp),np.nanmean(gp))
    print(f"  -> {'F̂ UNDER-EXTRACTING: build dedicated market model' if best>0.040 else 'market factor CAPS ~'+f'{best:.3f}'+': 0.067 is BTC-specific microstructure, not market'}",flush=True)

if __name__=="__main__":
    main()
