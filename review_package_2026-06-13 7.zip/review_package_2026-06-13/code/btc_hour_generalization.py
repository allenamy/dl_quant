"""Phase 15 pre-check: does the frozen BTC teacher generalize across UTC hours?

npz_v4 (the teacher's TRAINING data) covers only ~UTC 04-19h (partial day). The multi-asset day adds the
UTC evening/night hours the teacher likely never trained on. This script builds full days, runs the teacher
encode, and reports Pearson(q50, realized y_600) BY UTC HOUR. If evening hours hold a useful Pearson, the
full-day teacher rebuild is justified (it would lift coverage 38%->~100%). If they crater, the teacher can't
help there and full coverage won't reach morning-only quality.

Run cwd = single-asset repo so `import src.*` resolves there:
  cd /mnt/storage/private/work_hsy/quant_research && \
  python /mnt/storage/private/work_hsy/quant_research_multi_asset/scripts/btc_hour_generalization.py \
      --days /tmp/npz_fullday_pretest --fold 1
"""
from __future__ import annotations
import argparse, sys, datetime as dt
from pathlib import Path
import numpy as np, torch

sys.path.insert(0, "/mnt/storage/private/work_hsy/quant_research_multi_asset/scripts")
from extract_h_pred import load_teacher


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", default="/tmp/npz_fullday_pretest")
    ap.add_argument("--fold", type=int, default=1)
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    m, xm, safe, _ = load_teacher(a.fold, dev)
    Q, Y, HR = [], [], []
    for p in sorted(Path(a.days).glob("*.npz")):
        z = np.load(p, allow_pickle=True)
        X = z["X"].astype(np.float32); Xr = z["X_raw"].astype(np.float32); rp = z["regime_prior"].astype(np.float32)
        ts = z["timestamps"].astype(np.int64); y = z["y_600"].astype(np.float64)
        Xn = (X - xm) / safe
        q = []
        for i in range(0, len(Xn), 512):
            out = m.forward(x_feat=torch.from_numpy(Xn[i:i + 512]).to(dev),
                            x_raw=torch.from_numpy(Xr[i:i + 512]).to(dev),
                            regime_prior=torch.from_numpy(rp[i:i + 512]).to(dev))
            q.append(out["quantiles"][:, 1].float().cpu().numpy())
        q = np.concatenate(q)
        hrs = np.array([dt.datetime.fromtimestamp(int(t) / 1e6, dt.timezone.utc).hour for t in ts])
        Q.append(q); Y.append(y); HR.append(hrs)
    Q = np.concatenate(Q); Y = np.concatenate(Y); HR = np.concatenate(HR)
    mf = np.isfinite(Q) & np.isfinite(Y)
    Q, Y, HR = Q[mf], Y[mf], HR[mf]
    print(f"\n=== BTC teacher q50-vs-y600 generalization by UTC hour (fold{a.fold}, n={len(Q)}) ===")
    print(f"OVERALL Pearson = {np.corrcoef(Q, Y)[0, 1]:+.4f}")
    for h0 in range(0, 24, 2):
        msk = (HR >= h0) & (HR < h0 + 2)
        if msk.sum() > 80 and np.std(Q[msk]) > 1e-12:
            print(f"  UTC {h0:02d}-{h0+2:02d}: n={msk.sum():5d} P={np.corrcoef(Q[msk], Y[msk])[0, 1]:+.4f}")
    for lab, lo, hi in [("teacher-SEEN  ~04-19 UTC", 4, 19), ("teacher-UNSEEN 19-04 UTC", 19, 28)]:
        msk = ((HR >= lo) & (HR < hi)) if hi <= 24 else ((HR >= lo) | (HR < hi - 24))
        if msk.sum() > 80:
            print(f"  {lab}: n={msk.sum()} P={np.corrcoef(Q[msk], Y[msk])[0, 1]:+.4f}")
    print("DONE")


if __name__ == "__main__":
    main()
