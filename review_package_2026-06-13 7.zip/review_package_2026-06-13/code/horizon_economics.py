"""HORIZON ECONOMICS — pick the optimal prediction window for the multi-asset L/S task.

IC alone is the WRONG figure of merit. The tradeable quantity per rebalance is the realized
LONG-SHORT decile spread (gross edge/trade), which ~ IC(h) x sigma_idio(h). User's hypothesis:
longer h -> bigger sigma_idio -> bigger gross/trade, so even with lower IC the per-trade margin
(and cost amortization) can win. We verify with data, then net vs a FIXED per-rebalance cost and
divide by holding time to get a per-unit-TIME rate (short h trades more often but pays cost more often).

Per horizon h (NON-OVERLAPPING holds, stride=h, eval W1-W4):
  IC          = cs_spear (ridge predictor vs idio y_h)
  sigma_idio  = cross-sectional std of demeaned y_h over UNIV10 (bps)  <- the user's sigma_ytrue
  gross/trade = realized top3-bottom3 spread, ranked by RIDGE pred (bps)  [realizable]
  oracle      = same spread ranked by TRUE idio y_h (bps)                 [ceiling]
  net/trade@c = gross - c   (c = round-trip cost per rebalance, bps)
  rebal/day   = 85800 / h
  net/day@c   = net/trade * rebal/day   (the per-unit-TIME rate -> decides optimal h)
Longer horizons 7200/14400 built EXACTLY by additivity: y_{2h}[t]=y_h[t]+y_h[t+h].
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from scipy.stats import rankdata
from sklearn.linear_model import Ridge
from gbdt_cs_alpha import csfeat, csd, dr, NPZ
from train_cs_ranker import UNIV10, UNIV_NAMES

WINDOWS=[("W1",20250425,20250509),("W2",20250510,20250524),("W3",20250525,20250608),("W4",20250609,20250624)]
TRAIN=(20240901,20250420)
BASE_HS=[120,300,600,1800,3600]          # directly available
LONG_HS=[7200,14400]                      # built from y_3600 by additivity
HS=BASE_HS+LONG_HS
TDAY=85800; K=3                           # top-K / bottom-K decile spread (10-asset universe)

def build_yh_full(day, h):
    """Full-day y_h array. h<=3600 direct; h>3600 = sum of y_3600 at offsets (log-return additivity)."""
    if h in BASE_HS:
        p=NPZ/str(day)/f"y_{h}.npy"
        return np.asarray(np.load(p,mmap_mode="r"),np.float32) if p.exists() else None
    p=NPZ/str(day)/"y_3600.npy"
    if not p.exists(): return None
    y=np.asarray(np.load(p,mmap_mode="r"),np.float32); T=y.shape[0]; n=h//3600
    out=np.full_like(y,np.nan); vl=T-h
    if vl<=0: return out
    acc=np.zeros((vl,)+y.shape[1:],np.float32)
    for k in range(n): acc=acc+y[3600*k:3600*k+vl]   # y_{n*3600}[t] = sum_k y_3600[t+3600k] (log-return additivity)
    out[:vl]=acc
    return out

def load_h(dates, h, stride):
    """X (cs-z featurized) + y_h, NON-OVERLAPPING at stride, valid t<T-h."""
    Xs=[]; Ys=[]
    for d in dates:
        xp=NPZ/str(d)/"X.npy"
        if not xp.exists(): continue
        yh=build_yh_full(d,h)
        if yh is None: continue
        X=np.load(xp,mmap_mode="r"); T=min(X.shape[0],yh.shape[0]); idx=np.arange(0,T-h,stride)
        if len(idx)==0: continue
        Xs.append(np.asarray(X[idx],np.float32)); Ys.append(yh[idx])
    if not Xs: return None,None
    return csfeat(np.concatenate(Xs)), np.concatenate(Ys)

def decile_spread(pred,yv):
    """mean(top-K y) - mean(bottom-K y), ranked by pred, over UNIV10. bps. Avg over snapshots."""
    sp=[]
    for t in range(pred.shape[0]):
        p=pred[t,UNIV10]; y=yv[t,UNIV10]; v=np.isfinite(p)&np.isfinite(y)
        if v.sum()<2*K: continue
        pi=np.where(v)[0]; order=pi[np.argsort(p[v])]
        lo=y[order[:K]]; hi=y[order[-K:]]
        sp.append(np.nanmean(hi)-np.nanmean(lo))
    return np.array(sp)*1e4  # bps

def sigma_idio(yv):
    s=[]
    for t in range(yv.shape[0]):
        y=yv[t,UNIV10]; v=np.isfinite(y)
        if v.sum()>=5: s.append(np.std(csd(y[None,:])[0][v]))
    return float(np.nanmean(s))*1e4 if s else np.nan

def cs_spear(pred,yv):
    cs=[]
    for t in range(pred.shape[0]):
        r=pred[t,UNIV10]; y=yv[t,UNIV10]; v=np.isfinite(r)&np.isfinite(y)
        if v.sum()>=5 and np.std(r[v])>1e-12 and np.std(y[v])>1e-12: cs.append(np.corrcoef(rankdata(r[v]),rankdata(y[v]))[0,1])
    return float(np.nanmean(cs)) if cs else np.nan

def main():
    COSTS=[0,1,2,3,5]
    rows=[]
    print("loading per horizon (train fit @stride=h, eval @stride=h non-overlap)...\n",flush=True)
    for h in HS:
        Xtr,ytr=load_h(dr(*TRAIN),h,180)   # DENSE train stride (fitting only; overlap fine) — do NOT starve long-h ridge
        if Xtr is None: print(f"h={h}: no data"); continue
        ridge=Ridge(alpha=100.0)
        t,Sn,F2=Xtr.shape; xr=Xtr.reshape(t*Sn,F2); yrd=csd(ytr).reshape(t*Sn)
        ok=np.isfinite(yrd)&np.all(np.isfinite(xr),1); ridge.fit(xr[ok],yrd[ok])
        ic=[]; sig=[]; gtr=[]; orc=[]
        for wn,wa,wb in WINDOWS:
            Xw,yw=load_h(dr(wa,wb),h,h)
            if Xw is None: continue
            tw,Sw,_=Xw.shape; xw=Xw.reshape(tw*Sw,F2); m=np.all(np.isfinite(xw),1)
            pr=np.where(m,ridge.predict(np.nan_to_num(xw)),np.nan).reshape(tw,Sw)
            ywd=csd(yw)
            ic.append(cs_spear(pr,ywd)); sig.append(sigma_idio(yw))
            gtr.append(np.nanmean(decile_spread(pr,ywd)))       # realizable (ridge-ranked, idio y)
            orc.append(np.nanmean(decile_spread(ywd,ywd)))      # oracle ceiling
        ic=np.nanmean(ic); sig=np.nanmean(sig); gross=np.nanmean(gtr); oracle=np.nanmean(orc)
        rebal=TDAY/h
        rows.append((h,rebal,ic,sig,gross,oracle))
        print(f"h={h:>5}: rebal/day={rebal:7.1f}  IC={ic:+.4f}  sigma_idio={sig:6.2f}bps  gross/trade={gross:+6.2f}bps  oracle={oracle:+6.2f}bps",flush=True)
    print("\n=== NET PER TRADE (gross - c) and NET PER DAY (net * rebal/day), bps ===",flush=True)
    hdr="  h    | " + " | ".join(f"net/trade@{c}bp  net/day@{c}bp" for c in COSTS)
    print(hdr,flush=True)
    for h,rebal,ic,sig,gross,oracle in rows:
        cells=[]
        for c in COSTS:
            nt=gross-c; nd=nt*rebal
            cells.append(f"{nt:+6.2f}  {nd:+9.1f}")
        print(f"{h:>5}  | "+" | ".join(cells),flush=True)
    print("\nREAD: sigma_idio column = user's sigma_ytrue (grows with h?). gross/trade grows with h?",flush=True)
    print("optimal h at each cost = argmax net/day. short h: high rebal but cost*rebal explodes (cost wall).",flush=True)
    print("(gross uses RIDGE; DL lifts short-h gross further per e_fast120/300 -> short-h gross is a LOWER bound.)",flush=True)

if __name__=="__main__":
    main()
