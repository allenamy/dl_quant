# code/ — 核心代码注解（每个文件对应的思路、实验版本与核心改动）

> 19 个脚本 = 三条主线（raw/LOBNet3 线、idio/cs_ranker 线、基准与诊断线）的核心代码 + 2 个依赖（`gbdt_cs_alpha.py` 为多个诊断脚本提供数据装载/GBDT 基线；`walkforward_revalidate.py` 定义 8 折 walk-forward 的折参数，是 `walkforward_backtest.py` 的依赖）。
> 数据与 checkpoint 不在包内（在服务器 `/mnt/storage/private/work_hsy/quant_research_multi_asset/`：NPZ mmap `data/npz_v23_400d_mmap/{day}/{X.npy,y_600.npy,dt.npy}`，教师流 `data/btc_stream/fold1/`，模型 `experiments/diagnostic_*/best.pt`）。
> 所有训练单种子 42（P8 纪律：禁 multi-seed/ensemble）。评估统一 UNIV10（含 ETH）。

---

## 主线一：raw y_600（LOBNet3 + BTC 教师融合，Phase 15）

### `train_rawlob3.py` — LOBNet3 主模型（多资产 in-RAM 全 1s LOB）
一个文件浓缩了 raw 线的全部架构演进，每个改动都有对应实验验证：

| 核心改动 | 代码位置 | 思路 / 实验证据 |
|---|---|---|
| **A1 `--pre_temporal`** | `__init__` temp1s + forward 步骤 6 | 审计发现原模型 patch(10s 均值)是第一个时间轴算子 → 1s 微观动力学被抹掉。修复：patch **前**加 3 层膨胀因果卷积(dil 1,2,4)，零初始化门 `g1s`。 |
| **A4 `--use_flow`** | flowin/flowconv/flowproj + forward 步骤 4 | 审计发现 9 通道 signed order-flow 在序列里广播成常量。修复：独立因果卷积流(dil 1,2,4,8)，零初始化门 `gflow`（per-asset 时 BTC 可自行关掉 flow）。**A1+A4 = MEAN_P 0.022→0.0415 (+89%)，rl3abl2 消融**。 |
| **A2/A3 归一化修复** | `robust_revin_seq` + `LOBSpatial` | 移除跨通道 LayerNorm（曾把 delta_bps 和 logsz 混单位、抹掉盘口量级）；换成每(样本,通道)沿时间轴的因果 robust-RevIN。 |
| **LOBSpatial 档位卷积** | `LOBSpatial` 类 | DETAIL(5 档×4 字段)/CUMU(9 深度桶×2 侧)分别沿档位卷积 + **学习型档位注意力池化**（保留盘口形状 vs 均值池化）。 |
| **per-asset 门 + σ_scale (C4)** | `gdim=S`、`sigma_scale` | β 校准异质化：每资产输出增益旋钮，放在 head **之后**（原在 FiLM 前与 γ 数学冗余）。 |
| **use_basket (STEP3)** | basket 块（forward 步骤 10） | 篮子市场上下文：`ztd=detach()` 停止梯度保护中盘股 + 对角 mask 严格外生 + **死区修复**（只零初始化门 gb，bproj 用正常初始化——双零会让两者梯度永久为 0，rl3btc2 的 bug）。 |
| **BTCFusion (Phase 15-B2)** | btc_in/btc_q/k/v/gf_btc/btc_self 块（forward 步骤 11；构造参数 `use_btc_fusion`，由 fusion 驱动的 CONFIGS 设置，非 CLI flag） | 冻结教师 token `(B,K,34)=[h_pred32,q50,σ]` 作 K/V，**alt 的 z 作 Query** 的非对称门控 cross-attn（每个 alt 自己学吸收 BTC 的哪个滞后）；BTC 自身槽位走直连残差 `g_btc_self`；token 是外生数据无教师梯度；warmup `(ep−1)/3`。**结果：alt 均值 0.032→0.045，因果对照通过**。 |
| **TemporalTransformer (Phase 15-C，证伪)** | `TemporalTransformer` 类（构造参数 `temporal='transformer'`；CLI flag `--temporal` 在 fusion 驱动里） | E215c 在 idio 目标上最优的纯自注意力 temporal。**迁移到 raw+fusion 失败**：base-tf 0.033≈conv 0.032（vsel 优势是过拟合），fusion-on-tf 退化到 0.028（门变负）。conv 版保持 deliverable。 |
| 损失（foundation 配方） | main() 训练循环 | `Huber(MAD-z y) + 0.1·尾部加权 sign-BCE + 0.3·mag-focal + 0.3·LambdaRank(CS-demeaned)`。**B1 修复：rank 在去均值 idio 上而非 market-laden raw**。rank 共训是 raw 第一杠杆（0.007→0.031）。 |

### `train_rawlob3_fusion.py` — Phase 15-B 融合驱动（消融 + 泄漏对照）
- `build_btc_index`/`attach_btc`：教师流的 **as-of 因果 dt-join**（样本绝对秒 `dt.npy[t]` 对教师 ts `searchsorted`，取 ≤t 的最近 K 个快照，gap>600s 置零交给门）。**用时间 join，绝不用位置索引**（交易中断会错位）。
- 单轴消融 configs：`base`（无融合）/ `q50`（融合开但 h_pred 32 维置零 = 标量对照）/ `hl0`（K=1）/ `multilag`（K=4 ≈ 滞后 0/180/360/540s）。
- 泄漏对照：`--btc_scramble`（打乱对齐）、`--btc_shift_s`（未来窥视；+3600s 使 multilag 塌回 base = 因果性证明）。
- **covered-only 评估**：教师只覆盖 ~41% 样本（npz_v4 部分天构建 artifact），三个 config 用同一覆盖行做 apples-to-apples。
- 关键结果：multilag conv 全样本 alt 均值 **0.0445**、covered **0.0454**、covBTC 0.017→**0.038**；q50 对照 ≈ multilag（alt 只吸收 BTC 方向）。

### `extract_h_pred.py` — Phase 15-A4 教师 h_pred 提取
- 教师重建：checkpoint 内嵌 config **丢了 `use_film_multistage`** → 必须合并 JSON config 再 strict load（否则 film_gate_block1/2/final 缺失）。
- 归一化逐位忠实：`x_feat=(X−x_mean)/where(x_std<1e-4,1,x_std)`，X_raw/regime_prior 原样。
- `--validate`：重算 q50 对保存的 test_preds 校验（**median |Δq50|=2.2e-7，Pearson 0.0740 vs 0.0741** = 管线保真）。
- fold 选择防泄漏：fold_1 测试窗 2025-04-10→07-10 ⊇ 多资产评测窗 2025-04-19→05-18 → 教师在评测窗 OOS。

### `eval_fusion_ckpts.py` — checkpoint 重评估 + 全覆盖预览
- 背景：服务器磁盘满导致训练日志被 unlink → 从 best.pt 直接重建结果（与训练摘要逐位一致）。
- `--btc_stream_dir`：替换评测期教师流 → **全覆盖(98.6%)预览**证明覆盖率不是瓶颈（0.0412 ≤ 0.0445），省掉 10h 全天重建。归一化统计仍取自原训练流（防 NaN/分布错位）。
- `--btc_scramble/--btc_shift_s`：对已训模型做评估期泄漏对照。

### `btc_hour_generalization.py` — 教师按 UTC 小时泛化检查
- 动机：npz_v4 只覆盖每天 ~UTC 00–15h，教师没见过晚间时段。30 天全天重建数据上按 2h 桶算 q50-vs-y Pearson：**无泛化悬崖**（未见时段 +0.031 ≈ 已见 +0.043），整窗 +0.038（该月低信号 regime）。

### `train_rawlob3_btc1.py` — BTC>0.07 攻坚 wave-1（β 校准消融）
- `sigma_match` 函数：每资产 `(σ_pred/σ_act − ρ)²`，ρ=detached Pearson——"σ_pred=ρ·σ_act 金标准"的实现。
- 三 config 消融（C0ref/C1deshrink/C2sigmatch）：验证用户的"de-shrink"假设——per-asset σ + 干净 Huber 把 β 2.15→1.25；σ_match 到 0.95 但损 Pearson（BTC 0.028→0.014）。

---

## 主线二：idio / 市场中性（cs_ranker 家族，E142→E215c）

### `train_cs_ranker.py` — 基座 + 两个全项目关键资产
- **`UNIV10 = [0,1,13,4,11,2,12,5,7,9]`**（BTC,ETH,ETC,XRP,DOT,SOL,FIL,DOG,LINK,TRX）：唯一规范宇宙（ETH 曾被错删，#2 可预测资产）。
- **`lambdarank_loss`**：先转每快照 CS 秩（修复小 |Δy| 弱梯度导致的 ln(2)=0.6931 平台，E141），pairwise softplus 按秩差加权。

### `train_cs_ranker_seq.py` — idio 深模型全家族（一个文件 = 一条实验谱系）
flag 与实验版本的对应（审查时按 flag 找代码块）：

| flag | 实验 | 核心思路与结果 |
|---|---|---|
| 基座 MLP 两头 + `feat_drop` | E142/E144 | GBDT feature_fraction 类比；cs 0.0349→0.0439 |
| GRU temporal（per-asset，无跨资产混合） | E147 | 时间结构是树拿不到的；cs→0.0501。**per-asset 隔离防 ln2-collapse** |
| `--use_lobcnn` / `--raw_lob_seq` / `--use_lobtemporal` | E150/E154/E155 | DeepLOB 档位卷积 + 原始 38 列 LOB 序列 + time×level 二维卷积；cs→0.0541 |
| `--per_asset_film` | **E157** | 每资产 γ/β（零初始化恒等）：深提取(d320 L6) + 资产特化 → **idio 每资产 Pearson 翻倍 0.020→0.040，FIL 0.084**；E158 证明深度是主驱动 |
| `--split_mag` + `--mag_loss ccc` | **E206/E210** | mag 头独立分支（与 rank 不抢干路）+ Lin's CCC（结构上不会 σ 塌缩）→ **校准修复 σ_p/a 4→0.6-1.1, sign-hit 0.53**；E210 = 两点确认 deliverable |
| `--temporal_transformer` | **E215c** | 纯 2 层自注意力（**无卷积**——conv 重的 Conformer 在 rank 上过拟合）→ cs 0.0526 / P9 0.0440 = **calibrated split_mag 谱系内**最佳架构（对比同谱系 GRU E210 0.0506/0.0406）。注意：rank-primary 谱系的 E174 (0.0550/0.0455，未校准) 数字更高——两谱系口径不同，见 04 文档说明 |
| `--cross_asset --var_w` | E172/E174 | 守门跨资产注意力：方差地板惩罚防 ln2-collapse，1 层+标量门是唯一 keeper（+0.003）；`--vrex_beta` V-REx 温和正则 (+0.005 P9) |
| `--factor_bridge --head_routing` | E229e | 三头分解 `raw = idio_mag + tanh(α_F)·β·F̂`：idio-mag 用 **CCC-on-残差**（关键），raw 是派生量无独立损失（不干涉性已验证） |
| `--causal_norm` / `--revin` | 泄漏修复 (6/1) | **per-day 归一化 = 前视泄漏 14× 虚高（0.1116→0.0080）**；frozen-train 统计或窗口内 RevIN 才合法 |
| `--raw_target` / `--idio_target` | E156/E159/E171 | raw 与 idio 双目标第一性：深模型 idio 0.040 ≫ raw 0.024（raw 70% 是不可预测市场分量） |

---

## 主线三：基准、诊断与回测（结论的证据来源）

| 文件 | 作用 | 关键结论 |
|---|---|---|
| `snapshot_models.py` | 快照模型横评（ridge/GBDT/pooled-MLP） | **每资产快照 ridge = raw y_600 冠军 0.044**（深序列 0.030；pooled-MLP σ 塌缩 0.005）——RevIN+序列毁掉绝对量级 |
| `compare_models_fullmetrics.py` | DL vs GBDT vs ridge 同协议全指标 | 信息界证据：idio 上 DL−GBDT 每资产仅 +0.0014；raw 上全部 ≪ 单资产 0.067 |
| `market_factor_probe.py` | 市场因子可预测性上限 | bar_1s 聚合特征预测市场因子上限 ~0.02 → **BTC 教师注入的理论依据**（导入不可自建的信号） |
| `leadlag_diag.py` | BTC→alt 领先滞后结构 | BTC 领先 alts（融合的多滞后 K/V 设计依据） |
| `horizon_economics.py` | 恒等式 gross/trade = IC×σ_idio | y_600 = 经济死区；双最优：y_120（信号端）/ y_1800+3600（净收益端） |
| `predcalib_eval.py` | β/σ 比/sign-hit/bias 校准评估 | **"Pearson 高≠可交易"的制度化检查**（E205 FIL 0.086 但 σ 比≈4、sign-hit 0.50 的教训） |
| `walkforward_backtest.py` | 8 折滚动诚实回测（ridge） | **把 y_1800 "+1.7@2bp" 修正为有利窗口 artifact**（8 折 @2bp −5.97～−2.36） |
| `wf_backtest.py` | 8 折 DL 回测 + 策略阶梯 | conviction-gate z=1.0：@2bp −0.08 breakeven（5/8 正）、@1bp +1.22 |
| `bt_directional.py` | 方向性（非中性）策略回测 | **@2bp +0.91（6/8 折正）**，双对照通过（sign-flip −3.79 / momentum −1.33）= 当前最佳诚实交易结果 |

---

## 全项目工程纪律（审查时核对的不变量）

1. **Identity-init 接入**：所有新模块 `x + tanh(α)·f(x)` 或 FiLM `(1+γ)x+β`，门零初始化 → step 0 = 已证基线；**只零门、不零投影**（双零 = 乘法死区）。
2. **跨资产/融合三件套**：warmup 缓升 `(ep−1)/3` + 停止梯度/外生上下文（不准拉扯共享干路）+ 资产槽位 mask。
3. **防 σ 塌缩**：DAQH sign×magnitude 解耦（零初始化）、自由 scale 路径无 LayerNorm、每资产 MAD-z 目标。
4. **防 ln2-collapse**（跨资产）：非对称 Q-vs-K/V 或显式快照内方差地板。
5. **泄漏防护**：因果归一化（禁 per-day z）、tier4 列置零、join 用时间不用位置、future-shift/scramble 对照、inner-slice 选 checkpoint。
6. **评估协议**：UNIV10 含 ETH；idio+raw 双目标都报；分层指标（rank + magnitude + **calibration**）；两点稳健（140d 与 386d）；<0.005 视为噪声。
