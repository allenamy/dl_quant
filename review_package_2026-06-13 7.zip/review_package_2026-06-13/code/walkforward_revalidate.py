"""WALK-FORWARD k-fold re-validation across the FULL 667-day span (2023-08 .. 2025-06).
Anti-over-empiricism: does the cs_spear 'ceiling' hold across 2023-2025 regimes, or was it a
2025-8-week artifact? Ridge on the 112-feat (224 cs-z) input, tier4 leaked cols DROPPED (cols 30-40
+ their cs-z copies 142-152) => leak-free. Per horizon y_120/300/600 (finer where targets exist).
Rolling folds: NTR-day train -> NTE-day OOS, advancing by STEP. UNIV10. Reports per-fold + aggregate.
"""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from scipy.stats import rankdata
from sklearn.linear_model import Ridge
from gbdt_cs_alpha import csfeat, csd, NPZ
from train_cs_ranker import UNIV10

HS=[120,300,600]
DROP=list(range(30,41))+[112+c for c in range(30,41)]   # tier4 leaked cols (raw + cs-z)
NTR,NTE,STEP=180,30,60                                    # rolling train/test/advance (days)

def cs_spear(pred,yv):
    cs=[]
    for t in range(pred.shape[0]):
        r=pred[t,UNIV10]; y=yv[t,UNIV10]; v=np.isfinite(r)&np.isfinite(y)
        if v.sum()>=5 and np.std(r[v])>1e-12 and np.std(y[v])>1e-12: cs.append(np.corrcoef(rankdata(r[v]),rankdata(y[v]))[0,1])
    return float(np.nanmean(cs)) if cs else np.nan
def per_asset(pred,yv):
    out=[]
    for a in UNIV10:
        p=pred[:,a]; y=yv[:,a]; m=np.isfinite(p)&np.isfinite(y)
        if m.sum()>100 and p[m].std()>1e-12 and y[m].std()>1e-12: out.append(np.corrcoef(p[m],y[m])[0,1])
    return float(np.nanmean(out)) if out else np.nan

def load(days,h,stride):
    Xs=[];Ys=[]
    for d in days:
        xp=NPZ/str(d)/"X.npy"; yp=NPZ/str(d)/f"y_{h}.npy"
        if not xp.exists() or not yp.exists(): continue
        X=np.load(xp,mmap_mode="r"); T=X.shape[0]; idx=np.arange(0,T-h,stride)
        if len(idx)==0: continue
        Xs.append(np.asarray(X[idx],np.float32)); Ys.append(np.asarray(np.load(yp,mmap_mode="r")[idx],np.float32))
    if not Xs: return None,None
    Xc=csfeat(np.concatenate(Xs)); Xc[:,:,DROP]=0.0       # leak-free: drop tier4
    return Xc, np.concatenate(Ys)

def main():
    days=sorted([int(p.name) for p in NPZ.iterdir() if p.name.isdigit() and (p/"X.npy").exists()])
    folds=[]
    i=0
    while i+NTR+NTE<=len(days):
        folds.append((days[i:i+NTR], days[i+NTR:i+NTR+NTE])); i+=STEP
    print(f"{len(days)} days {days[0]}..{days[-1]}; {len(folds)} rolling folds (train {NTR}d -> OOS {NTE}d, step {STEP}d), tier4 DROPPED\n",flush=True)
    res={h:[] for h in HS}
    for fi,(tr,te) in enumerate(folds):
        line=f"fold{fi} OOS {te[0]}..{te[-1]}: "
        for h in HS:
            Xtr,ytr=load(tr,h,180)
            if Xtr is None: continue
            Xte,yte=load(te,h,h)
            if Xte is None: continue
            t,S,F=Xtr.shape; xr=Xtr.reshape(t*S,F); yr=csd(ytr).reshape(t*S); v=np.isfinite(yr)&np.all(np.isfinite(xr),1)
            rg=Ridge(alpha=100.0).fit(xr[v],yr[v])
            tw,Sw,_=Xte.shape; xw=Xte.reshape(tw*Sw,F); ok=np.all(np.isfinite(xw),1)
            pr=np.where(ok,rg.predict(np.nan_to_num(xw)),np.nan).reshape(tw,Sw); ywd=csd(yte)
            cs=cs_spear(pr,ywd); pa=per_asset(pr,ywd); res[h].append(cs)
            line+=f" y{h}: cs={cs:+.4f}/pa={pa:+.4f} "
        print(line,flush=True)
    print("\n=== AGGREGATE across folds (cs_spear) ===",flush=True)
    for h in HS:
        a=np.array(res[h]);
        if len(a)==0: print(f"  y{h}: no folds"); continue
        print(f"  y{h}: mean={np.nanmean(a):+.4f} std={np.nanstd(a):.4f} min={np.nanmin(a):+.4f} pos={int((a>0).sum())}/{len(a)} folds",flush=True)
    print("\nREAD: if y600 mean ~0.04 & pos most folds -> ceiling HELD across 2023-2025 (real, not 2025 artifact).",flush=True)
    print("if mean << 0.04 or many neg folds -> the '0.05 ceiling' was a 2025-window artifact (over-empiricism caught).",flush=True)

if __name__=="__main__":
    main()
