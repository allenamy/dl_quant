"""E140: DL breakthrough informed by the GBDT diagnostic.
GBDT lambdarank hit cs_spearman 0.049 (6/6 folds) — 2x our deep 0.024 — proving
(1) the objective must be LEARNING-TO-RANK, not regression/Pearson-Huber, and
(2) the structure is PER-SNAPSHOT CROSS-SECTIONAL, not temporal-sequence.

This is the DL analog of that GBDT: a lightweight per-snapshot cross-sectional
ranker — assets-as-tokens self-attention on CS-normalized features -> score per
asset -> differentiable LambdaRank loss (pairwise-logistic weighted by target gap).
Small, regularized, per-snapshot batches (fast). Target: match GBDT ~0.05.

Usage: python scripts/train_cs_ranker.py --tag e140_csranker --epochs 25
"""
from __future__ import annotations
import argparse, datetime as _dt, json, time, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # project root for `src` imports
import numpy as np
import torch
from torch import nn
from scipy.stats import rankdata
from src.model.gdcn import GDCN  # explicit feature-crossing block (tree-like inductive bias)

NPZ=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap")
# ===== CANONICAL EVAL UNIVERSE — single source of truth. 10 assets INCL ETH=1. NEVER hardcode a 9-list. =====
UNIV10=[0,1,13,4,11,2,12,5,7,9]; H=600; S=14   # BTC,ETH,ETC,XRP,DOT,SOL,FIL,DOG,LINK,TRX (ETH=#2 predictable, was wrongly dropped)
UNIV_NAMES={0:"BTC",1:"ETH",13:"ETC",4:"XRP",11:"DOT",2:"SOL",12:"FIL",5:"DOG",7:"LINK",9:"TRX"}
assert len(UNIV10)==10 and 1 in UNIV10, "EVAL UNIVERSE must be the 10 assets incl ETH=1"
UNIV9=UNIV10  # DEPRECATED import-compat alias (== UNIV10); do not use in new code
TRAIN=(20240316,20250420)
WINDOWS=[("W1",20250425,20250509),("W2",20250510,20250524),("W3",20250525,20250608),("W4",20250609,20250624)]
def set_seed(s=42):
    torch.manual_seed(s); np.random.seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)
def dr(a,b):
    s=_dt.date(a//10000,(a//100)%100,a%100);e=_dt.date(b//10000,(b//100)%100,b%100);o=[];d=s
    while d<=e:o.append(d.year*10000+d.month*100+d.day);d+=_dt.timedelta(days=1)
    return o
def load_window(dates,stride):
    """Return Xcs (N,S,2F), Yd (N,S), valid (N,S). CS-normalized features + demeaned target."""
    Xs,Ys=[],[]
    for d in dates:
        xp,yp=NPZ/str(d)/"X.npy",NPZ/str(d)/"y_600.npy"
        if not xp.exists(): continue
        X=np.load(xp,mmap_mode="r");Y=np.load(yp,mmap_mode="r");Tv=X.shape[0]-H;idx=np.arange(0,Tv,stride)
        Xs.append(np.asarray(X[idx],np.float32));Ys.append(np.asarray(Y[idx],np.float32))
    if not Xs: return None,None,None
    X=np.concatenate(Xs);Y=np.concatenate(Ys)   # (N,S,F),(N,S)
    m=np.nanmean(np.where(np.isfinite(X),X,np.nan),1,keepdims=True)
    sd=np.nanstd(np.where(np.isfinite(X),X,np.nan),1,keepdims=True)+1e-6
    Xcs=np.concatenate([np.nan_to_num(X,nan=0.0),np.nan_to_num((X-m)/sd,nan=0.0)],-1)  # (N,S,2F)
    ym=np.nanmean(np.where(np.isfinite(Y),Y,np.nan),1,keepdims=True)
    Yd=Y-ym; valid=np.isfinite(Yd)
    return Xcs.astype(np.float32), np.nan_to_num(Yd,nan=0.0).astype(np.float32), valid

class CSRanker(nn.Module):
    """Per-snapshot CS ranker — faithful DL analog of the GBDT that hit cs_spear 0.049.

    Backbone = shared per-asset MLP on CS-normalized features. CRITICAL: NO cross-asset
    mixing by default. The GBDT scored each (asset,snapshot) row from its OWN features
    (CS z-score already injects cross-sectional info); adding asset-token attention let
    the score collapse to a per-snapshot constant -> within-snapshot variance ~0 ->
    LambdaRank pinned at ln2=0.6931 (E140/E141 failure).

    TWO HEADS decouple incompatible scales: rank head (order-1, LambdaRank) + magnitude
    head (return-scale, Huber). A single scalar can't be both an order-1 ranking score
    AND a ~0.003 return — forcing it caused the collapse. Heads share the backbone.
    Optional identity-init asset-token attention (--use_attn) kept for ablation only."""
    def __init__(self,Fin,d=128,heads=4,layers=3,dropout=0.3,use_attn=False,feat_drop=0.0,
                 backbone="mlp",n_cross=3):
        super().__init__()
        self.feat_drop=feat_drop; self.bmode=backbone
        blocks=[]; din=Fin
        for _ in range(layers):
            blocks += [nn.Linear(din,d),nn.LayerNorm(d),nn.GELU(),nn.Dropout(dropout)]; din=d
        self.backbone=nn.Sequential(*blocks)             # deep tower
        if backbone=="gdcn":                              # DCN-V2: parallel explicit-cross tower
            self.cross_in=nn.Sequential(nn.Linear(Fin,d),nn.LayerNorm(d))  # normalize BEFORE crossing (raw feats explode x0*proj)
            self.cross=GDCN(d,n_cross_layers=n_cross,use_gate=True)
            self.cross_drop=nn.Dropout(dropout)
            self.fuse=nn.Linear(2*d,d)
        self.use_attn=use_attn
        if use_attn:
            self.attn=nn.MultiheadAttention(d,heads,dropout=dropout,batch_first=True)
            self.attn_norm=nn.LayerNorm(d); self.alpha=nn.Parameter(torch.zeros(1))
        self.rank_head=nn.Linear(d,1); self.mag_head=nn.Linear(d,1)
    def forward(self,x):  # x (B,S,Fin) -> rank (B,S), mag (B,S)
        if self.training and self.feat_drop>0:  # column dropout = GBDT feature_fraction analog
            keep=(torch.rand(x.shape[-1],device=x.device)>self.feat_drop).float()
            x=x*keep/(1-self.feat_drop)
        deep=self.backbone(x)
        if self.bmode=="gdcn":
            cross=self.cross_drop(self.cross(self.cross_in(x)))  # project+norm -> d, then explicit cross
            h=self.fuse(torch.cat([cross,deep],-1))
        else:
            h=deep
        if self.use_attn:
            a,_=self.attn(h,h,h); h=self.attn_norm(h+torch.tanh(self.alpha)*a)
        return self.rank_head(h).squeeze(-1), self.mag_head(h).squeeze(-1)

def _csrank(y,valid):  # per-snapshot centered rank in ~[-1,1], O(1) gains (like GBDT rank buckets)
    B,Sn=y.shape; out=torch.zeros_like(y)
    yy=torch.where(valid,y,torch.full_like(y,-1e9))
    # rank via argsort-of-argsort
    r=yy.argsort(dim=1).argsort(dim=1).float()
    cnt=valid.float().sum(1,keepdim=True).clamp(min=1)
    out=(r-(cnt-1)/2)/(cnt/2+1e-9)          # center & scale to ~[-1,1]
    return torch.where(valid,out,torch.zeros_like(out))

def lambdarank_loss(s,y,valid):  # s,y (B,S)
    yr=_csrank(y,valid)                     # O(1) rank-based target (fixes tiny-|Δy| weak gradient)
    Sd=s.unsqueeze(2)-s.unsqueeze(1)        # (B,S,S) s_i - s_j
    Yd=yr.unsqueeze(2)-yr.unsqueeze(1)      # rank gap
    vv=valid.unsqueeze(2)&valid.unsqueeze(1)
    mask=(Yd>0)&vv                          # pairs where i should rank above j
    w=Yd.abs()*mask.float()                 # lambda gain weight = |rank gap| (O(1))
    loss=(w*torch.nn.functional.softplus(-Sd)).sum()/(w.sum()+1e-9)
    return loss

def huber_demean(s,y,valid,delta=1.0):
    d=torch.where(valid,s-y,torch.zeros_like(s)); ad=d.abs()
    h=torch.where(ad<=delta,0.5*d*d,delta*(ad-0.5*delta))
    return (h*valid.float()).sum()/(valid.float().sum()+1e-9)

@torch.no_grad()
def evaluate(model,Xcs,Yd,valid,device,bs=2048):
    model.eval(); N=Xcs.shape[0]; rpred=np.zeros((N,S),np.float32); mpred=np.zeros((N,S),np.float32)
    for i in range(0,N,bs):
        xb=torch.from_numpy(Xcs[i:i+bs]).to(device)
        r,m=model(xb); rpred[i:i+bs]=r.cpu().numpy(); mpred[i:i+bs]=m.cpu().numpy()
    cs=[]; pa={s:([],[]) for s in range(S)}   # cs_spear from RANK head; P9 from MAG head
    for t in range(N):
        row=rpred[t,UNIV9];yr=Yd[t,UNIV9];v=valid[t,UNIV9]
        if v.sum()>=5 and np.std(row[v])>1e-12: cs.append(np.corrcoef(rankdata(row[v]),rankdata(yr[v]))[0,1])
        for s in range(S):
            if valid[t,s]: pa[s][0].append(mpred[t,s]); pa[s][1].append(Yd[t,s])
    p9=[]
    for s in UNIV9:
        ph,yy=np.array(pa[s][0]),np.array(pa[s][1])
        if len(ph)>100 and np.std(ph)>1e-12: p9.append(np.corrcoef(ph,yy)[0,1])
    return (np.nanmean(cs) if cs else np.nan),(np.nanmean(p9) if p9 else np.nan)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tag",required=True);ap.add_argument("--epochs",type=int,default=25)
    ap.add_argument("--stride",type=int,default=180);ap.add_argument("--d",type=int,default=128)
    ap.add_argument("--layers",type=int,default=3);ap.add_argument("--dropout",type=float,default=0.3)
    ap.add_argument("--lr",type=float,default=1e-3);ap.add_argument("--bs",type=int,default=512)
    ap.add_argument("--huber_w",type=float,default=0.1);ap.add_argument("--wd",type=float,default=1e-3)
    ap.add_argument("--use_attn",action="store_true");ap.add_argument("--smoke",action="store_true")
    ap.add_argument("--sched",default="cosine",choices=["cosine","plateau"]);ap.add_argument("--warmup",type=int,default=3)
    ap.add_argument("--feat_drop",type=float,default=0.0)
    ap.add_argument("--backbone",default="mlp",choices=["mlp","gdcn"]);ap.add_argument("--n_cross",type=int,default=3)
    a=ap.parse_args(); set_seed(42); device="cuda" if torch.cuda.is_available() else "cpu"
    tr_days=dr(*TRAIN)
    if a.smoke: tr_days=tr_days[:10]; a.epochs=2
    print(f"E140 CS-ranker | loading train {len(tr_days)}d stride={a.stride}...",flush=True)
    Xtr,Ytr,Vtr=load_window(tr_days,a.stride)
    Fin=Xtr.shape[-1]; N=Xtr.shape[0]
    print(f"train snapshots={N} Fin={Fin}",flush=True)
    val_days=dr(20250425,20250509); Xv,Yv,Vv=load_window(val_days,600)  # W1 for selection
    model=CSRanker(Fin,d=a.d,layers=a.layers,dropout=a.dropout,use_attn=a.use_attn,feat_drop=a.feat_drop,
                   backbone=a.backbone,n_cross=a.n_cross).to(device)
    print(f"params={sum(p.numel() for p in model.parameters()):,} backbone={a.backbone} use_attn={a.use_attn} huber_w={a.huber_w}",flush=True)
    opt=torch.optim.AdamW(model.parameters(),lr=a.lr,weight_decay=a.wd)
    sched=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='max',factor=0.5,patience=3) if a.sched=="plateau" else None
    import math
    def cos_lr(ep):  # linear warmup -> cosine decay to 0.05*lr
        if ep<=a.warmup: return a.lr*ep/max(1,a.warmup)
        prog=(ep-a.warmup)/max(1,a.epochs-a.warmup); return a.lr*(0.05+0.95*0.5*(1+math.cos(math.pi*prog)))
    outdir=Path(f"/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments/diagnostic_{a.tag}");outdir.mkdir(parents=True,exist_ok=True)
    best=-1e9
    Xt=torch.from_numpy(Xtr); Yt=torch.from_numpy(Ytr); Vt=torch.from_numpy(Vtr)
    for ep in range(1,a.epochs+1):
        if a.sched=="cosine":
            for g in opt.param_groups: g['lr']=cos_lr(ep)
        model.train(); t0=time.perf_counter(); perm=torch.randperm(N); losses=[]
        for i in range(0,N,a.bs):
            idx=perm[i:i+a.bs]
            xb=Xt[idx].to(device); yb=Yt[idx].to(device); vb=Vt[idx].to(device)
            opt.zero_grad(set_to_none=True)
            rs,ms=model(xb)
            loss=lambdarank_loss(rs,yb,vb)+a.huber_w*huber_demean(ms,yb,vb)
            if not torch.isfinite(loss): continue
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
            losses.append(loss.item())
        cs9,p9=evaluate(model,Xv,Yv,Vv,device)
        if sched is not None: sched.step(cs9 if np.isfinite(cs9) else -1)
        mark=""
        if np.isfinite(cs9) and cs9>best: best=cs9; torch.save(model.state_dict(),outdir/"best.pt"); mark="★"
        print(f"ep{ep:02d}/{a.epochs} loss={np.mean(losses):.4f} W1_cs_spear={cs9:+.4f} W1_P9={p9:+.4f} ({time.perf_counter()-t0:.0f}s){mark}",flush=True)
    # multi-window eval on best
    if (outdir/"best.pt").exists():
        model.load_state_dict(torch.load(outdir/"best.pt",map_location=device))
        print("\n=== MULTI-WINDOW (best.pt) vs GBDT 0.049 / linear 0.0315 / deep 0.024 ===",flush=True)
        csa=[];pa=[]
        for wn,wa,wb in WINDOWS:
            Xw,Yw,Vw=load_window(dr(wa,wb),600)
            if Xw is None: continue
            cs9,p9=evaluate(model,Xw,Yw,Vw,device); csa.append(cs9);pa.append(p9)
            print(f"  {wn}: cs_spear_9={cs9:+.4f} P9={p9:+.4f}",flush=True)
        print(f"  AGG: cs_spear_9={np.nanmean(csa):+.4f} P9={np.nanmean(pa):+.4f}",flush=True)
    print("DONE",flush=True)

if __name__=="__main__":
    main()
