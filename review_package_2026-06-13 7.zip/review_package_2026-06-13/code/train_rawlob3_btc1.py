"""BTC>0.07 ladder WAVE-1: per-asset specialization + beta calibration (STEP 0+1 of design wf_35e16317).
On top of the A1+A4 base (pre_temporal+use_flow), compare:
  C0ref      : scalar gates, FULL loss (Huber+sign-BCE+mag-focal+rank)        = rl3abl2 A1+A4 (beta1.85, BTC0.006, MEAN0.0415)
  C1deshrink : per-asset gates+sigma, SIMPLE loss (Huber+rank, drop focal/BCE) = user's de-shrink: does clean Huber + per-asset sigma give beta~1 naturally + let BTC shut flow?
  C2sigmatch : per-asset gates+sigma, SIMPLE loss + per-asset sigma_match      = workflow: does the sigma_match anchor help beta further?
Per-asset gate lets BTC learn gate~0 on the flow path that HURT it (0.0116->0.0061). Per-asset sigma fixes the GLOBAL-sigma-can't-serve-heterogeneous-assets cause of beta=1.85.
Preload ONCE (485d, OOS 2025-04). Reports per-asset P/beta/sign + per-asset gflow (BTC=idx0 should ->0).
Usage: python scripts/train_rawlob3_btc1.py --tag rl3btc1
"""
from __future__ import annotations
import argparse, time, math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from train_rawlob3 import preload, LOBNet3, make_batch, evaluate, huber, dev, S, FALL
from train_cs_ranker import UNIV10, UNIV_NAMES, dr, set_seed, lambdarank_loss

CONFIGS = {
    "C0ref":      dict(per_asset=False, sign_w=0.1, magf_w=0.3, sigm_w=0.0, rank_w=0.3),
    "C1deshrink": dict(per_asset=True,  sign_w=0.0, magf_w=0.0, sigm_w=0.0, rank_w=0.3),
    "C2sigmatch": dict(per_asset=True,  sign_w=0.0, magf_w=0.0, sigm_w=0.3, rank_w=0.3),
}


def sigma_match(q, yz, vf):  # per-asset: pin sigma_pred/sigma_act -> rho (detached calibration target)
    s = q.new_zeros(()); n = 0
    for c in range(S):
        m = vf[:, c] > 0.5
        if m.sum() < 8: continue
        qc = q[:, c][m]; yc = yz[:, c][m]; sa = yc.std()
        if not torch.isfinite(sa) or sa < 1e-8: continue
        rho = torch.corrcoef(torch.stack([qc, yc]))[0, 1].detach()
        rho = torch.nan_to_num(rho).clamp(0.0, 1.0)
        s = s + (qc.std() / (sa + 1e-6) - rho).pow(2); n += 1
    return s / max(n, 1)


def train_eval(name, cfg, sm_tr, rl_tr, sm_vs, rl_vs, sm_ev, rl_ev, hmed, hmad, ymed, ymad, a):
    set_seed(42)
    model = LOBNet3(hmed, hmad, d=a.d, use_lob=True, pre_temporal=True, use_flow=True, per_asset=cfg["per_asset"]).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    outdir = Path(f"/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments/diagnostic_{a.tag}_{name}"); outdir.mkdir(parents=True, exist_ok=True)
    ym = torch.from_numpy(ymed.astype(np.float32)).to(dev); yd = torch.from_numpy(ymad.astype(np.float32)).to(dev)
    rng = np.random.default_rng(42); N = len(sm_tr); best = -1e9; bad = 0
    print(f"\n##### {name}  per_asset={cfg['per_asset']} sign={cfg['sign_w']} magf={cfg['magf_w']} sigm={cfg['sigm_w']} params={sum(p.numel() for p in model.parameters()):,} #####", flush=True)
    def cos(ep): return a.lr * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * ep / a.epochs))) if ep > 2 else a.lr * ep / 2
    for ep in range(1, a.epochs + 1):
        for g in opt.param_groups: g['lr'] = cos(ep)
        model.train(); perm = rng.permutation(N); losses = []; te = time.perf_counter()
        for i in range(0, N - a.bs + 1, a.bs):
            idx = perm[i:i + a.bs]
            hand, lob, yraw, vb = make_batch(sm_tr, idx, rl_tr, a.win, a.sub, True)
            hand = hand.to(dev); yraw = yraw.to(dev); vb = vb.to(dev); vf = vb.float()
            if vf.sum() < 1: continue
            yz = torch.clamp((yraw - ym) / yd, -6, 6)
            opt.zero_grad(set_to_none=True)
            q, slog, ma, rk = model(hand, lob.to(dev))
            magl = (huber(q, yz) * vf).sum() / vf.sum().clamp(min=1)
            ydem = yz - (yz * vf).sum(1, keepdim=True) / vf.sum(1, keepdim=True).clamp(min=1)
            loss = magl + cfg["rank_w"] * lambdarank_loss(rk, ydem, vb)
            if cfg["sign_w"] > 0:
                wsign = (yz.abs().clamp(max=5).pow(1.5) * (yz.abs() > 0.5).float() + 1e-3) * vf
                loss = loss + cfg["sign_w"] * (F.binary_cross_entropy_with_logits(slog, (yz > 0).float(), reduction='none') * wsign).sum() / wsign.sum().clamp(min=1)
            if cfg["magf_w"] > 0:
                loss = loss + cfg["magf_w"] * (huber(ma, yz.abs()) * (1 + yz.abs()) * vf).sum() / ((1 + yz.abs()) * vf).sum().clamp(min=1)
            if cfg["sigm_w"] > 0:
                loss = loss + cfg["sigm_w"] * sigma_match(q, yz, vf)
            if not torch.isfinite(loss): continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); losses.append(loss.item())
        rv = evaluate(model, sm_vs, rl_vs, a.win, a.sub, True, ymad, ymed); pv = np.nanmean([rv[x][0] for x in rv]) if rv else np.nan
        mark = ""
        if np.isfinite(pv) and pv > best + 1e-5: best = pv; bad = 0; torch.save(model.state_dict(), outdir / "best.pt"); mark = "★"
        else: bad += 1
        gf = torch.tanh(model.gflow).detach().cpu().numpy()
        gfs = f"BTC={gf[0]:+.2f} SOL={gf[2]:+.2f} FIL={gf[12]:+.2f}" if cfg["per_asset"] else f"{float(gf):+.2f}"
        print(f"  [{name}] ep{ep:02d}/{a.epochs} loss={np.mean(losses):.4f} vselP={pv:+.4f} gflow({gfs}) bad={bad} ({time.perf_counter()-te:.0f}s){mark}", flush=True)
        if bad >= a.patience and ep >= 5: print(f"  [{name}] [early-stop]", flush=True); break
    if not (outdir / "best.pt").exists(): torch.save(model.state_dict(), outdir / "best.pt")
    model.load_state_dict(torch.load(outdir / "best.pt", map_location=dev))
    return evaluate(model, sm_ev, rl_ev, a.win, a.sub, True, ymad, ymed)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True); ap.add_argument("--configs", default="C0ref,C1deshrink,C2sigmatch")
    ap.add_argument("--train_start", type=int, default=20231201); ap.add_argument("--train_end", type=int, default=20250418)
    ap.add_argument("--eval_start", type=int, default=20250419); ap.add_argument("--eval_end", type=int, default=20250518)
    ap.add_argument("--win", type=int, default=600); ap.add_argument("--sub", type=int, default=1)
    ap.add_argument("--stride", type=int, default=360); ap.add_argument("--epochs", type=int, default=14)
    ap.add_argument("--bs", type=int, default=96); ap.add_argument("--lr", type=float, default=8e-4)
    ap.add_argument("--wd", type=float, default=1e-3); ap.add_argument("--d", type=int, default=96)
    ap.add_argument("--patience", type=int, default=4)
    a = ap.parse_args(); set_seed(42)
    want = [c.strip() for c in a.configs.split(",") if c.strip()]
    tr = dr(a.train_start, a.train_end); vsel = tr[-20:]; tr = tr[:-20]
    t0 = time.perf_counter(); print(f"[preload-ONCE] train {len(tr)}d, configs={want} ...", flush=True)
    rl_tr, sm_tr = preload(tr, a.win, a.stride)
    rl_vs, sm_vs = preload(vsel, a.win, 600); rl_ev, sm_ev = preload(dr(a.eval_start, a.eval_end), a.win, 600)
    print(f"  preloaded train={len(sm_tr)} vsel={len(sm_vs)} eval={len(sm_ev)} in {time.perf_counter()-t0:.0f}s", flush=True)
    hf = np.stack([sm_tr[i][2] for i in range(0, len(sm_tr), max(1, len(sm_tr)//6000))]).reshape(-1, FALL)
    hmed = np.nan_to_num(np.median(hf, 0)); hmad = 1.4826 * np.median(np.abs(hf - hmed), 0) + 1e-6
    hmad = np.where(np.isfinite(hmad) & (hmad > 1e-9), hmad, 1.0)
    yt = np.stack([sm_tr[i][3] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))]); vt = np.stack([sm_tr[i][4] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))])
    yv = np.where(vt, yt, np.nan); ymed = np.nan_to_num(np.nanmedian(yv, 0, keepdims=True))
    ymad = 1.4826 * np.nanmedian(np.abs(yv - ymed), 0, keepdims=True); ymad = np.where(np.isfinite(ymad) & (ymad > 1e-12), ymad, 1.0) + 1e-12
    allres = {}
    for name in want:
        allres[name] = train_eval(name, CONFIGS[name], sm_tr, rl_tr, sm_vs, rl_vs, sm_ev, rl_ev, hmed, hmad, ymed, ymad, a)
    print(f"\n===== BTC>0.07 WAVE-1 (OOS {a.eval_start}->{a.eval_end}, {len(tr)}d, same preload+seed) =====", flush=True)
    print("  asset " + "".join(f"{n:>12s}" for n in want), flush=True)
    for x in UNIV10:
        row = f"  {UNIV_NAMES[x]:5s}"
        for n in want: row += f"{(allres[n].get(x,(np.nan,))[0]):>+12.4f}"
        print(row, flush=True)
    print("  " + "-" * (7 + 12 * len(want)), flush=True)
    for stat, idx, fmt in [("MEAN_P", 0, "+12.4f"), ("beta", 1, "+12.2f"), ("sign", 3, "12.3f")]:
        row = f"  {stat:5s}"
        for n in want:
            vals = [allres[n][x][idx] for x in UNIV10 if x in allres[n]]
            row += f"{np.nanmean(vals):>{fmt}}"
        print(row, flush=True)
    print(f"  BTC target: 0.0061(A1+A4) -> recover via per-asset flow-gate; beta target ~1 (was 1.85) | GOAL BTC>0.07", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
