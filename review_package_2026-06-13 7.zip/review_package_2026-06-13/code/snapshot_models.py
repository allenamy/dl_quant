"""SNAPSHOT magnitude models for raw y_600 (our 112 feats, tier4-dropped, leak-free WF).
The deep SEQUENCE model + RevIN under-performed a plain snapshot ridge (0.044 > 0.030). Test whether
GBDT / a POOLED MLP (shared trunk + asset embedding; cross-asset statistical strength, E157 insight)
push per-asset raw y_600 Pearson higher — target the strong mid-caps past 0.07.
Per-asset Pearson, 3 expanding-window OOS points. Global-z standardize fit on TRAIN only (causal).
"""
import numpy as np, os
from datetime import date, timedelta
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
import torch, torch.nn as nn

OURS = "/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap"
HSTEP = 600
UNIV10 = [0, 1, 13, 4, 11, 2, 12, 5, 7, 9]
NAMES = {0:"BTC",1:"ETH",13:"ETC",4:"XRP",11:"DOT",2:"SOL",12:"FIL",5:"DOG",7:"LINK",9:"TRX"}
POINTS = [
    ("2023-08-28","2024-08-21","2024-08-22","2024-09-20"),
    ("2023-08-28","2024-12-19","2024-12-20","2025-01-18"),
    ("2023-08-28","2025-04-18","2025-04-19","2025-05-18"),
]
dev = "cuda" if torch.cuda.is_available() else "cpu"

def drange(a,b):
    a=date.fromisoformat(a); b=date.fromisoformat(b); o=[]
    while a<=b: o.append(a); a+=timedelta(days=1)
    return o

def load(days, stride=600):
    Xs,Ys=[],[]
    for d in days:
        dd=d.strftime("%Y%m%d"); xp=f"{OURS}/{dd}/X.npy"; yp=f"{OURS}/{dd}/y_600.npy"
        if not os.path.exists(xp) or not os.path.exists(yp): continue
        X=np.load(xp,mmap_mode="r"); y=np.load(yp,mmap_mode="r"); T=X.shape[0]
        secs=np.arange(stride,T-HSTEP,stride)
        Xa=np.asarray(X[secs],np.float32); Xa[...,30:41]=0.0  # drop tier4 (leak)
        Xs.append(Xa); Ys.append(np.asarray(y[secs],np.float32))
    if not Xs: return None,None
    return np.concatenate(Xs), np.concatenate(Ys)  # (N,14,112),(N,14)

def perasset_corr(pred, y, v):
    return float(np.corrcoef(pred[v], y[v])[0,1]) if v.sum()>50 and np.std(pred[v])>1e-20 else np.nan

def ridge_eval(Xtr,Ytr,Xte,Yte):
    out={}
    for a in UNIV10:
        xt=np.nan_to_num(Xtr[:,a,:]); yt=Ytr[:,a]; vt=np.isfinite(yt)
        xe=np.nan_to_num(Xte[:,a,:]); ye=Yte[:,a]; ve=np.isfinite(ye)
        if vt.sum()<500: continue
        sc=StandardScaler().fit(xt[vt]); r=RidgeCV(alphas=[1,10,100,1000,1e4]).fit(sc.transform(xt[vt]),yt[vt])
        out[a]=perasset_corr(r.predict(sc.transform(xe)),ye,ve)
    return out

def gbdt_eval(Xtr,Ytr,Xte,Yte):
    out={}
    for a in UNIV10:
        xt=np.nan_to_num(Xtr[:,a,:]); yt=Ytr[:,a]; vt=np.isfinite(yt)
        xe=np.nan_to_num(Xte[:,a,:]); ye=Yte[:,a]; ve=np.isfinite(ye)
        if vt.sum()<500: continue
        g=HistGradientBoostingRegressor(max_iter=300,max_depth=4,learning_rate=0.03,
            l2_regularization=1.0,early_stopping=True,validation_fraction=0.15,random_state=42)
        g.fit(xt[vt],yt[vt]); out[a]=perasset_corr(g.predict(xe),ye,ve)
    return out

class PooledMLP(nn.Module):  # shared trunk over global-z feats + asset embedding -> per-asset magnitude
    def __init__(self,F,nA=14,d=256,emb=16):
        super().__init__(); self.emb=nn.Embedding(nA,emb)
        self.net=nn.Sequential(nn.Linear(F+emb,d),nn.GELU(),nn.Dropout(0.2),
            nn.Linear(d,d),nn.GELU(),nn.Dropout(0.2),nn.Linear(d,1))
    def forward(self,x,a): return self.net(torch.cat([x,self.emb(a)],-1)).squeeze(-1)

def pooled_mlp_eval(Xtr,Ytr,Xte,Yte,epochs=40):
    torch.manual_seed(42)
    # global-z standardize features on train (pooled across assets+samples); per-asset z the target
    Xt=np.nan_to_num(Xtr.reshape(-1,Xtr.shape[-1])); fm=Xt.mean(0,keepdims=True); fs=Xt.std(0,keepdims=True)+1e-6
    ymed=np.nanmedian(np.where(np.isfinite(Ytr),Ytr,np.nan),0,keepdims=True)
    ymad=1.4826*np.nanmedian(np.abs(np.where(np.isfinite(Ytr),Ytr,np.nan)-ymed),0,keepdims=True)+1e-9
    def prep(X,Y):
        N,S,F=X.shape; xs=[]; ys=[]; ids=[]
        Xz=(np.nan_to_num(X)-fm)/fs
        Yz=np.clip((Y-ymed)/ymad,-6,6)
        for ai,a in enumerate(range(S)):
            v=np.isfinite(Y[:,a])
            xs.append(Xz[v,a,:]); ys.append(Yz[v,a]); ids.append(np.full(v.sum(),a))
        return (np.concatenate(xs).astype(np.float32),np.concatenate(ys).astype(np.float32),
                np.concatenate(ids).astype(np.int64))
    xtr,ytr,itr=prep(Xtr,Ytr)
    m=PooledMLP(Xtr.shape[-1]).to(dev); opt=torch.optim.AdamW(m.parameters(),lr=1e-3,weight_decay=1e-4)
    Xtt=torch.from_numpy(xtr); Ytt=torch.from_numpy(ytr); Itt=torch.from_numpy(itr); N=len(xtr)
    for ep in range(epochs):
        m.train(); perm=torch.randperm(N)
        for i in range(0,N,4096):
            idx=perm[i:i+4096]; xb=Xtt[idx].to(dev); yb=Ytt[idx].to(dev); ib=Itt[idx].to(dev)
            opt.zero_grad(); p=m(xb,ib); loss=nn.functional.smooth_l1_loss(p,yb); loss.backward(); opt.step()
    # predict per-asset on test
    m.eval(); out={}
    Xez=(np.nan_to_num(Xte)-fm)/fs
    with torch.no_grad():
        for a in UNIV10:
            ve=np.isfinite(Yte[:,a])
            xb=torch.from_numpy(Xez[:,a,:].astype(np.float32)).to(dev)
            ib=torch.full((Xez.shape[0],),a,dtype=torch.long,device=dev)
            pe=m(xb,ib).cpu().numpy()
            out[a]=perasset_corr(pe,Yte[:,a],ve)
    return out

def summarize(name, pts):
    agg={a:np.nanmean([p.get(a,np.nan) for p in pts]) for a in UNIV10}
    mean=np.nanmean(list(agg.values()))
    strong=np.nanmean([agg[a] for a in UNIV10 if a not in (0,9,5)])  # ex BTC/TRX/DOG (idio~0/weak)
    print(f"  {name:12s} meanP10={mean:+.4f} strong7={strong:+.4f}  " +
          " ".join(f"{NAMES[a]}={agg[a]:+.3f}" for a in UNIV10), flush=True)

def main():
    print("SNAPSHOT magnitude models -> raw y_600 per-asset Pearson (leak-free WF, our feats)\n", flush=True)
    R,G,M=[],[],[]
    for (ts,te,os_,oe) in POINTS:
        Xtr,Ytr=load(drange(ts,te)); Xte,Yte=load(drange(os_,oe))
        if Xtr is None or Xte is None: continue
        R.append(ridge_eval(Xtr,Ytr,Xte,Yte))
        G.append(gbdt_eval(Xtr,Ytr,Xte,Yte))
        M.append(pooled_mlp_eval(Xtr,Ytr,Xte,Yte))
        print(f"  [point {os_} done]", flush=True)
    print(); summarize("ridge",R); summarize("gbdt",G); summarize("pooled_mlp",M)
    print("\n  strong7 = mean ex BTC/DOG/TRX (idio~0 / structurally weak). DONE", flush=True)

if __name__=="__main__":
    main()
