"""Phase 15-A4: extract the frozen BTC-teacher h_pred stream for multi-asset fusion.

Loads the VERIFIED single-asset REG_arch teacher (DualPathLOBModelV3, pooled test
Pearson 0.0664, beta 1.09), runs encode()->h_pred(32) + forward()->q50,sigma over the
single-asset npz_v4 days, and writes per-day btc_stream keyed by unix-SECONDS so the
multi-asset model can do an as-of causal dt-join.

Teacher fold choice (LEAK-CLEAN): fold_1 TEST window = 2025-04-10..07-10 fully contains
the multi-asset eval window 2025-04-19..05-18 -> teacher is OUT-OF-SAMPLE on the eval
window. On the multi-asset train window fold_1 is in-sample (mild, conservative: biases the
eval signal weaker, never stronger). For a 2nd robustness window (2025-06) use fold_2.

Input normalization is bit-faithful to training (from fold norm_params):
  x_feat = (X - x_mean) / where(x_std<1e-4, 1, x_std);  X_raw as-is (already bps+log1p);  regime_prior as-is.

Run with cwd = single-asset repo so `import src.*` resolves to ITS src (not the multi-asset src):
  cd /mnt/storage/private/work_hsy/quant_research && \
  python /mnt/storage/private/work_hsy/quant_research_multi_asset/scripts/extract_h_pred.py \
      --fold 1 --start 20230828 --end 20250518
Add --validate to check forward q50 reproduces the saved fold test_preds (pipeline fidelity).
"""
from __future__ import annotations
import argparse, sys, time, json
from pathlib import Path
import numpy as np
import torch

SINGLE = Path("/mnt/storage/private/work_hsy/quant_research")
NPZ_V4 = SINGLE / "data/npz_v4"
OUT = Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/btc_stream")
# authoritative arch config (the checkpoint's embedded `config` dropped use_film_multistage)
JSON_CFG = SINGLE / "configs/v5push/singh_alpha0_huber_track_reg_arch.json"


def load_teacher(fold: int, dev):
    fdir = SINGLE / f"experiments/v5push/singh_track_reg_arch/fold_{fold}"
    ck = torch.load(fdir / "best_model.pt", map_location="cpu", weights_only=False)
    assert ck["class"] == "DualPathLOBModelV3", ck["class"]
    if str(SINGLE) not in sys.path:
        sys.path.insert(0, str(SINGLE))  # so `import src.*` resolves to the single-asset repo, not the multi-asset src
    from src.model.dual_path_model_v3 import DualPathLOBModelV3
    cfg = dict(ck["config"])
    cfg.update(json.load(open(JSON_CFG))["model"])  # JSON is authoritative for arch flags (adds use_film_multistage)
    m = DualPathLOBModelV3(**cfg).to(dev)
    m.load_state_dict(ck["state"])  # strict: proves the reconstructed arch matches the trained teacher exactly
    m.eval()
    npz = np.load(fdir / "norm_params.npz")
    xm = npz["x_mean"].astype(np.float32)
    xs = npz["x_std"].astype(np.float32)
    safe = np.where(xs < 1e-4, 1.0, xs).astype(np.float32)
    print(f"[teacher] fold_{fold} loaded: {sum(p.numel() for p in m.parameters()):,} params, "
          f"x_mean[:2]={xm[:2]} safe_std[:2]={safe[:2]}", flush=True)
    return m, xm, safe, fdir


@torch.no_grad()
def run_day(m, xm, safe, path: Path, dev, bs: int = 512):
    z = np.load(path, allow_pickle=True)
    X = z["X"].astype(np.float32)                 # (N,600,64)
    Xr = z["X_raw"].astype(np.float32)            # (N,600,20,4)
    rp = z["regime_prior"].astype(np.float32)     # (N,6)
    ts_us = z["timestamps"].astype(np.int64)      # microseconds
    Xn = (X - xm) / safe                          # bit-faithful standardisation
    H, Q, SG = [], [], []
    for i in range(0, len(Xn), bs):
        xf = torch.from_numpy(Xn[i:i + bs]).to(dev)
        xr = torch.from_numpy(Xr[i:i + bs]).to(dev)
        r = torch.from_numpy(rp[i:i + bs]).to(dev)
        h = m.encode(x_feat=xf, x_raw=xr, regime_prior=r)            # (b,32) pooled pre-head embedding
        out = m.forward(x_feat=xf, x_raw=xr, regime_prior=r)         # dict
        q = out["quantiles"]                                          # (b,3) = q10,q50,q90 (normalized space)
        H.append(h.float().cpu().numpy())
        Q.append(q[:, 1].float().cpu().numpy())
        SG.append((q[:, 2] - q[:, 0]).float().cpu().numpy())          # q90-q10 spread as sigma proxy
    return ts_us // 1_000_000, np.concatenate(H), np.concatenate(Q), np.concatenate(SG)


def validate(m, xm, safe, fdir, dev):
    """forward q50 must reproduce the saved test_preds (proves normalization+encode+head fidelity)."""
    saved = np.load(fdir / "test_preds.npz")
    s_ts = saved["timestamps"].astype(np.int64)           # us
    s_q50 = saved["predictions"][:, 1].astype(np.float64)
    # recompute q50 over the test days and match on timestamp
    days = sorted({int(t) // 1_000_000 // 86400 for t in s_ts})  # unix-day buckets
    import datetime as dt
    rec = {}
    for d in days:
        date = dt.datetime.fromtimestamp(d * 86400, dt.timezone.utc).strftime("%Y-%m-%d")
        p = NPZ_V4 / f"{date}.npz"
        if not p.exists():
            continue
        ts, _, q, _ = run_day(m, xm, safe, p, dev)
        for t, qq in zip(ts, q):
            rec[int(t)] = float(qq)
    matched = [(s_q50[i], rec[int(s_ts[i] // 1_000_000)]) for i in range(len(s_ts)) if int(s_ts[i] // 1_000_000) in rec]
    a = np.array([m_[0] for m_ in matched]); b = np.array([m_[1] for m_ in matched])
    print(f"[validate] matched {len(matched)}/{len(s_ts)} samples  "
          f"max|Δq50|={np.max(np.abs(a - b)):.2e}  corr={np.corrcoef(a, b)[0, 1]:.6f}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold", type=int, default=1)
    ap.add_argument("--start", type=int, default=20230828)
    ap.add_argument("--end", type=int, default=20250518)
    ap.add_argument("--bs", type=int, default=512)
    ap.add_argument("--validate", action="store_true")
    ap.add_argument("--days_dir", default=str(NPZ_V4))   # source npz dir (default npz_v4 partial-day; override for full-day rebuild)
    ap.add_argument("--out_dir", default=str(OUT))       # output stream root (default data/btc_stream)
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    m, xm, safe, fdir = load_teacher(a.fold, dev)

    if a.validate:
        validate(m, xm, safe, fdir, dev)
        return

    outdir = Path(a.out_dir) / f"fold{a.fold}"
    outdir.mkdir(parents=True, exist_ok=True)
    files = sorted(Path(a.days_dir).glob("*.npz"))
    todo = []
    for p in files:
        try:
            di = int(p.stem.replace("-", ""))
        except ValueError:
            continue
        if a.start <= di <= a.end:
            todo.append((di, p))
    print(f"[run] fold_{a.fold} {a.start}->{a.end}: {len(todo)} days -> {outdir}", flush=True)
    t0 = time.perf_counter(); n_samp = 0
    for k, (di, p) in enumerate(todo):
        op = outdir / f"{di}.npz"
        if op.exists():
            continue
        ts, h, q, sg = run_day(m, xm, safe, p, dev, a.bs)
        np.savez(op, ts_sec=ts.astype(np.int64), h_pred=h.astype(np.float32),
                 q50=q.astype(np.float32), sigma=sg.astype(np.float32))
        n_samp += len(ts)
        if (k + 1) % 50 == 0:
            print(f"  {k+1}/{len(todo)} days, {n_samp} samples, {time.perf_counter()-t0:.0f}s", flush=True)
    print(f"[done] {n_samp} samples over {len(todo)} days in {time.perf_counter()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
