"""PARADIGM BREAK: Gradient-Boosted Trees for cross-sectional alpha.
130+ deep experiments, ZERO tree-based. A linear model already beats our deep nets ->
strong signal a well-regularized nonlinear TABULAR learner (GBDT, industry standard for
weak-signal cross-sectional alpha) should beat both. LightGBM lambdarank directly
optimizes per-snapshot ranking (our money metric).

Two objectives, walk-forward 6-fold (rigorous), CS-normalized features, vs linear 0.0315 / deep 0.024.
"""
from __future__ import annotations
import datetime as _dt, json
from pathlib import Path
import numpy as np
from scipy.stats import rankdata
import lightgbm as lgb

NPZ=Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/npz_v23_400d_mmap")
UNIV9=[0,1,13,4,11,2,12,5,7,9]; H=600; ALLS=list(range(14))
def dr(a,b):
    s=_dt.date(a//10000,(a//100)%100,a%100);e=_dt.date(b//10000,(b//100)%100,b%100);o=[];d=s
    while d<=e:o.append(d.year*10000+d.month*100+d.day);d+=_dt.timedelta(days=1)
    return o
def load(dates,stride):
    Xs,Ys,Ts=[],[],[]
    for d in dates:
        xp,yp=NPZ/str(d)/"X.npy",NPZ/str(d)/"y_600.npy"
        if not xp.exists():continue
        X=np.load(xp,mmap_mode="r");Y=np.load(yp,mmap_mode="r");Tv=X.shape[0]-H;idx=np.arange(0,Tv,stride)
        Xs.append(np.asarray(X[idx],np.float32));Ys.append(np.asarray(Y[idx],np.float32))
        Ts.append(np.full(len(idx),d,dtype=np.int64)*100000+idx)  # unique snapshot id
    if not Xs:return None,None,None
    return np.concatenate(Xs),np.concatenate(Ys),np.concatenate(Ts)
def csfeat(X):  # raw + per-snapshot cross-sectional z-score concat -> (T,S,2F)
    m=np.nanmean(np.where(np.isfinite(X),X,np.nan),1,keepdims=True)
    sd=np.nanstd(np.where(np.isfinite(X),X,np.nan),1,keepdims=True)+1e-6
    return np.concatenate([np.nan_to_num(X,nan=0.0),np.nan_to_num((X-m)/sd,nan=0.0)],-1)
def csd(A):
    m=np.nanmean(np.where(np.isfinite(A),A,np.nan),1,keepdims=True);return A-m
def flatten(X,Y,T):
    Xf=csfeat(X)  # (t,S,2F)
    Yd=csd(Y)     # demeaned target
    t,S,F2=Xf.shape
    xr=Xf.reshape(t*S,F2); yr=Yd.reshape(t*S); gid=np.repeat(np.arange(t),S); aid=np.tile(np.arange(S),t)
    valid=np.isfinite(yr)&np.isfinite(xr).all(1)
    return xr,yr,gid,aid,valid,t,S
def eval_pred(pred_flat,Yd_flat,gid,aid,t,S,hold=24,cost=2.0):
    pred=np.full((t,S),np.nan);yv=np.full((t,S),np.nan)
    pred[gid,aid]=pred_flat; yv[gid,aid]=Yd_flat
    cs=[]
    for ti in range(t):
        row=pred[ti,UNIV9];yr=yv[ti,UNIV9];v=np.isfinite(row)&np.isfinite(yr)
        if v.sum()>=5 and np.std(row[v])>1e-12: cs.append(np.corrcoef(rankdata(row[v]),rankdata(yr[v]))[0,1])
    # vol-weight L/S on UNIV9, hold, net Sharpe
    P=pred[:,UNIV9]; Yu=yv[:,UNIV9]; avol=np.nanstd(Yu,0)+1e-9; Sn=len(UNIV9); W=np.zeros((t,Sn))
    for ti in range(t):
        v=np.isfinite(P[ti])
        if v.sum()<4:continue
        r=np.full(Sn,np.nan);r[v]=rankdata(P[ti,v]);r=r-np.nanmean(r);raw=np.where(v,r/avol,0.0)
        gl=np.abs(raw).sum()
        if gl>1e-12:W[ti]=raw/gl
    for ti in range(t):
        if ti%hold!=0:W[ti]=W[ti-1]
    pnl=np.nansum(W*np.where(np.isfinite(Yu),Yu,0.0),1);dW=np.abs(np.diff(W,axis=0,prepend=0)).sum(1)
    net=pnl-dW*cost*1e-4*0.5;ann=np.sqrt(52560)
    return (np.nanmean(cs) if cs else np.nan), net.mean()/(net.std()+1e-12)*ann, pnl.mean()/(pnl.std()+1e-12)*ann
FOLDS=[("F1",20240601,20240831,20240905,20240930),("F2",20240801,20241031,20241105,20241130),
 ("F3",20241001,20241231,20250105,20250131),("F4",20241201,20250228,20250305,20250331),
 ("F5",20250201,20250420,20250425,20250524),("F6",20250301,20250524,20250525,20250624)]
PARAMS_REG=dict(objective="regression_l2",num_leaves=15,min_child_samples=2000,learning_rate=0.03,
    feature_fraction=0.5,bagging_fraction=0.7,bagging_freq=1,lambda_l2=5.0,n_estimators=300,verbose=-1,n_jobs=8)
def main():
    print(f"{'fold':<5}{'test':>20}{'REG_cs':>9}{'REG_net2':>9}{'RANK_cs':>9}{'RANK_net2':>10}")
    rc,rn,kc,kn=[],[],[],[]
    for name,ta,tb,va,vb in FOLDS:
        Xt,Yt,Tt=load(dr(ta,tb),180);Xv,Yv,Tv=load(dr(va,vb),600)
        if Xt is None or Xv is None:print(f"{name} SKIP");continue
        xtr,ytr,gtr,atr,vtr,_,_=flatten(Xt,Yt,Tt); xte,yte,gte,ate,vte,tt,S=flatten(Xv,Yv,Tv)
        # --- regression on demeaned y ---
        m=lgb.LGBMRegressor(**PARAMS_REG); m.fit(xtr[vtr],ytr[vtr])
        pr=m.predict(xte)
        cs,n2,_=eval_pred(np.where(vte,pr,np.nan),np.where(vte,yte,np.nan),gte,ate,tt,S)
        rc.append(cs);rn.append(n2)
        # --- lambdarank (per-snapshot groups, relevance = rank bucket of demeaned y) ---
        # build groups: contiguous snapshots; relevance 0-9
        order=np.argsort(gtr[vtr],kind="stable"); xs=xtr[vtr][order]; ys=ytr[vtr][order]; gs=gtr[vtr][order]
        uniq,counts=np.unique(gs,return_counts=True)
        rel=np.zeros(len(ys),dtype=int); pos=0
        for c in counts:
            seg=ys[pos:pos+c]; rel[pos:pos+c]=np.clip((rankdata(seg)/max(1,c)*10).astype(int),0,9); pos+=c
        rk=lgb.LGBMRanker(objective="lambdarank",num_leaves=15,min_child_samples=500,learning_rate=0.03,
            feature_fraction=0.5,bagging_fraction=0.7,bagging_freq=1,lambda_l2=5.0,n_estimators=300,verbose=-1,n_jobs=8,label_gain=list(range(11)))
        rk.fit(xs,rel,group=counts)
        prk=rk.predict(xte)
        csk,nk2,_=eval_pred(np.where(vte,prk,np.nan),np.where(vte,yte,np.nan),gte,ate,tt,S)
        kc.append(csk);kn.append(nk2)
        print(f"{name:<5}{f'{va}-{vb}':>20}{cs:>+9.4f}{n2:>+9.2f}{csk:>+9.4f}{nk2:>+10.2f}",flush=True)
    import numpy as _np
    print(f"\nREG : cs_spear mean={_np.nanmean(rc):+.4f} (min {_np.nanmin(rc):+.4f})  net@2bp mean={_np.nanmean(rn):+.2f} ({int((_np.array(rn)>0).sum())}/{len(rn)} pos)")
    print(f"RANK: cs_spear mean={_np.nanmean(kc):+.4f} (min {_np.nanmin(kc):+.4f})  net@2bp mean={_np.nanmean(kn):+.2f} ({int((_np.array(kn)>0).sum())}/{len(kn)} pos)")
    print(f"(linear ridge baseline: cs_spear 0.0315, deep arch_v2: 0.024)")
if __name__=="__main__":
    main()
