"""Phase 15-B: fuse the FROZEN BTC-teacher h_pred stream into the multi-asset LOBNet3.

GOAL (user-set): alt-MEAN y_600 Pearson > 0.1 AND alt-mean > BTC, beta~1, monotone calibration, tradeable.
The teacher (single-asset REG_arch, pooled P=0.0664) extracts a 0.066-quality BTC market/lead-lag signal
that bar_1s features provably cap at ~0.025 (market_factor_probe). Injecting it gives each alt the
well-predicted market component on top of its own idio -> alts can exceed BTC.

Single-axis ablation vs the SAME base recipe (only the fusion changes):
  base     : no fusion (the floor)
  q50      : fusion ON, h_pred channels ZEROED -> only [q50,sigma] scalars (control; ~0.025 cap predicted)
  hl0      : fusion ON, h_pred lag0 only (K=1)
  multilag : fusion ON, full multi-lag h_pred (K=4, teacher 180s grid -> lags ~0/180/360/540s)

Leak controls (must collapse to ~base): --btc_scramble (permute alignment) ; --btc_shift_s (future-peek test).
Alignment: as-of causal dt-join (multi-asset dt.npy unix-sec  vs  teacher ts_sec); JOIN on time, never position.

Usage:
  python scripts/train_rawlob3_fusion.py --tag rl3fuse --configs base,q50,hl0,multilag \
      --pre_temporal --use_flow --per_asset
"""
from __future__ import annotations
import argparse, time, math, sys, glob
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from train_rawlob3 import preload, LOBNet3, make_batch, huber, NPZ, dev, S, FALL
from train_cs_ranker import UNIV10, UNIV_NAMES, dr, set_seed, lambdarank_loss

BTC_STREAM = Path("/mnt/storage/private/work_hsy/quant_research_multi_asset/data/btc_stream")

CONFIGS = {
    "base":     dict(use_btc_fusion=False, K=1, zero_hpred=False),
    "q50":      dict(use_btc_fusion=True,  K=4, zero_hpred=True),
    "hl0":      dict(use_btc_fusion=True,  K=1, zero_hpred=False),
    "multilag": dict(use_btc_fusion=True,  K=4, zero_hpred=False),
}


def build_btc_index(fold):
    files = sorted(glob.glob(str(BTC_STREAM / f"fold{fold}" / "*.npz")))
    assert files, f"no btc_stream files for fold{fold}"
    TS, V = [], []
    for f in files:
        z = np.load(f)
        TS.append(z["ts_sec"].astype(np.int64))
        V.append(np.concatenate([z["h_pred"], z["q50"][:, None], z["sigma"][:, None]], 1).astype(np.float32))  # (n,34)
    TS = np.concatenate(TS); V = np.concatenate(V)
    o = np.argsort(TS, kind="stable")
    return TS[o], V[o]


def attach_btc(samples, btc_ts, btc_vec, K, max_gap_s, shift_s=0, scramble=False, seed=42):
    """For each multi-asset sample (day d, sec-index t): abs_sec = dt[d][t]; as-of join the K most-recent
    teacher snapshots with ts <= abs_sec (causal). Returns btc_arr (N,K,34) + valid fraction."""
    daydt = {}
    N = len(samples); out = np.zeros((N, K, 34), np.float32); nval = 0
    for j, s in enumerate(samples):
        d, t = s[0], s[1]
        if d not in daydt:
            daydt[d] = np.load(NPZ / str(d) / "dt.npy")
        abs_sec = int(daydt[d][t]) + shift_s
        pos = np.searchsorted(btc_ts, abs_sec, side="right")  # first index > abs_sec
        idxs = (pos - 1) - np.arange(K)                        # pos-1, pos-2, ..., pos-K (most-recent first)
        if idxs[-1] < 0 or (abs_sec - int(btc_ts[pos - 1])) > max_gap_s:
            continue                                           # invalid -> leave zeros (gate handles it)
        out[j] = btc_vec[idxs]; nval += 1
    if scramble:                                               # leak control: destroy sample<->btc alignment
        out = out[np.random.default_rng(seed).permutation(N)]
    return out, nval / max(N, 1)


def _metrics(P, Y, Vm, rowmask=None):
    res = {}
    for a in UNIV10:
        p = P[:, a]; yy = Y[:, a]; m = Vm[:, a] & np.isfinite(p) & np.isfinite(yy)
        if rowmask is not None: m = m & rowmask
        if m.sum() < 100 or np.std(p[m]) < 1e-12: continue
        pc = np.corrcoef(p[m], yy[m])[0, 1]; beta = np.cov(yy[m], p[m])[0, 1] / np.var(p[m])
        sr = np.std(p[m]) / (np.std(yy[m]) + 1e-12); sh = np.mean(np.sign(p[m]) == np.sign(yy[m]))
        res[a] = (pc, beta, sr, sh)
    return res


@torch.no_grad()
def evaluate_fusion(model, samples, rawlob, win, sub, btc_arr, ymad, ymed, bs=192, cov_mask=None):
    model.eval(); P = np.zeros((len(samples), S), np.float32); Y = np.zeros((len(samples), S), np.float32); Vm = np.zeros((len(samples), S), bool)
    for i in range(0, len(samples), bs):
        idx = list(range(i, min(i + bs, len(samples))))
        hand, lob, y, v = make_batch(samples, idx, rawlob, win, sub, True)
        bt = torch.from_numpy(btc_arr[idx]).to(dev) if btc_arr is not None else None
        q, _, _, _ = model(hand.to(dev), lob.to(dev), bt)
        P[idx] = q.cpu().numpy(); Y[idx] = y.numpy(); Vm[idx] = v.numpy()
    P = P * ymad + ymed
    res = _metrics(P, Y, Vm)                                   # full eval (pooled, diluted by no-coverage rows)
    res_cov = _metrics(P, Y, Vm, rowmask=cov_mask) if cov_mask is not None else None  # covered-only (isolates the fusion lift)
    return res, res_cov


def train_eval(name, cfg, sm_tr, rl_tr, sm_vs, rl_vs, sm_ev, rl_ev, bt_tr, bt_vs, bt_ev, hmed, hmad, ymed, ymad, a, cov_ev=None):
    set_seed(42)
    use_f = cfg["use_btc_fusion"]
    model = LOBNet3(hmed, hmad, d=a.d, use_lob=True, pre_temporal=a.pre_temporal, use_flow=a.use_flow,
                    per_asset=a.per_asset, use_regime_film=a.use_regime_film,
                    use_btc_fusion=use_f, btc_lags=cfg["K"], temporal=a.temporal, n_tlayers=a.n_tlayers).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    outdir = Path(f"/mnt/storage/private/work_hsy/quant_research_multi_asset/experiments/diagnostic_{a.tag}_{name}"); outdir.mkdir(parents=True, exist_ok=True)
    ym = torch.from_numpy(ymed.astype(np.float32)).to(dev); yd = torch.from_numpy(ymad.astype(np.float32)).to(dev)
    rng = np.random.default_rng(42); N = len(sm_tr); best = -1e9; bad = 0
    K = cfg["K"]
    btr = bt_tr[:, :K] if use_f else None; bvs = bt_vs[:, :K] if use_f else None; bev = bt_ev[:, :K] if use_f else None
    print(f"\n##### {name}  fusion={use_f} K={K} zero_hpred={cfg['zero_hpred']} params={sum(p.numel() for p in model.parameters()):,} #####", flush=True)
    def cos(ep): return a.lr * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * ep / a.epochs))) if ep > 2 else a.lr * ep / 2
    for ep in range(1, a.epochs + 1):
        for g in opt.param_groups: g['lr'] = cos(ep)
        if use_f: model.warmup.fill_(min(1.0, (ep - 1) / 3.0))  # base converges first, fusion ramps in
        model.train(); perm = rng.permutation(N); losses = []; te = time.perf_counter()
        for i in range(0, N - a.bs + 1, a.bs):
            idx = perm[i:i + a.bs]
            hand, lob, yraw, vb = make_batch(sm_tr, idx, rl_tr, a.win, a.sub, True)
            hand = hand.to(dev); yraw = yraw.to(dev); vb = vb.to(dev); vf = vb.float()
            if vf.sum() < 1: continue
            bt = torch.from_numpy(btr[idx]).to(dev) if use_f else None
            yz = torch.clamp((yraw - ym) / yd, -6, 6)
            opt.zero_grad(set_to_none=True)
            q, slog, ma, rk = model(hand, lob.to(dev), bt)
            magl = (huber(q, yz) * vf).sum() / vf.sum().clamp(min=1)
            wsign = (yz.abs().clamp(max=5).pow(1.5) * (yz.abs() > 0.5).float() + 1e-3) * vf
            sign = (F.binary_cross_entropy_with_logits(slog, (yz > 0).float(), reduction='none') * wsign).sum() / wsign.sum().clamp(min=1)
            magf = (huber(ma, yz.abs()) * (1 + yz.abs()) * vf).sum() / ((1 + yz.abs()) * vf).sum().clamp(min=1)
            ydem = yz - (yz * vf).sum(1, keepdim=True) / vf.sum(1, keepdim=True).clamp(min=1)
            rankl = lambdarank_loss(rk, ydem, vb)
            loss = magl + a.sign_w * sign + a.magf_w * magf + a.rank_w * rankl
            if not torch.isfinite(loss): continue
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); losses.append(loss.item())
        if use_f: model.warmup.fill_(1.0)  # full gate at eval
        rv, _ = evaluate_fusion(model, sm_vs, rl_vs, a.win, a.sub, bvs, ymad, ymed)
        pv = np.nanmean([rv[x][0] for x in rv]) if rv else np.nan
        mark = ""
        if np.isfinite(pv) and pv > best + 1e-5: best = pv; bad = 0; torch.save(model.state_dict(), outdir / "best.pt"); mark = "★"
        else: bad += 1
        gs = ""
        if use_f:
            gf = torch.tanh(model.gf_btc).detach().cpu().numpy()
            gs = f" gf(ETH={gf[1]:+.2f} SOL={gf[2]:+.2f} FIL={gf[12]:+.2f}) gbtc={math.tanh(float(model.g_btc_self)):+.2f}"
        print(f"  [{name}] ep{ep:02d}/{a.epochs} loss={np.mean(losses):.4f} vselP={pv:+.4f} bad={bad}{gs} ({time.perf_counter()-te:.0f}s){mark}", flush=True)
        if bad >= a.patience and ep >= 5: print(f"  [{name}] [early-stop]", flush=True); break
    if not (outdir / "best.pt").exists(): torch.save(model.state_dict(), outdir / "best.pt")
    model.load_state_dict(torch.load(outdir / "best.pt", map_location=dev))
    if use_f: model.warmup.fill_(1.0)
    return evaluate_fusion(model, sm_ev, rl_ev, a.win, a.sub, bev, ymad, ymed, cov_mask=cov_ev)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True); ap.add_argument("--configs", default="base,q50,hl0,multilag")
    ap.add_argument("--fold", type=int, default=1)  # teacher fold (fold_1 OOS for 2025-04-19..05-18)
    ap.add_argument("--train_start", type=int, default=20231201); ap.add_argument("--train_end", type=int, default=20250418)
    ap.add_argument("--eval_start", type=int, default=20250419); ap.add_argument("--eval_end", type=int, default=20250518)
    ap.add_argument("--win", type=int, default=600); ap.add_argument("--sub", type=int, default=1)
    ap.add_argument("--stride", type=int, default=360); ap.add_argument("--epochs", type=int, default=14)
    ap.add_argument("--bs", type=int, default=96); ap.add_argument("--lr", type=float, default=8e-4)
    ap.add_argument("--wd", type=float, default=1e-3); ap.add_argument("--d", type=int, default=96)
    ap.add_argument("--sign_w", type=float, default=0.1); ap.add_argument("--rank_w", type=float, default=0.3); ap.add_argument("--magf_w", type=float, default=0.3)
    ap.add_argument("--pre_temporal", action="store_true"); ap.add_argument("--use_flow", action="store_true")
    ap.add_argument("--per_asset", action="store_true"); ap.add_argument("--use_regime_film", action="store_true")
    ap.add_argument("--temporal", default="conv", choices=["conv", "transformer"]); ap.add_argument("--n_tlayers", type=int, default=2)  # deep-idio: E215c self-attention temporal
    ap.add_argument("--max_gap_s", type=int, default=600); ap.add_argument("--btc_shift_s", type=int, default=0); ap.add_argument("--btc_scramble", action="store_true")
    ap.add_argument("--patience", type=int, default=4)
    a = ap.parse_args(); set_seed(42)
    want = [c.strip() for c in a.configs.split(",") if c.strip()]
    tr = dr(a.train_start, a.train_end); vsel = tr[-20:]; tr = tr[:-20]
    t0 = time.perf_counter(); print(f"[preload-ONCE] train {len(tr)}d configs={want} teacher=fold{a.fold} ...", flush=True)
    rl_tr, sm_tr = preload(tr, a.win, a.stride)
    rl_vs, sm_vs = preload(vsel, a.win, 600); rl_ev, sm_ev = preload(dr(a.eval_start, a.eval_end), a.win, 600)
    print(f"  preloaded train={len(sm_tr)} vsel={len(sm_vs)} eval={len(sm_ev)} in {time.perf_counter()-t0:.0f}s", flush=True)
    # frozen-train robust-z (handcrafted) + target MAD-z
    hf = np.stack([sm_tr[i][2] for i in range(0, len(sm_tr), max(1, len(sm_tr)//6000))]).reshape(-1, FALL)
    hmed = np.nan_to_num(np.median(hf, 0)); hmad = 1.4826 * np.median(np.abs(hf - hmed), 0) + 1e-6
    hmad = np.where(np.isfinite(hmad) & (hmad > 1e-9), hmad, 1.0)
    yt = np.stack([sm_tr[i][3] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))]); vt = np.stack([sm_tr[i][4] for i in range(0, len(sm_tr), max(1, len(sm_tr)//12000))])
    yv = np.where(vt, yt, np.nan); ymed = np.nan_to_num(np.nanmedian(yv, 0, keepdims=True))
    ymad = 1.4826 * np.nanmedian(np.abs(yv - ymed), 0, keepdims=True); ymad = np.where(np.isfinite(ymad) & (ymad > 1e-12), ymad, 1.0) + 1e-12
    # --- BTC teacher stream: as-of dt-join + frozen-train normalization ---
    btc_ts, btc_vec = build_btc_index(a.fold)
    print(f"[btc] fold{a.fold} index: {len(btc_ts)} snapshots {time.strftime('%Y-%m-%d', time.gmtime(int(btc_ts[0])))}->{time.strftime('%Y-%m-%d', time.gmtime(int(btc_ts[-1])))}", flush=True)
    Kmax = max(CONFIGS[c]["K"] for c in want)
    bt_tr, cov_tr = attach_btc(sm_tr, btc_ts, btc_vec, Kmax, a.max_gap_s, a.btc_shift_s, a.btc_scramble)
    bt_vs, cov_vs = attach_btc(sm_vs, btc_ts, btc_vec, Kmax, a.max_gap_s, a.btc_shift_s, a.btc_scramble)
    bt_ev, cov_ev = attach_btc(sm_ev, btc_ts, btc_vec, Kmax, a.max_gap_s, a.btc_shift_s, a.btc_scramble)
    print(f"[btc] coverage tr={cov_tr:.3f} vs={cov_vs:.3f} ev={cov_ev:.3f}  shift_s={a.btc_shift_s} scramble={a.btc_scramble}", flush=True)
    # per-channel robust-z from TRAIN valid rows (leak-free); applied to all splits
    flat = bt_tr.reshape(-1, 34); valid = np.any(flat != 0, 1)
    bmed = np.median(flat[valid], 0); bmad = 1.4826 * np.median(np.abs(flat[valid] - bmed), 0) + 1e-6
    bmad = np.where(bmad > 1e-9, bmad, 1.0)
    def norm(b, zero_h):
        bn = np.where(np.any(b != 0, -1, keepdims=True), np.clip((b - bmed) / bmad, -8, 8), 0.0).astype(np.float32)
        if zero_h: bn = bn.copy(); bn[..., :32] = 0.0
        return bn
    cov_ev = np.any(bt_ev != 0, axis=(1, 2))  # eval coverage (same rows for all configs incl. base) -> apples-to-apples covered-only
    allres = {}
    for name in want:
        zh = CONFIGS[name]["zero_hpred"]
        allres[name] = train_eval(name, CONFIGS[name], sm_tr, rl_tr, sm_vs, rl_vs, sm_ev, rl_ev,
                                  norm(bt_tr, zh), norm(bt_vs, zh), norm(bt_ev, zh), hmed, hmad, ymed, ymad, a, cov_ev=cov_ev)
    R = {n: allres[n][0] for n in want}        # full (pooled) per-asset metrics
    Rc = {n: allres[n][1] for n in want}       # covered-only per-asset metrics
    # ---- summary: per-asset + alt-mean vs BTC (the user gate) ----
    print(f"\n===== PHASE-15 FUSION (OOS {a.eval_start}->{a.eval_end}, {len(tr)}d, seed42, cov_ev={cov_ev.mean():.3f}) =====", flush=True)
    print("  asset " + "".join(f"{n:>12s}" for n in want), flush=True)
    for x in UNIV10:
        row = f"  {UNIV_NAMES[x]:5s}"
        for n in want: row += f"{(R[n].get(x,(np.nan,))[0]):>+12.4f}"
        print(row, flush=True)
    print("  " + "-" * (7 + 12 * len(want)), flush=True)
    ALT = [x for x in UNIV10 if x != 0]  # alts = UNIV10 minus BTC
    def meanrow(label, dct, sel, idx=0, fmt="+12.4f"):
        row = f"  {label:12s}"
        for n in want:
            d = dct[n]; vals = [d[x][idx] for x in sel if d and x in d]
            row += f"{(np.nanmean(vals) if vals else np.nan):>{fmt}}"
        print(row, flush=True)
    meanrow("MEAN_all", R, UNIV10); meanrow("MEAN_ALT", R, ALT); meanrow("BTC", R, [0])
    meanrow("ALT_beta", R, ALT, idx=1, fmt="+12.2f"); meanrow("ALT_sign", R, ALT, idx=3, fmt="12.3f")
    print("  --- covered-only (samples with a BTC token; isolates the fusion lift) ---", flush=True)
    meanrow("covMEAN_ALT", Rc, ALT); meanrow("covBTC", Rc, [0])
    print("  GATE: alt-MEAN P > 0.1 AND alt-MEAN > BTC | beta~1 | multilag>>q50-control | scramble/future-shift must collapse to base", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
