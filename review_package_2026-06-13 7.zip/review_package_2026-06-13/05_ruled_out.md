# 05 — 已系统证伪清单（防止重复试错）

> ~230 个实验积累的完整 kill list，每条附杀死证据与出处。请合作者重点看末尾「cross-cutting meta-verdicts」的 caveat：部分 kill 是目标函数特异（cs-z/idio-rank 上成立），并非全部是机制级证伪。

# RULED-OUT / FAILED Directions — Complete Kill List (compiled from all 60 files in `~/.claude/projects/-Users-haosiyu-Desktop-multi-asset-crypto/memory/`)

## Architecture / capacity
- **Architecture scaling (wider/deeper)** → E145 d384/L5 = 0.0432 ≈ E144 (saturated); E179-E182 single-axis screen (rank_w2 / gru_layers2 / d_t128 / layers8) ALL dead, P9 down; "bigger=worse" pattern across ~185 exps → `findings_e142_dl_csranker_breakthrough.md`, `findings_guarded_crossasset.md`
- **Regime-routing MoE** → E184 MoE-4 140d +0.002 (noise); E185 n_exp=6 overfit; E186 MoE on 386d REGRESSED cs 0.055→0.0495 — two-point dead → `findings_guarded_crossasset.md`, `findings_signal_bound_ceiling_2026-05-30.md`
- **Conformer temporal encoder on cs-idio rank target** → E196/E197 (L30/L10) 0.039 < GRU 0.0439; E198 386d dense 0.0471 < GRU 0.055 — two-point robust negative (rich encoder overfits low-SNR idio; it only wins on MAGNITUDE objective) → `findings_arch_critique_2026-05-30.md`, `findings_magnitude_pivot_2026-05-30.md`
- **Head LayerNorm (--head_norm, E187)** → 0.0423 < 0.0439, LN strips scale heads use → `findings_arch_critique_2026-05-30.md`
- **Attn-pool over GRU states at coarse L10 (E188)** → 0.0398 << 0.0439 (nothing to attend over) → `findings_arch_critique_2026-05-30.md`
- **Finer-resolution-ALL-features temporal (E193 L30/s20; E183 L20)** → 0.0386 < 0.0439 / flat — slow families broadcast to 20s = noise → `findings_arch_critique_2026-05-30.md`, `findings_guarded_crossasset.md`
- **Multi-rate fast-channels-only temporal (E195)** → 0.0301 << 0.0439 (temporal needs full trajectory) → `findings_arch_critique_2026-05-30.md`
- **mag_film per-asset FiLM on mag branch (E211)** → AGG flat, DOT/ETC down — redistribution not win → `findings_magnitude_pivot_2026-05-30.md`
- **Per-asset (vector) cross-asset gate (E176)** → cs flat 0.0552, P9 DROPPED 0.0455→0.0409 — clean negative vs scalar gate → `findings_guarded_crossasset.md`

## Feature crossing / interaction modules
- **GDCN / DCN-V2 / cross-net crossing** → E146 GDCN 0.0326 < MLP 0.0439 (overfit); E189/E191 dcnv2_csz done RIGHT (cs-z-only, low-rank, identity-init) two-point robust negative (140d 0.0492<0.0506 AND 386d 0.0543<0.0550, P9 hurt); DCN-V2 on RawLOBNet 0.039→0.019 → `findings_e142_dl_csranker_breakthrough.md`, `findings_arch_critique_2026-05-30.md`, `findings_redesign_blueprint_2026-06-01.md`
- **FM low-rank interactions (E168)** → gated to −0.003, 0.0447 → `findings_signal_bound_ceiling_2026-05-30.md`, `findings_crossdomain_arch_verdict.md`
- **GBDT-style tree edge via NN tricks generally** → "DON'T try to out-tabular GBDT with NN tricks" — trees' axis-aligned splits not capturable → `findings_e142_dl_csranker_breakthrough.md`

## Cross-asset attention / lead-lag
- **Symmetric cross-asset self-attention over asset tokens (unguarded, E140/E141)** → ln2-collapse: within-snapshot variance→0, LambdaRank pinned at softplus(0)=0.6931 → `findings_e142_dl_csranker_breakthrough.md`
- **2-layer guarded cross-asset (E173)** → cs 0.049 < 1-layer 0.052 — extra capacity overfits (1-layer guarded E172 is the only keeper, +0.003) → `findings_guarded_crossasset.md`
- **Asymmetric BTC/ETH lead-lag module (E149)** → AGG 0.0480 vs 0.0501 base, gate ~0 — redundant with cs-z + temporal GRU → `findings_e142_dl_csranker_breakthrough.md`
- **Lagged-leader features (E66 multi-lag stack)** → cs_spear flat +0.0148, EMA crash ep7, marginal-fail gate → `findings_e66_multilag.md`
- **Cross-asset attn / lead-lag on causal raw objective** → both FLAT (+0.033 / +0.030 vs +0.031 baseline) in 6-axis lever audit → `findings_norm_lookahead_leak_2026-06-01.md`
- **Cross-asset basket for BTC raw (rl3btc3/rl3btc2b)** → IS 0.060 → OOS 0.020 (overfit), regressed mid-caps via shared trunk (SOL 0.067→0.025); < per-asset-gate 0.028 → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **var_w sweep on cross-asset (E175)** → flat axis in [0.5,2.0] → `findings_guarded_crossasset.md`

## FactorBridge / market head
- **FactorBridge market-factor term (E161/E162)** → model DECLINED it: alpha_F gate→0 in both rank- and mag-primary regimes (later E229 showed the gate→0 was partly a no-raw-target confound; un-confounded it helps cs/BTC but does NOT unlock raw magnitude) → `findings_market_factor_predictable.md`, `findings_dl_vs_tree_fullmetrics_2026-05-30.md`
- **Market-head variants (strong_mkt / mkt_raw)** → E229f attention-pool+deeper MLP F̂ 0.017 < flat-mean 0.025; E229g raw-features head F̂ −0.001 — market direction is SIGNAL-limited ~0.025, not architecture-limited → `findings_multitarget_2026-05-31.md`
- **Dedicated REG_arch-style market-series model** → market_factor_probe: ridge 0.0141/GBDT 0.0184 < F̂ 0.025, W4 sign-flip; BTC 0.067 is BTC-directional NOT the market factor — "gap" was a red herring → `findings_multitarget_2026-05-31.md`
- **Kendall uncertainty weighting (--uw, E229h) + 60-epoch long (E229e_long)** → both slightly worse than static-weight E229e 40ep → `findings_multitarget_2026-05-31.md`

## SSL / pretraining
- **SSL same-data (GRU next-step, E212)** → +0.0014 cs / −0.0043 P9 ≈ flat → `findings_magnitude_pivot_2026-05-30.md`
- **SSL same-data (transformer masked-patch, E215b)** → regressed BOTH (−0.0135 cs, −0.0089 P9); transfer surface only 332KB of 1.64M params → `findings_signal_bound_ceiling_2026-05-30.md`, `findings_magnitude_pivot_2026-05-30.md`

## Data scale / resolution / new-info
- **Data-scale 570d+ (E224, train_start 20230828)** → cs 0.0526→0.0475, P9 0.0440→0.0372 WORSE (2023 drift, 18.5% feature-corr sign-flips) — do NOT build 1430d NPZ → `findings_signal_bound_ceiling_2026-05-30.md`
- **More data 290d (E41) / REG_arch optim port batch128+lr3e-4+wd (E44)** → both killed ep3-4, ema_P below E29 → `findings_reg_arch_optim_gap_2026-05-22.md`
- **Fine resolution via cs-z path (E228, step 60→10 on raw target)** → raw P9 0.0255→0.004 DECISIVE negative; 10s frames are noise at y_600 → `findings_dl_vs_tree_fullmetrics_2026-05-30.md`
- **Fine 1s-LOB stream (--fine_lob, even at y_120 most-favorable)** → coarse 0.0927 / fine60 0.0932 / fine120 0.0921 = ±0.0006 noise — resolution lever CLOSED at fast AND slow horizons → `findings_npz_foundation_audit_2026-05-31.md`
- **Signed-book-event 1s channels** → gate KILLED: inst-1s residual CS-IC +0.0070 < +0.010 bar; ema10/30/agg60 all NEGATIVE — signal decays <10s, doesn't survive to y_600 → `findings_new_info_audit_2026-05-30.md`
- **Trade-flow finer than 60s** → decisive read-only test: 1/5/15s imbalance/sign-autocorr/intensity weak + sign-flip, incremental ridge NEGATIVE — spend ZERO further effort → `findings_crossdomain_arch_verdict.md`
- **Multi-level OFI factor (#1 frontier candidate)** → best per-level incremental cs-IC L3 +0.0064 < +0.010 gate — redundant on 1s bars → `findings_ic_term_structure_2026-05-31.md`
- **slope_imbalance / convexity book-shape factors** → corrected dual gate (UNIV10, idio AND raw) overturned the idio-only false positive: residual sign-flipped (suppressor artifact, collinear with L1 depth-imbalance) → `findings_ic_term_structure_2026-05-31.md`
- **Universe expansion 14→50-60 perps** → only 19 symbols exist in the feed (14 USDT + 5 dup USDC) — breadth lever DEAD → `findings_magnitude_pivot_2026-05-30.md`
- **Porting single-asset's 121 precomputed features (preprocess_bar_xsec_v2)** → would REGRESS: our features beat theirs 2× (ridge 0.044 vs 0.022) → `findings_norm_lookahead_leak_2026-06-01.md`
- **funding/OI/liquidations/true-tick** → physically ABSENT from /mnt/storage/share (data-access limit, not testable) → `findings_new_info_audit_2026-05-30.md`

## Regime / drift
- **Recency-weighted training (E164, --recency 0.3)** → cs 0.0452/P9 0.0269 vs 0.050/0.034 base, W4 NOT improved — OOS windows are distinct regimes, reweighting can't match unseen regime → `findings_regime_drift_methods.md`
- **V-REx as a breakthrough** → final beta-curve verdict = WEAK-REAL mild regularizer only (~+0.005 P9 at beta 1-1.25, cs unmoved); the E165 +0.011 was noise-inflated → `findings_regime_drift_methods.md`
- **Regime FiLM for BTC raw (rl3btc2 S2)** → BTC 0.014→0.002 HURT, redistributed to DOT/LINK → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **Regime-state prediction (detect coming regime)** → absolute-level detector 0.81 in-sample INVERTS cross-pair (0.306) = calendar artifact; drift adaptable-not-predictable → `findings_regime_drift_methods.md`

## Targets / labels / horizons
- **book_mid target (E65)** → ema_P +0.0104 vs E56 +0.0332 (−0.023) — quote-noise-sensitive; keep trade-mid → `findings_e65_book_mid_failed.md`
- **Single-head idio target swap (E75, σ_match=0)** → cs +0.005 but per-asset P dropped −0.005, BTC raw 0.021, σ collapsed 0.028 — trade-off too costly → `findings_e75_incremental.md`
- **Raw target at y_3600 (E171)** → raw P AGG 0.011, BTC −0.018 << idio 0.047 — "market predictable at 1h → raw works" REFUTED → `findings_longhorizon_tradeable.md`
- **y_3600 as a y_600 cs lever** → worse (0.0421) → `findings_signal_bound_ceiling_2026-05-30.md`
- **Dual-horizon rank-short/mag-long (rank_horizon=300)** → two-point DISCARD: Δcs +0.0034→+0.0010 (collapsed at 386d), both < 0.005 noise floor; rh=120 overshoots (mag drops) → `findings_ic_term_structure_2026-05-31.md`, `findings_horizon_economics_2026-05-31.md`
- **Un-pool + warm-start stack** → combined 0.0360 < warm-alone 0.0409 ≈ base; ±0.005 single-seed deltas = noise, not banked → `findings_ic_term_structure_2026-05-31.md`
- **y_600 cs_spearman>0.10 / pool P>0.05-on-idio targets** → structurally unreachable (multivariate OOS ceiling ~0.04-0.059; GBDT≈DL≈ridge converge) → `findings_tradeable_linear_alpha_2026-05-29.md`, `findings_signal_bound_ceiling_2026-05-30.md`
- **Horizons >1h (y_7200/y_14400)** → ridge gross collapses (−2.8bps @4h); DL gross plateaus ~2bp — no gain beyond y_1800/3600 → `findings_horizon_economics_2026-05-31.md`

## Losses / normalization
- **pearson_reg as σ anchor (E7 sweet-point)** → no sweet point exists — 1/σ_yhat divergent gradient; REG_arch itself has lambda_pearson=0 → `findings_sigma_collapse_root_cause.md`
- **cs_ic_ir loss (E20)** → NOT identity-init compatible: 0/0 → grad_norm 1.7e8 at step 0, degenerate basin → `findings_e20_failure_analysis.md`
- **CS-priority loss boost (E35: cs_spearman→1.0 + pairwise_rank)** → per-asset crashed, CS unchanged (pairwise stuck at ln2) — CS loss can't fix homogenized backbone → `findings_e29_diagnostic_2026-05-22.md`
- **huber_w 0.5 magnitude boost on shared backbone (E152)** → cs CRASHED 0.0516→0.0296 — sharp rank-vs-mag tradeoff, keep huber_w 0.1 → `findings_e142_dl_csranker_breakthrough.md`
- **DAQH + REG_arch 5-component loss on multi-asset deep** → rawP10 +0.005 (HURT −0.026 vs plain Huber+rank) — single-asset recipe doesn't transfer → `findings_norm_lookahead_leak_2026-06-01.md`
- **Per-day / future-inclusive input normalization** → intra-day LOOK-AHEAD leak, inflated raw Pearson 14× (0.11 → causal 0.008) — must be frozen-train/RevIN/trailing → `findings_norm_lookahead_leak_2026-06-01.md`
- **RevIN + sequence model for raw y_600 magnitude** → snapshot ridge 0.044 > deep sequence 0.030 (RevIN destroys absolute scale; sequence redundant); pooled-MLP snapshot σ-collapsed to 0.005 → `findings_norm_lookahead_leak_2026-06-01.md`
- **Loss simplification (drop mag-focal) for BTC (rl3btc1 C1)** → regressed mid-caps SOL 0.070→0.040 — mag_focal load-bearing → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **σ_match for BTC raw** → BTC 0.028→0.014 HURT (it is a β-calib tool, not a BTC lever) → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **Drop CS-rank co-train for BTC (rank_w 0)** → BTC 0.0255→0.0143 HURT — rank co-train is the dominant raw lever, loss not the BTC unlock → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **EMA weights for BTC** → BTC 0.0277→0.0192 HURT (helps mean/mid-caps only) → `findings_rawlob3_audit_fixes_2026-06-01.md`
- **Computable interaction features for BTC (rl3feat)** → BTC 0.0218 FLAT — gap is uncomputable 25-level/tick features; BTC>0.07 = data-access limit → `findings_rawlob3_audit_fixes_2026-06-01.md`

## Raw-LOB add-on paths (early generation)
- **LOB raw path as identity-init add-on (E18/E30)** → no lift (E18 ema_P 0.009 vs E15 0.025): under-capacity 710-param encoder, patch=30 destroyed 1s events, big trunk diluted d_raw=16 → `findings_e18_lob_raw_attribution.md`, `findings_experiments_summary_2026-05-22.md`
- **E22 module stack (FiLM/GDCN/lead-lag bundle on E29)** → cs_spear↑ but ema_P↓, net no gain → `findings_experiments_summary_2026-05-22.md`
- **LOBNet3 as originally built ("1s order-flow" model)** → was actually a 10s-token book-shape model: patch-before-temporal, cross-channel LayerNorm erased book magnitude, flow broadcast-constant (fixes A1+A4 later validated +89%) → `findings_rawlob3_audit_fixes_2026-06-01.md`

## Phase 15 (BTC-teacher fusion)
- **Transformer-on-raw+fusion (Phase 15-C)** → NEGATIVE: base-tf 0.033 ≈ conv 0.032 (LOBNet3-transformer 的 vsel 优势是 in-sample overfit；非 E215c 自身 idio 结果), fusion-on-transformer REGRESSED to 0.028 ≪ conv multilag 0.045 — conv multilag stays deliverable → `findings_phase15_btc_fusion_2026-06-03.md`
- **Full-day teacher coverage rebuild** → full-cov preview MEAN_ALT 0.0412 ≤ 41%-cov 0.0445 — coverage NOT the bottleneck, 10h build SAVED → `findings_phase15_btc_fusion_2026-06-03.md`
- **Rich h_pred (32-dim) for alts** → multilag ≈ q50 scalar on alts (0.0454 vs 0.0439) — alts only absorb BTC DIRECTION; fusion plateaus ~0.045, 0.1 unreachable on raw y_600 → `findings_phase15_btc_fusion_2026-06-03.md`

## Training schedule / misc
- **BTC-only training (E_diag, E25-26)** → BTC 0.040 < multi-asset 0.060 — multi-asset HELPS via implicit σ regularization → `findings_e_diag_root_cause.md`
- **Heavy regularization (E27)** → underfits, val_P=0 → `findings_experiments_summary_2026-05-22.md`
- **Lookback 1800s for y_600** → E29 proved lookback must ≈ horizon (600s): 1800 = 2/3 stale info; static 7-month-gap val = regime-drift artifact → `findings_e29_breakthrough.md`, `findings_overfit_regime_drift.md`
- **Incremental feature additions past ~+0.04 (Tier-10 VPIN/Kyle E68, Tier-11, v24 131-feat E120)** → signal redistribution not lift; cs_spear cap structural; v24 no lift → `findings_e68_tier10.md`, `findings_npz_foundation_audit_2026-05-31.md`
- **E52 BTC=0.076 "breakthrough"** → NOT reproducible — single-epoch RAW-model outlier at cosine-decay end; stable EMA peak ~0.05 → `findings_e52_breakthrough.md`
- **Level attention-pool (mean→soft pool program)** → pre-registered offline probe NULL (AGG −0.0055 < +0.003 gate) — extraction thread exhausted → `findings_crossdomain_arch_verdict.md`
- **700d supervised NPZ build** → disk-blocked (needs ~350G+, would fill shared disk); also drift-risky → `findings_crossdomain_arch_verdict.md`

## Trading / backtest
- **y_600 trading @2bp (any model)** → structural cost wall: ~1bp gross edge vs 2-4bp perp cost; higher IC (E155 0.054) does NOT beat the wall; y_600 = horizon-economics "dead zone" → `findings_e142_dl_csranker_breakthrough.md`, `findings_horizon_economics_2026-05-31.md`
- **y_1800 "+1.7 Sharpe @2bp" deliverable** → walk-forward correction: favorable-2025-window ARTIFACT — 8-fold DL best naive @2bp −0.52; signal real but sub-economic at 2bp → `findings_npz_foundation_audit_2026-05-31.md`
- **mag-tilt position sizing** → HURTS (@1bp −0.01, critic-confirmed, mag head mis-calibrated) → `findings_npz_foundation_audit_2026-05-31.md`
- **tail-K concentration (vs full-CS)** → loses diversification (+0.35 < full-CS +0.74 @1bp); conviction-gating also failed earlier on linear (loses breadth) → `findings_npz_foundation_audit_2026-05-31.md`, `findings_tradeable_linear_alpha_2026-05-29.md`
- **Maker-execution assumption** → fantasy per critic: adverse selection (posted side gets filled when wrong) — honest taker 4.5bp/side → `findings_npz_foundation_audit_2026-05-31.md`
- **Plain-Huber calibrated-raw directional model** → σ-COLLAPSED (β=50, σ_pred/σ_act=0.00) — raw too noisy to calibrate-predict without σ_match/DAQH machinery → `findings_npz_foundation_audit_2026-05-31.md`

## Constraints (not empirical, but enforced kills)
- **Multi-seed ensemble / SWA / weight averaging / post-training stacking** → P8 explicit user constraint: forbidden until single-model maxed; single-asset 0.0667 was a 5-way ensemble (P8-forbidden reference point, single-model = 0.0646) → CLAUDE.md P8, `findings_norm_lookahead_leak_2026-06-01.md`, `findings_rawlob3_audit_fixes_2026-06-01.md`
- **Touching /mnt/storage/share raw data** → hard user constraint, never delete/modify → `feedback_share_data_protection.md`

## Cross-cutting meta-verdicts
- **"More architecture on cs-idio" generally** → every added module gated-to-0 or overfit (cross-asset unguarded, GDCN, lead-lag, FactorBridge, level-pool, FM, MoE); ceiling is information/SNR-bound (GBDT 0.0587 ≈ DL 0.055 on same input) → `findings_crossdomain_arch_verdict.md`, `findings_signal_bound_ceiling_2026-05-30.md`
- **Caveat on the above** → later memos show some "kills" were integration-bug or objective-specific confounds (DCN-V2 random-init xproj; cross-asset ln2-collapse fixed by var-floor; FactorBridge no-raw-target confound; "ridge>DL" was a broken-stack artifact) — kills are trustworthy on the cs-z/idio-rank objective but several were NOT clean mechanism falsifications on other objectives → `findings_module_integration_design_2026-06-01.md`, `findings_redesign_blueprint_2026-06-01.md`, `findings_dl_vs_tree_fullmetrics_2026-05-30.md`