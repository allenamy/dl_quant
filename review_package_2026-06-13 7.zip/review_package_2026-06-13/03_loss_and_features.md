# 03 — 损失函数与特征体系（代码核对版）

> (A) 全程序损失设计：当前 LOBNet3/fusion 配方、σ_match 校准项、cs_ranker 配方（LambdaRank/CCC/split_mag/factor_bridge）、单资产教师五件套、以及损失轴上的全部失败案例。
> (B) 特征体系：112 维快照（tier 1-7+10）、47 通道 1s 原始 LOB 序列、6 维因果 regime prior、教师流 34 维、单资产 64 特征（不可计算 gap）、归一化方案与前视泄漏教训（per-day z 虚高 14×）。

# Loss & Feature System Report — multi_asset_crypto program (as of 2026-06-13)

Note: `docs/02_features/feature_catalog.md` does NOT exist locally (`docs/02_features/` dir is absent; CLAUDE.md references it aspirationally). Feature facts below come from code (`scripts/train_rawlob3.py`, `src/features/pipeline.py`) and memory files.

## (A) LOSS DESIGNS ACROSS THE PROGRAM

### A1. Current LOBNet3 / BTC-fusion recipe (exact, `scripts/train_rawlob3_fusion.py` lines 123–134)

Target normalization first: `yz = clamp((y_raw − ymed)/ymad, −6, 6)` — per-asset MAD-z with **frozen-train** med/MAD. Then 4 components, all masked by validity `vf`:

```python
magl  = (huber(q, yz) * vf).sum() / vf.sum()                                  # primary Huber, implicit weight 1.0
wsign = (|yz|.clamp(max=5)^1.5 * 1[|yz|>0.5] + 1e-3) * vf                     # tail-focal sign weight
sign  = BCE_with_logits(slog, 1[yz>0]) weighted by wsign                      # sign-BCE
magf  = (huber(ma, |yz|) * (1+|yz|) * vf).sum() / ((1+|yz|)*vf).sum()         # mag-focal on |yz|
ydem  = yz − cs_mean(yz)                                                      # B1 fix: rank on CS-DEMEANED, not raw
rankl = lambdarank_loss(rk, ydem, vb)
loss  = magl + sign_w*sign + magf_w*magf + rank_w*rankl
```

- **Default weights: `--sign_w 0.1 --rank_w 0.3 --magf_w 0.3`** (the "foundation recipe"; an earlier "fix" cutting rank→0.15/magf→0.5 caused negative vsel and was reverted — rank co-train is THE dominant lever).
- Optimizer context: AdamW lr 8e-4, wd 1e-3, bs 96, grad-clip 1.0, cosine LR with 2-epoch linear warmup; fusion gate `model.warmup` ramps `(ep−1)/3` (base converges first); gates `gf_btc`/`g_btc_self` are tanh, identity-init (zero GATE only — zeroing both gate AND projection creates a multiplicative dead-zone, the rl3btc2 basket bug).
- Empirically tuned variants: `sigma_match` add-on via `--base_sigm 0.3` (Wave-2); per-asset flow/1s gates (`--per_asset`); regime FiLM (`--use_regime_film`, HURT BTC); cross-asset basket (overfits, needs stop-gradient `zt.detach()`).

### A2. `sigma_match` (β-calibration term, `scripts/train_rawlob3_btc1.py:25`)

Per-asset: `Σ_c (σ_pred,c/σ_act,c − ρ_c)² / n`, where ρ_c = detached Pearson corr clamped [0,1]. Pins σ_pred/σ_act to ρ — the "gold standard" calibration target (σ_pred/σ_act ≈ ρ when β=1). Results: fixes β (2.15→0.95) but LOWERS Pearson, esp. BTC (0.028→0.014). The clean alternative — per-asset σ + plain conditional-mean Huber ("de-shrink") — got β 2.15→1.25 without σ_match. Earlier era (E11/E13) used a global `sigma_match` weight 0.5–1.0 as the anti-σ-collapse anchor.

### A3. cs_ranker recipes (`scripts/train_cs_ranker_seq.py`, `train_cs_ranker.py`)

- **`lambdarank_loss(s,y,valid)`** (`train_cs_ranker.py:109`): converts y to per-snapshot CS ranks (`_csrank`, fixes tiny-|Δy| weak gradient), pairwise `softplus(−(s_i−s_j))` weighted by |rank gap| over valid pairs. O(1)-scale gain.
- **`ccc_loss`** (Lin's CCC, `train_cs_ranker_seq.py:51`): `1 − 2cov/(v_p+v_y+(m_p−m_y)²)` — pushes mean→mean, var→var (β→1), corr up; structurally cannot σ-collapse. Used for the mag head (`--mag_loss ccc`).
- **`huber_demean`**: δ=1 Huber on (pred−y) masked-mean.
- **E206/E210 deliverable (split_mag balanced)**: `--split_mag` (mag head = own MLP branch so rank & mag don't fight the shared trunk) + `loss = 1.0·lambdarank + 1.0·ccc` on cs-demeaned target. Fixed the E205 calibration disaster (σ_p/σ_a≈4, sign-hit 0.50 → σ≈1, sign-hit 0.53).
- **factor_bridge multi-target (E229e deliverable)**: rank head LambdaRank on demeaned idio + idio-mag head **CCC on the DEMEANED residual** (keystone — not raw) + market head F̂ on cs-mean of raw (`--mkt_ccc`) + `beta_prior`; RAW = idio_mag + tanh(α_F)·β·F̂ is DERIVED, no own loss (non-interference keystone). `loss = rank_w·lr + huber_w·magl + f_w·fl + bprior`. Static 1.0/1.0 weights; `--uw` Kendall uncertainty weighting was slightly WORSE.
- **`--var_w` variance-floor penalty**: `relu(var_floor − √within-snapshot-var)` — anti ln2-collapse guard required with `cross_asset`.
- **Checkpoint selection**: `combo` = cs9+p9 (selecting on noisy vsel raw-P alone hurt; combo-select lifted late-OOS rawP10 to +0.0425).
- Joint raw-target recipe that broke the leak-free plateau: RevIN + `rank_w 0.5` + plain Huber (rank co-train lifted rawP10 0.007→0.031, 4.5×).

### A4. Single-asset teacher loss (REG_arch `dul_config`, 0.0646 single-model)

```
L = 0.10·pinball(τ∈{0.1,0.5,0.9})
  + 0.50·utility_rank(α=0)                                  # primary ranking
  + 0.50·dir_huber(δ=2, w_wrong=0, w_extreme=0 ⇒ plain Huber)
  + 0.10·BCE(sign_logit) with tail-focal weight clip(|y|/σ,0.3,3.0)^1.5
  + 0.30·mag_focal_huber with linear focal clip(|y|/σ,0.3,3.0)   # no ^1.5
```
Disabled (λ=0, in code): calib, pearson, beta_calib (anti #13 — train/val drift catastrophe), diff_spearman, crps, mean_zero, signcorr, unc, pearson_tail. Weights are inherited heuristics, never single-axis swept. Source: `reference_package_y600_single_asset/docs/02_LOSS_DESIGN_RATIONALE.md`, `code/training/dul_loss.py`.

### A5. What FAILED (loss axis)

- **DAQH + 5-comp REG_arch transfer to multi-asset causal raw** (`--daqh --reg_loss`, line ~685: rank + 0.10·pinball + huber_demean + 0.30·mag_focal): rawP10 +0.005 vs joint baseline +0.031 — HURT −0.026. Recipe does NOT transfer.
- **pearson_reg σ collapse**: divergent gradient ∝ 1/σ_ŷ (findings_sigma_collapse_root_cause); REG_arch itself runs lambda_pearson=0.
- **Anti-pattern invariants**: #20 dir_huber w_wrong>0 → σ collapse via PyTorch sign(0)=0; #21 utility α=1+softplus → negative bias; #13 free-Parameter beta_calib; #11 σŷ/σy<0.02 gate.
- **Rank-on-RAW target (B1 defect)**: taught the trunk market-beta ordering; fixed to CS-demeaned. BUT for BTC (idio≈0) demeaned-rank is near-noise — yet dropping it HURT BTC (0.026→0.014) while helping mid-caps: BTC-vs-midcap tradeoff.
- **Loss simplification (drop mag-focal)** regressed mid-caps (SOL 0.070→0.040) — mag-focal is load-bearing for high-vol mid-caps.
- **Pooled MLP + smooth_l1 on raw magnitude σ-collapses** (σ_pred→0); ridge's closed form sidesteps it — why DAQH/anti-collapse machinery existed and why snapshot ridge (0.044) beat the deep seq model (0.030).

## (B) FEATURE SYSTEM

### B1. Snapshot handcrafted features — FALL = 112 (`train_rawlob3.py:18`)

NPZ tiers (`src/features/pipeline.py`): 1 per-asset raw, 2 rolling multiscale (600/1800/3600s), 3 microstructure, 4 regime, 5 cross-sectional, 6 LOB-derived, 7 raw-LOB levels, 8 alpha-extended, 9 cross-asset LOB, 10 trade-flow, 11 alpha101, 12 hawkes, 13 microprice. The active 112-col build = tiers 1–7+10 (NPZ v24 with 11/12/13 = 131 cols exists). Key column facts (code-verified):
- **Tier 6 (10 feats)**: ofi_l1 (Cont-2014), ofi_l2_4, depth_imbalance_l1, spread_l1, spread_l1_zscore_60s, cumu_depth_grad (dep_3/dep_30), trade_aggression_60s, trade_vwap_slip_60s, book_event_intensity_60s (bkDel is signed-negative → abs()), midchg_signed_intensity_60s.
- **Tier 7 raw-LOB = cols 71–108** (38 ch, see B2). **Tier 10** trade-flow (VPIN col 109, Kyle-λ col 111 — kyle is intra-day CONSTANT, excluded everywhere).
- **Tier 4 one-hots cols 30:41 ZEROED** in LOBNet3 (`X[...,30:41]=0`) — within-day-quantile LEAKED; the zeroing is a correct defense, not a bug.
- **INTERACT (optional `--use_interact`, n_hand 117)**: 5 ridge-informed products [(21,64) net_flow×spread, (21,17) net_flow×vol, (63,64) obi×spread, (61,109) ofi×vpin, (67,21) aggr×net_flow] — FLAT for BTC (rl3feat).
- cs_ranker path consumes a 224-dim variant (cs-z + raw halves of the snapshot set).

### B2. Raw 1s LOB sequence — RLOF = 47 ch (`train_rawlob3.py:19-22`)

`RLO` (38) = cumu18 (9 depth bins {0.1,0.3,1,3,10,30,100,300,1000}bps × ask/bid) + detail20 (5 levels × 4 fields); `FLOW` (9) = signed order-flow cols `[1,20,21,24,61,62,63,67,70]` (excl kyle 111). Stored (T,14,47) in RAM. Micro-dynamics fixes (audit 2026-06-01): A1 `--pre_temporal` 3-layer dilated causal conv (1,2,4) at FULL 1s before the 10s patch; A4 `--use_flow` parallel CausalConv1d flow stream, gated `gflow` zero-init; A1+A4 additive (+89%, 0.022→0.0415).

### B3. Regime prior — REGIME = 6 cols `[3,17,28,29,60,65]`

bar_range / rollvol / volz / rangecompress / cs_vol / spread_z — CAUSAL (deliberately NOT the leaky 30:41 one-hots); feeds FiLM regime gating (`--use_regime_film`; HURT BTC, redistributed to DOT/LINK).

### B4. BTC teacher stream — 34-dim

`concat[h_pred(32), q50, sigma]` per timestep from frozen single-asset DualPathLOBModelV3 (118K params, fold_1), as-of causal dt-join (max_gap 600s), K multi-lag tokens as K/V in asymmetric cross-attn. On alts, h_pred ≈ q50 scalar (alts absorb only BTC DIRECTION); h_pred only helps BTC's own slice.

### B5. Single-asset 64 features (the uncloseable gap)

Path A = Linear(64→32) on 64 handcrafted from **25-level L2 + per-trade TICKS**: VPIN, true Kyle-λ on exec volume, microprice-dev, Roll spread, obi_L5/L10/L25, depth slope/concentration, +6 ridge-selected flow-interactions & trailing-1h-percentile feats. Path B = raw (600,25,4) conv, small/not load-bearing. Uncomputable from our pre-agg bar_1s (5 levels + 9 cumu bins + 1s trade counts, no per-trade side) → BTC>0.07 is a DATA-ACCESS limit. Porting their 121 precomputed feats (`preprocess_bar_xsec_v2/H600`) would REGRESS us (ridge 0.022 vs OURS 0.044).

### B6. Normalization schemes (and the leak)

- **Frozen-train robust-z** (hmed/hmad per feature) for snapshot inputs; **frozen-train per-asset MAD-z, clamp ±6** for targets. LOBNet3 hand-path has NO LayerNorm (free scale); A2 fix REMOVED cross-channel LayerNorm in LOBSpatial (it mixed units, erased book magnitude); A3 fix activated `robust_revin_seq` per-channel-over-time causal normalizer on the 47-ch seq.
- **THE LEAK**: per-day `_gz` input z (stats over the day incl FUTURE) inflated raw y600 Pearson **14×** (0.1116 vs causal 0.0080) via vol-clustering. Rule: causal only — frozen-train (`--causal_norm`), trailing/expanding, or per-window RevIN ending at t. NEVER per-day-full.
- **cs-z** (per-snapshot cross-asset z): NO time leak, clean — but scale-erasing, handicaps DL magnitude.
- **RevIN** (`--revin`, per-window adaptive causal): the single-asset ingredient; with rank_w 0.5 → rawP10 0.031. BUT RevIN+sequence destroys absolute-scale magnitude — snapshot ridge global-z NO-RevIN (0.044) beat the deep RevIN sequence model (0.030).

Key files: `/Users/haosiyu/Desktop/multi_asset_crypto/quant_research_multi_asset/scripts/{train_rawlob3.py,train_rawlob3_fusion.py,train_rawlob3_btc1.py,train_rawlob3_btc2.py,train_cs_ranker.py,train_cs_ranker_seq.py}`, `/Users/haosiyu/Desktop/multi_asset_crypto/reference_package_y600_single_asset/docs/02_LOSS_DESIGN_RATIONALE.md`, `/Users/haosiyu/Desktop/multi_asset_crypto/quant_research_multi_asset/src/features/{pipeline.py,tier6_lob.py}`.