# 07 — Phase 15 完整记录（BTC 教师→多资产融合，最近期工作的权威记录）

> 这是 Phase 15 的原始研究记录（教师复现验证→h_pred 提取→融合块→消融→泄漏对照→覆盖率排除→transformer 堆叠证伪→定论）。
> 注意：本文为 verbatim 记录，个别引用（如 y_1800 "+1.7"）早于 walk-forward 修正——以 01/04 文档为准。

---
name: findings_phase15_btc_fusion_2026-06-03
description: "Phase 15 BTC-teacher->multi-asset fusion — teacher reproduced+verified (0.0664), fusion built, partial-coverage caveat, proof run launched"
metadata: 
  node_type: memory
  type: project
  originSessionId: 857e6e8e-0af6-4637-8d69-2118c4e51c53
---

# Phase 15 — BTC-teacher → multi-asset fusion (2026-06-03)

**Thesis:** inject a FROZEN single-asset BTC teacher (rich raw 25-level L2 + per-trade) into the multi-asset
bar_1s model so alts get the well-predicted market/lead-lag component on top of their idio → alt-mean y_600
Pearson > 0.1 AND > BTC. Justified by `market_factor_probe` (bar_1s caps ~0.025, can't reconstruct BTC 0.066)
+ BTC-leads-alts lead-lag. See [[project_multi_asset_overview]], [[findings_multitarget_2026-05-31]].

## PHASE A — teacher reproduction: DONE + VERIFIED (no rebuild/retrain needed)
- **The FULL original single-asset codebase is on the server**: `/mnt/storage/private/work_hsy/quant_research/`
  (NOT the incomplete local `reference_package_y600_single_asset/`). Has src/{model,losses,features}, run_pipeline_v3.py,
  configs/v5push/, **28GB built NPZ `data/npz_v4` (991 days 2023-01-01→2025-09-30)**, and **trained checkpoints**.
- **Teacher = `experiments/v5push/singh_track_reg_arch/fold_{0,1,2}`** (DualPathLOBModelV3, 118K params, config =
  `configs/v5push/singh_alpha0_huber_track_reg_arch.json`). Checkpoint embedded `config` DROPS `use_film_multistage`
  → must merge the JSON model cfg (adds block1/block2/final FiLM) for strict load.
- **VERIFIED pooled (3-fold) `best_model`: Pearson 0.0664, Spearman 0.0695, β 1.09, σR 0.061** (ema_best 0.0593, β1.39 — worse).
  Meets gate. q50 fidelity: my recomputed forward q50 vs saved test_preds median |Δ|=2e-7, Pearson identical (0.074 vs 0.074 on fold_1 test).
- **A4 h_pred extraction DONE**: `scripts/extract_h_pred.py` (local, runs cwd=single-asset repo). model.encode(x_feat,x_raw,regime_prior)→h_pred(32);
  norm: x_feat=(X-x_mean)/where(x_std<1e-4,1,x_std), X_raw as-is, regime_prior as-is. Output per-day
  `data/btc_stream/fold1/{YYYYMMDD}.npz` = {ts_sec(unix-s), h_pred(N,32), q50(N), sigma(N)}. **619 days 2023-08-28→2025-05-18.**
  fold_1 chosen LEAK-CLEAN: its TEST window 2025-04-10→07-10 ⊇ multi-asset eval 2025-04-19→05-18 (OOS).

## PHASE B — fusion implemented
- **LOBNet3 (`scripts/train_rawlob3.py`)**: added `use_btc_fusion` flag (OFF by default, backward-compatible). Block after
  use_basket, before regime_film: alt zt=query, BTC multi-lag tokens (B,K,34)=K/V asymmetric cross-attn → gated ctx
  (gf_btc per-asset, identity-init, warmup); BTC own slice idx0 gets direct h_pred residual (g_btc_self). btc_tok is
  EXOGENOUS data → no teacher gradient; only projections train.
- **Driver `scripts/train_rawlob3_fusion.py`**: as-of causal dt-join (multi-asset dt.npy unix-s vs teacher ts_sec; JOIN on
  time not position). Configs base/q50(h_pred zeroed control)/hl0/multilag. Leak controls --btc_scramble, --btc_shift_s.
  Reports full + **covered-only** alt-mean (isolates lift from dilution).

## ⚠ CRITICAL CAVEAT — partial teacher coverage (~38%)
- **npz_v4 covers only a partial day** (UTC ~04:09 → variable end, 115-294 windows ≈ 6-15h) — a BUILD ARTIFACT.
  **Raw book data is FULL 24h (00:00→23:59 UTC, verified 3 dates).** Multi-asset day = ~24h (14:05→13:54 UTC).
  → only ~38% of multi-asset samples get a BTC token within max_gap 600s; rest = zeros (gate handles → those stay baseline).
- Partial coverage MUTES the achievable lift. So: **prove mechanism on covered-only eval first (free), then full-day
  teacher rebuild (`src/features/multi_day_pipeline.py`, raw is full-day) for ~100% coverage to chase >0.1.**

## Full-day build VALIDATED + teacher GENERALIZES (2026-06-03 pre-check)
- Full-day rebuild via `scripts/build_npz_y1800.py --input-len 600 --stride 180 --n-levels 20 --horizon 600`
  (book/trades = `/mnt/storage/share/23-25-BTCUSDT/{book_snapshot_25,trades}`, output `/tmp`, ridge+regime_prior default on).
  Produces **477 windows/day (full 24h)** vs npz_v4's partial 162-294, ~30s/day, ~80MB/day. Day boundary 03:30 UTC.
- **Reproduces npz_v4 faithfully** on overlapping windows: X_raw IDENTICAL, regime_prior IDENTICAL, X mean|diff|=0.006,
  y_600 corr 0.9955 (old vs new raw dump differ trivially). `scripts/btc_hour_generalization.py` checks per-UTC-hour.
- **Teacher GENERALIZES full-day — NO cliff** (eval window 2025-04-19→05-18, 30 days, n=14310): all UTC hours +0.03..+0.08;
  teacher-unseen evening/night +0.031 ≈ seen-morning +0.043. OVERALL q50-vs-y600 Pearson **+0.0379 on the eval window**
  (lower than 0.066 pool = this month is a lower-signal regime). Still > multi-asset's own BTC (~0.028) → fusion should lift.
- DISK: `/mnt/storage` 100% FULL (4T). Build to `/tmp` (root FS 20G free), tiny stream output. NEVER touch share.
  Full GO build must STREAM (build day→/tmp→encode→save tiny stream→delete npz; 535d×80MB=43G won't fit /tmp at once).

## RESULT (rl3fuse1, OOS 2025-04-19→05-18, 485d, seed42) — fusion VALIDATED but MODEST, plateaus ~0.045
```
                  base      q50(ctrl)  multilag
MEAN_ALT(full)   +0.0319    +0.0475    +0.0445   (q50/multilag ~tie on alts!)
covMEAN_ALT      +0.0282    +0.0439    +0.0454   (covered/morning, 41%)
covBTC           +0.0172    +0.0093    +0.0381   (BTC direct h_pred residual works: 0.017->0.038 ~ teacher eval qual)
ALT_beta         +1.73      +2.59      +2.31     (beta INFLATED — needs sigma calib for tradeability; Pearson unaffected)
```
Per-asset multilag lifts 7/9 alts (XRP .026->.056, SOL .041->.058, LINK .025->.050; ETH/DOT dip). `scripts/eval_fusion_ckpts.py` re-evals best.pt (reproduces summary exactly).

### Verdicts (decisive)
1. **Mechanism REAL + CAUSAL.** future-shift +3600s control → multilag covMEAN_ALT +0.0307 ≈ base +0.0282 (lift needs correct-time BTC; NO future leak). (scramble control confounded — it also permutes the coverage mask; future-shift is the clean one.)
2. **multilag ≈ q50 on ALTS** (+0.0454 vs +0.0439). The rich h_pred barely beats BTC's q50 SCALAR for alts — alts only absorb BTC's DIRECTION. h_pred only clearly helps BTC's OWN slice (the direct residual).
3. **Coverage is NOT the bottleneck — full build NOT worth it.** Full-day teacher rebuild validated (`/tmp/npz_fullday_eval`, 477win/day) + full-cov eval preview (cov 0.986, existing model): MEAN_ALT(full) +0.0412 — SLIGHTLY WORSE than 41%-cov +0.0445 (evening BTC untrained + lower teacher qual +0.031). So 10h full build+retrain SAVED.
4. **Plateau ~0.045, 0.1 NOT reached.** Capped by teacher-quality(0.038 this low-signal month) × alt-beta. Alts (0.045) only MARGINALLY > BTC (0.038) — not "significantly higher". Goal `alt-mean>0.1` unmet on this regime.

## PHASE 15-C (deep-idio transformer + fusion stack) — NEGATIVE, conv multilag stays best
User chose "deep-idio + fusion stack". Added E215c-proven `TemporalTransformer` (plain 2-layer self-attn, replaces dilated-conv post-patch temporal) to LOBNet3 (`--temporal transformer`), trained base+multilag on the SAME rl3fuse1 split.
```
                  base-tf   multilag-tf  | conv: base / multilag
MEAN_ALT(full)   +0.0329   +0.0278       | +0.0319 / +0.0445
covMEAN_ALT      +0.0276   +0.0297       | +0.0282 / +0.0454
ALT_beta          2.25      1.43         |  1.73   /  2.31
```
- **Transformer base OOS ≈ conv base (0.033≈0.032)** — its vsel edge (+0.030 vs conv +0.019) was IN-SAMPLE OVERFIT, did NOT carry OOS.
- **Fusion on transformer REGRESSED**: multilag-tf 0.028 < base-tf 0.033 (gates went NEGATIVE; transformer trunk + per-snapshot fusion injection interact badly), and ≪ conv multilag 0.045.
- Only positive: transformer β 1.43 < conv 2.31 (better calib) but Pearson worse + β doesn't affect Pearson.
- VERDICT: E215c transformer edge (idio-target, cs-z inputs, 386d) does NOT transfer to raw-target+fusion+LOBNet3. **conv multilag (rl3fuse1, alt-mean 0.045) is THE Phase-15 deliverable.** `--temporal transformer` flag kept (off by default).

## PHASE 15 OVERALL CONCLUSION
y_600 RAW alt-mean is INFO-BOUND ~0.045 with BTC fusion (validated+causal, alts>BTC, conv multilag). Deeper extraction (transformer) does NOT help. **0.1 on raw y_600 is unreachable** (raw ~70% unpredictable market; best market forecast = teacher ~0.038-0.066). Genuine tradeable signal remains the market-neutral IDIO (E210/E215c FIL/DOT/ETC 0.07-0.08) + y_1800 deliverable (Sharpe +1.7 — **[已被后续 8 折 walk-forward 修正为有利窗口 artifact，见 04 §4 / 01 交易层表]**). [[findings_signal_bound_ceiling_2026-05-30]] [[findings_deliverable_y1800_backtest_2026-05-31]]

### NEXT-LEVER candidates (for user direction)
- Higher-signal regime: teacher 0.038 here vs 0.066 pooled → fusion may give 0.06-0.07 on avg regimes (needs 2nd window: fold_2 h_pred + retrain).
- Stronger per-asset IDIO (orthogonal to the market signal fusion provides): E157 deep per-asset got idio 0.040 / FIL 0.084 — stacking deep-idio + BTC-market-fusion is the untested combo.
- β calibration (sigma_match) for tradeability (won't raise Pearson).
Artifacts: teacher streams `data/btc_stream/fold1/` (619d partial) + `/root/btc_stream_fullday/fold1` (eval full); ckpts `experiments/diagnostic_rl3fuse1_{base,q50,multilag}/best.pt`.
