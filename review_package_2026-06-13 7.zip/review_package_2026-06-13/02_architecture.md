# 02 — 架构设计细节（代码核对版）

> 本文档由代码逐行核对生成（2026-06-13），覆盖三个模型家族：
> (A) LOBNet3（多资产 raw 主力，含 Phase-15 BTCFusion 块）；(B) 单资产 BTC 教师 DualPathLOBModelV3（已复现 0.0664）；(C) train_cs_ranker_seq 家族（idio 深模型，E142→E215c 谱系）。
> 末尾的「identity-init / gating discipline」一节是全项目的模块接入纪律，审查时请重点核对。
> 对应代码见 `code/` 目录；行号以包内副本为准。§(B) 教师模型的源码不在包内，可在服务器 `/mnt/storage/private/work_hsy/quant_research/src/model/` 核对。

# Architecture Designs (code-grounded, read 2026-06-13)

Sources: `/Users/haosiyu/Desktop/multi_asset_crypto/quant_research_multi_asset/scripts/train_rawlob3.py` (347 ln), `scripts/train_rawlob3_fusion.py` (231 ln), `scripts/train_cs_ranker_seq.py` (729 ln), `/Users/haosiyu/Desktop/multi_asset_crypto/reference_package_y600_single_asset/code/model/dual_path_model_v3.py` (+ submodules `gdcn.py`, `raw_lob_encoder.py`, `film_gate.py`, `direction_aware_quantile_head.py`, `backbones/conformer_backbone.py`), plus the 5 memory files. Memories are 9-14 days old; code is current local source.

---

## (A) LOBNet3 — `scripts/train_rawlob3.py` (multi-asset, in-RAM full 1s LOB) + BTCFusion (`train_rawlob3_fusion.py`)

### Data layout / constants
- `S=14` assets, `FALL=112` handcrafted snapshot features, `H=600` (y_600), NPZ = `data/npz_v23_400d_mmap/{day}/X.npy (T,14,F), y_600.npy, dt.npy`.
- `RLO = cols[71:89]+[89:109]` = 38 raw-LOB cols = CUMU 18 (9 depth bins × 2 sides) + DETAIL 20 (5 levels × 4 fields).
- `FLOW = [1,20,21,24,61,62,63,67,70]` = 9 signed order-flow cols (kyle col 111 excluded — intra-day constant). `RLOF = RLO+FLOW` = **47 seq channels** stored per day as `(T,14,47)` in RAM (`preload()`; tier4 cols 30:41 zeroed = leak defense).
- `REGIME = [3,17,28,29,60,65]` (bar_range/rollvol/volz/rangecompress/cs_vol/spread_z, causal) for regime FiLM. `INTERACT` = 5 ridge-informed flow products (`--use_interact`, appended to snapshot).
- Sample = `(day, t, snapshot X[t] (14,112), y(14), valid(14))`; lob window sliced at batch time `rawlob[d][t-win+1 : t+1 : sub]` → `(L=win/sub, 14, 47)`, default `win=600, sub=1` (600×1s).

### Forward dataflow (`LOBNet3.forward(hand (B,S,112), lobseq (B,L,S,47), btc_tok (B,K,34))`)
1. **Handcrafted snapshot trunk**: frozen-TRAIN robust-z `hz = clamp((hand−hmed)/hmad, ±8)` (buffers from train-sample median/MAD) → `self.hand` = `Linear(112,d)→GELU→Dropout(0.2)→Linear(d,d)→GELU` — **NO LayerNorm** (free scale, anti β=2 magnitude collapse). `hb (B*S, d)`, d=96 default. Base `z = hb`.
2. **Raw-LOB normalization (A2/A3 fix)**: `robust_revin_seq` — per-(sample,channel) median/MAD **over the time axis L** (causal window), clamp ±8. Applied to the full 47-ch sequence reshaped `(B*S, L, 47)`. Cross-channel LayerNorm explicitly REMOVED (it mixed delta_bps with logsz and erased book magnitude).
3. **LOBSpatial** (per-timestep, book 38 ch only): DETAIL reshaped `(M,5,4)→(M,4 fields,5 levels)` → `Conv1d(4,16,2)→GELU→Conv1d(16,32,2)→GELU` over levels; CUMU `(M,9,2)→(M,2 sides,9 bins)` → `Conv1d(2,8,2)→GELU→Conv1d(8,16,2)→GELU` over depth bins; each **level-attention-pooled** (`softmax(Linear(C,1))` over level axis — learned level importance vs mean) → concat 48 → `Linear(48,d_raw=32)→GELU`. Output `e (B*S, L, 32)`.
4. **Flow stream (A4, `--use_flow`)**: flow ch 38:47 → `CausalConv1d(9,d_flow=24,k=1)` then 4 residual dilated-causal convs `k=3, dil (1,2,4,8)` → `Linear(24,32)`; injected `e = e + pa(tanh(gflow)) * flowproj(...)` where `gflow` is **zero-init** (identity at start) and **per-asset** (`gdim=S` when `--per_asset` — BTC can shut flow off; flow empirically hurts BTC).
5. **Fuse**: `f = Linear(d+d_raw → d)(concat[e, hb broadcast over L])` — handcrafted ANCHORS the LOB per-timestep (not a side-channel).
6. **pre_temporal (A1, `--pre_temporal`)**: 3 residual dilated-causal convs `k=3, dil (1,2,4)` at FULL 1s **before** patching; gated `f = f + pa(tanh(g1s))*(out − f)`, `g1s` zero-init per-asset. Fixes "patch-before-temporal" defect (10s mean was the first time-axis op).
7. **Patch** `_patch(f, L)`: 1s → 10s tokens (`patch=10`, K=L/10). Variants all **identity-init to mean** for clean ablation: `mean` (default); `stats` = `Linear(4d,d)` on [mean,std,last,last−first] with W=[I,0,0,0]; `conv` = depthwise `Conv1d(d,d,10,stride 10)` init 1/patch.
8. **Temporal over patch tokens**: default `conv` = 6 residual dilated-causal convs `k=3, dils (1,2,4,8,16,32)` each `GroupNorm(8,d)(GELU(c(h))+h)`; OR `--temporal transformer` = `TemporalTransformer` (E215c) — `n_tlayers=2` pre-norm blocks {LN→MHSA(4 heads)+res, LN→FFN(2d)+res}, full (non-causal) attention is leak-free because the window ends at t.
9. **Attention pool + gated merge**: `w=softmax(qpool(h))` over K tokens; `z = hb + tanh(al)*Dropout(0.1)(Σ w·h)` — `al` scalar **zero-init** → model starts handcrafted-only.
10. **Basket block (`--use_basket`, STEP3)**: `zt=z.reshape(B,S,d)`; `ztd=zt.detach()` (**stop-grad: basket reads market context but cannot pull other assets' training** — protects mid-caps); per-asset key score `bq(ztd)` broadcast to `(B,S,S)`, diagonal masked `-inf` (strictly exogenous); `ctx = Dropout(0.2)(bproj(softmax·ztd))` with `bproj` **NORMAL-init** (dead-zone fix: zero-init the GATE only, never also the projection — double-zero made ∂gb=∂bproj=0 forever); `gate = tanh(gb[S], zero-init) * strong_mask * warmup`; `z = zt + gate*ctx`. `strong_mask` pins FIL/SOL/ETH/ETC/LINK/DOT shut (only BTC/XRP/DOG/TRX open). `warmup` buffer = `(ep−1)/3` during train, 1.0 at eval. Var-floor penalty `_varpen = relu(0.3 − ztd.std(1)).mean()` exposed for the loss.
11. **BTCFusion block (Phase 15, `--use_btc_fusion`)** — placed after basket, before regime FiLM:
    - `btc_tok (B,K,34)` = K teacher snapshots, each `[h_pred(32), q50, sigma]` from the FROZEN single-asset teacher — **exogenous data, no teacher gradient; only projections train**.
    - `bt = Linear(34,d)(btc_tok)`; asymmetric cross-attn: **alt `zt` = Query**, BTC-lag tokens = K/V (`btc_q/btc_k/btc_v`, scaled dot, softmax over K lags — each alt picks WHICH lag of BTC leads it); `ctx = Dropout(0.2)(attn @ v)` `(B,S,d)`.
    - Alt gate: `gate = tanh(gf_btc[S], zero-init) * btc_alt_mask([0,1,...,1] — BTC idx0 excluded) * warmup`.
    - BTC own slice: `bself = Linear(d,d)(bt[:,0])` (lag-0 direct h_pred residual), gated `gs = tanh(g_btc_self scalar, zero-init)*warmup`, applied via `btc_self_mask=[1,0,...,0]`.
    - `z = zt + gate*ctx + btc_self_mask*(gs*bself)`. Warmup ramp `(ep−1)/3` set by the fusion driver; `fill_(1.0)` at eval.
12. **Regime FiLM (`--use_regime_film`)**: `FiLMGate(NREG=6, d)` — trunk `Linear(6,d)→GELU→Drop→Linear(d,d)→GELU→Drop` (deeper: regimes are combinations), γ/β projections **zero-init** → `(1+γ)z+β` = identity at start. Conditions on the 6 causal REGIME columns of `hz`.
13. **Per-asset FiLM**: `pfilm = Embedding(S, 2d)` zero-init; `z = z*(1+γ_a)+β_a`.
14. **DAQH head**: `sign`/`mag` MLPs `Linear(d,d/2)→GELU→Linear(d/2,1)`, final layers **zero-init**; `q50 = tanh(sign_logit) * softplus(mag)` (anti σ-collapse: sign and magnitude decoupled).
15. **sigma_scale (C4 fix)**: `q50 = q50 * sigma_scale[aid]` — learnable output-gain β-knob applied **AFTER the head** (was before FiLM where it was mathematically redundant, absorbed into FiLM γ); per-asset when `--per_asset` (heterogeneous calibration), init ones.
16. **Rank head**: `rank = Linear(d,1)(z)`. Returns `(q50, sign_logit, mag, rank)` each `(B,S)`.

### Loss / training (foundation recipe)
- Target: per-asset MAD-z of raw y_600, clamp ±6 (`yz`). Eval de-normalizes `P*ymad+ymed`.
- `loss = huber(q50,yz) + 0.1*sign_BCE + 0.3*mag_focal + 0.3*lambdarank` where: sign BCE weighted `|yz|^1.5·1{|yz|>0.5}+1e-3` (tail focal); mag-focal = Huber(softplus-mag, |yz|) weighted `(1+|yz|)`; **rank is on `ydem = yz − cs_mean(yz)` (B1 fix: rank CS-demeaned idio, not market-laden raw)**.
- AdamW lr 8e-4, wd 1e-3, bs 96, 14 ep, cosine (2-ep linear warmup), grad-clip 1.0, seed 42, early-stop patience 4 on vselP (last-20-train-days selection slice, stride 600).
- Eval per-asset over `UNIV10`: Pearson, β=cov/var, σ-ratio, sign-hit.

### Fusion driver specifics (`train_rawlob3_fusion.py`)
- Teacher stream: `data/btc_stream/fold{f}/{day}.npz` = {ts_sec, h_pred(N,32), q50, sigma} → globally time-sorted index.
- `attach_btc`: **as-of CAUSAL dt-join** — sample abs time = `dt.npy[t]`; `searchsorted` → K most-recent teacher snapshots with ts ≤ abs_sec, reject if gap > `max_gap_s=600` (leave zeros; gate handles missing). JOIN on time, never position.
- Teacher tokens normalized by **frozen TRAIN-valid-rows robust-z** (per-channel median/MAD), zeros preserved.
- Configs (single-axis): `base` (no fusion) / `q50` (fusion on, h_pred 32 ch zeroed — scalar control) / `hl0` (K=1) / `multilag` (K=4 ≈ lags 0/180/360/540s). Leak controls: `--btc_scramble` (permute alignment), `--btc_shift_s` (future-peek; +3600s collapsed to base = causality verified). Reports full + **covered-only** alt-mean (same coverage rows for all configs).
- Result (memory): multilag conv = the Phase-15 deliverable, alt-mean 0.0445 full / 0.0454 covered, BTC 0.038 via direct residual; transformer trunk + fusion regressed (gates went negative); plateau ~0.045.

---

## (B) Single-asset teacher — `DualPathLOBModelV3` (REG_arch config; 118K params, pooled P=0.0664)

File: `reference_package_y600_single_asset/code/model/dual_path_model_v3.py`. Production teacher config = `singh_alpha0_huber_track_reg_arch.json`: `backbone_kind="conformer"` (2 blocks), `use_film_multistage=True` (checkpoint's embedded config DROPS this flag — must merge the JSON for strict load), `use_direction_aware_head=True` (DAQH), d_model=32, d_raw=16, n_features=64 handcrafted, n_levels=25, d_prior=6.

### encode() pipeline (the `h_pred(32)` extracted to the btc_stream)
1. **RevIN** (`use_revin`): per-instance (window) mean/std normalization of `x_feat (B,L,64)`, learnable affine; input-only (target stationary, never denormalized).
2. **Path A (handcrafted)**: `MaskNet` (serial mask blocks, noise suppression, DLP-KDD 2021) → `GDCN` (CIKM 2023 gated cross: `x_{l+1} = x0 ⊙ W(x_l) ⊙ sigmoid(W_g(x_l)) + x_l`, n_layers=2, operates in full 64-dim feature space BEFORE projection — preserves crossing on raw features) → `input_proj Linear(64→32)` → `h_craft (B,L,32)`.
3. **Path B (raw LOB)**: `RawLOBEncoder` on `x_raw (B,L,25,4)` [4 fields = bid_delta, bid_logamt, ask_delta, ask_logamt]: per-timestep `(B·L,4,25)` → `Conv1d(4,16,1)` channel-mix → `Conv1d(16,16,3)→GELU→Conv1d(16,32,3)→GELU` spatial over levels → `AttentionPool1D` over levels (learned, down-weights far levels) → `Linear(32→d_raw=16)→GELU→Drop` → `h_raw (B,L,16)`. **Small, not load-bearing** (~10K/118K params; no Path-B ablation exists).
4. **Fusion**: concat → `Linear(32+16→32)` (default `fusion_kind="concat"`).
5. **ConformerBackbone** (2 blocks, d=32, heads=2, conv kernel=15): each block = `x + 0.5·FFN1` → causal-masked MHSA (+res) → ConformerConvModule (LN → 1×1 conv to 2d → GLU → **depthwise causal conv k=15** → BatchNorm → SiLU → 1×1 conv → drop, +res) → `x + 0.5·FFN2` → LN. Macaron sandwich.
6. **FiLM multistage (Track REG_arch)**: with `use_film_multistage` the model manually iterates conformer blocks and applies `FiLMGate(d_prior=6, d=32)` **after block 1, after block 2, and after pooling** ("final" gate; replaces PPNetGate, which is skipped to avoid double gating). FiLMGate: trunk `Linear(6→32)→GELU→Drop` (optional deeper), γ/β heads **zero-init** → `γ=1+0, β=0` identity at start; broadcasts over T for sequence stages. Docs credit Conformer+FiLM ≈ +10%.
7. **Pool**: last-token slice `h[:, -1, :]` (or MultiResolutionPool if enabled; off in teacher) → final FiLM → `h_pred (B,32)`. This is exactly what `model.encode(x_feat, x_raw, regime_prior)` returns (everything except head + output_scale) — the API `extract_h_pred.py` uses; norm at extraction: `x_feat=(X−x_mean)/where(x_std<1e-4,1,x_std)`, X_raw as-is, regime_prior as-is.
8. **forward()** = `encode()` → `quantile_heads[horizon_idx]` → optional `output_scale` α multiply → optional regime additive bias. Returns dict {quantiles (B,3)=[q10,q50,q90], point_pred=q50, sign_logit, ...}.

### DAQH head (DirectionAwareQuantileHead)
- `sign_logit = MLP_s(h)`, `magnitude = softplus(MLP_m(h))`, `q50 = tanh(sign_logit) × magnitude`; `q10 = q50 − (softplus(MLP_lo)+min_delta)`, `q90 = q50 + (softplus(MLP_hi)+min_delta)` → structurally monotonic. sign & magnitude final layers **zero-init** → q50 starts at 0, no direction bias; BCE updates sign only, Huber/pinball update magnitude → no shared 0-attractor (avoids anti-pattern #20).
- Teacher loss recipe = V5 α=0 + plain Huber (loss simplicity, not the multi-asset 5-component, is part of the 0.0646 ladder: loss → FiLM → ensemble(+3%) → 700d → raw-TICK feed).
- Legacy/optional paths (off in teacher): PatchEmbedding+CausalPatchAttention, CrossAssetAttention (n_symbols>1), PPNetGate, TV-FiLM, xattn regime gates, MoE/Mamba/iTransformer/etc. backbones — a large pluggable `backbone_kind` zoo.

---

## (C) `train_cs_ranker_seq.py` family — temporal CS-ranker (E147→E157/E210/E215c lineage)

### Inputs (`load_seq`)
- `Xsnap (N,S,2F)` = [raw 112 | per-snapshot cs-z 112] concat; `Xseq (N,L,S,F[+38])` = downsampled lookback (default L=10, step=60s) of cs-z features, `--raw_lob_seq` appends the 38 **raw scale-preserved** LOB cols → Fseq=150; optional `Xfine (N,fine_L,S,38)` per-second LOB stream. Target: CS-demeaned idio (default), `--raw_target` raw y, or `--idio_target` β-neutral `y_h_idio`. Norm modes: cs-z (default), `--raw_norm` global-z (+per-asset MAD-z target), `--causal_norm` frozen TRAIN gstats (the honest deployable fix to the per-day look-ahead leak), `--revin` per-window RevIN. seqcache npz keyed by full config hash.

### Model `CSRankerSeq(Fsnap, Fseq, d=256, layers=4, ...)`
- **Snapshot backbone**: feature-dropout (`feat_drop=0.3`, GBDT feature_fraction analog) → `layers×[Linear→LayerNorm→GELU→Dropout]` → `h (B,S,d)` (the E144 two-head MLP).
- **PerAssetFiLM** (`--per_asset_film`, E157 driver of cs-spear): `Embedding(14,16)` → γ/β `Linear(16,d)` both **zero-init** (γ=1+0, β=0 identity) → per-asset specialization on the shared channel-independent trunk.
- Optional identity-init-gated residual modules, all `h + tanh(α)*Norm(module)` with α **zero-init**: `RegimeMoE` (softmax-gated E expert MLPs, state-dependent), `FMInteraction` (low-rank FM 2nd-order crosses `0.5((xV)²−x²V²)`), `CrossCSZ` (low-rank DCN-V2 cross on the cs-z half only, U zero-init), `LOBCNN` (per-frame DeepLOB ladder conv: DETAIL (5lvl×4ch) + CUMU (9depth×2ch) convs over level axis), `LOBTemporalCNN` (Conv2d over **time×level** grid of the seq's last 38 raw-LOB dims; optional attn-pool over the grid), `lobfine` (2nd DeepLOB on the per-second fine stream), `LeadLag` (asymmetric: all assets Query BTC/ETH as K/V only), `CrossAssetAttn` (full within-snapshot S-token self-attn; guarded by loss-side variance-floor `var_w·relu(var_floor − std_within_snapshot(rank))` — the ln2-collapse fix; optional per-asset gate).
- **Temporal encoder** (per-asset: `(B·S, L, Fseq)` — no cross-asset mixing → no ln2-collapse), selected by flag, fused as `h + tanh(alpha_t)*LayerNorm(Linear(d_t,d)(tt))`, `alpha_t` zero-init (starts = snapshot E144):
  - default **GRU** last-state (d_t=64) or `--temporal_attnpool` attention-pool over states;
  - `--temporal_conformer` `ConformerTemporal` (macaron FFN + MHSA + depthwise CAUSAL conv k=9 + FFN + attention-pool) — wins on magnitude, overfits rank;
  - `--temporal_transformer` `TransformerTemporal` (Linear-in + learned pos + plain pre-norm self-attn blocks + attn-pool; pool=False mode for masked-patch SSL; `--init_transformer/--init_gru` warm-starts) — **E215c best arch** (cs 0.0526 / P9 0.0440 scratch);
  - `--temporal_hybrid` `HybridTemporal` (depthwise causal conv on the near-end frames + patched transformer over the full window, fused);
  - `--temporal_fast_only` restricts the sequence to 55 fast channels (FASTSEQ_IDX) for fine-resolution runs.
- **Heads**: `rank_head = Linear(d,1)` on `rh` (with `--head_routing`: `rh = h + tanh(alpha_route)*Linear(cs-z half)` — isolates rank input from mag/market gradients); **`--split_mag`**: magnitude head = own MLP branch `Linear(d,d/2)→GELU→Drop→Linear(d/2,1)` so rank & mag don't fight on the shared trunk (the E206 calibration fix: σ_p/σ_a 4→~1); `--mag_film` per-asset FiLM on the mag branch only; `--daqh` swaps in a DAQHHead (tanh·softplus q50 + q10/q90, zero-init) with `--reg_loss` enabling the REG_arch 5-component recipe (lambdarank + 0.10 pinball + huber + 0.30 mag-focal + 0.10 tail-focal-BCE); `--factor_bridge`: `raw = idio_mag + tanh(alpha_F)·β_asset·F̂` where F̂ = market head on (attn-)pooled assets (optionally on raw features `--mkt_raw`), **alpha_F zero-init**, idio-mag supervised on the DEMEANED residual (recovered additively — non-interference verified), F̂ on the cross-asset mean (MSE or CCC), optional `(β−1)²` prior, optional Kendall uncertainty weighting (`--uw`); aux short-horizon rank heads (`--aux_horizons`), dual-horizon (`--rank_horizon` short idio rank + long raw mag).
- **Loss (default)**: `rank_w·lambdarank_loss(rank, Yd, valid) + huber_w·mag` with `--mag_loss ccc` = Lin's CCC (pushes β→1, σ_pred→σ_act) — E206/E210 deliverable config = GRU + split_mag + balanced rank_w 1.0 / huber_w 1.0 CCC + cross_asset + V-REx. `--vrex_beta` = V-REx variance penalty over k chronological blocks (ramped over ~3·warmup epochs — identity-init delay guard). AdamW, cosine LR with warmup, grad-clip 1.0, checkpoint selection `--select cs|combo` (combo = cs+P9; `--inner_val` for leak-free selection).
- **Eval**: per-snapshot cs Spearman over `UNIV10` (≥5 valid, prints `cs_spear_10`/`rawP10`/`idio_magP10` + per-asset Pearson AGG over W1-W4 or walk-forward OOS window), idio-mag recovered from factor_bridge, F̂-vs-market-factor correlation.

### Identity-init / gating discipline (consistent across all three codebases)
1. Every add-on module enters as a **gated residual** `x + tanh(α)·f(x)` (or FiLM `(1+γ)x+β`) with the GATE (α, γ/β projections, DAQH final layers, patch projections) **zero-init** → model = proven baseline at step 0, learns the deviation; single-axis ablatable.
2. **Zero the gate ONLY, never also the projection** — double-zero creates a multiplicative dead-zone (∂gate=∂proj=0 forever; the rl3btc2 basket bug). Projection gets normal init.
3. Cross-asset/fusion blocks add **warmup ramps** (`(ep−1)/3`, 1.0 at eval) so the base converges first, plus **stop-grad/exogenous context** (basket `ztd=detach()`; btc_tok is data) so the injection cannot pull the shared trunk, plus **masks** (strong_mask, btc_alt_mask/btc_self_mask) restricting which asset slices the gate can touch.
4. Anti ln2-collapse guards for anything cross-asset: asymmetric Q-vs-K/V structure (each asset's own query → within-snapshot variance preserved) and/or an explicit within-snapshot variance-floor loss term.
5. Anti σ-collapse for magnitude: sign×magnitude decoupled DAQH (zero-init), no trunk LayerNorm on free-scale paths, per-asset MAD-z targets, sigma_scale as a post-head per-asset gain knob.