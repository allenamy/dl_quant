# 多资产加密 y_600 预测项目 — 合作者审查包

> **生成日期：** 2026-06-13 | **范围：** ~230 个实验、15 个 Phase 的完整结论 + 架构/损失/特征设计 + 核心代码
> **目的：** 供合作者独立审查方法学、复核结论、挑战下一步方向。

## 一页结论（TL;DR）

1. **y_600 信号已被充分提取，触及信息上限**：idio cs_spear ~0.055–0.059（GBDT 0.0587 为界）；raw alt 均值 ~0.045（含 BTC 教师融合）。三重独立证据：模型类收敛（GBDT≈DL≈ridge 同输入）、外部信号注入封顶、加深无效。
2. **单资产 BTC 教师（0.0664, β1.09）已复现并逐位验证**，其冻结 h_pred 经因果对齐注入多资产模型后 **alt 均值 0.032→0.045、alts>BTC、future-shift 对照通过**（无泄漏）——但 alt 只吸收 BTC 的"方向"（标量 q50 对照 ≈ 32 维 h_pred），融合封顶 ~0.045，**raw y_600 冲 0.1 不可达**。
3. **最强真实信号**：快 horizon（y_120 cs 0.090，8/8 折正）+ 市场中性 idio 中盘股（FIL/DOT/ETC **0.07–0.08 已校准**（E210：σ≈1、sign-hit 0.53）；E215c 架构至 FIL 0.091 但 σ 偏高 1.3–2.7 未校准）。
4. **⚠ 交易层修正**：曾报告的 y_1800 "+1.7 @2bp" 被 8 折 walk-forward 证明是有利窗口 artifact。当前最诚实的最佳净收益：**方向性策略 @2bp Sharpe +0.91（6/8 折正，双对照通过）**；市场中性 conviction-gate @2bp ≈ breakeven。**mission（Sharpe≥1.5@2bp）尚未达成，gap 在执行/校准层而非信号层。**
5. **下一步最优**：① 执行/校准层收尾（最便宜攻 mission）；② y_120 快 α 净收益回测决断；③ 新数据采购（tick L2/funding/OI——唯一上限突破口，决策项）；④ P8 ensemble 解锁（决策项）。

## 包结构与阅读顺序

| 文件 | 内容 | 建议读者 |
|---|---|---|
| `01_executive_summary.md` | 进展/最佳指标/里程碑/核心世界观结论 | **所有人先读** |
| `02_architecture.md` | 三个模型家族逐行核对的架构细节 + 模块接入纪律 | 建模审查 |
| `03_loss_and_features.md` | 损失配方（含失败案例）+ 特征体系 + 归一化与泄漏教训 | 建模审查 |
| `04_metrics_catalog.md` | 全部 headline 指标逐条（配置/窗口/出处）+ 数字可信度 caveats | 复核数字 |
| `05_ruled_out.md` | ~230 实验的完整证伪清单（防重复试错；含 caveat：部分 kill 是目标特异） | 挑战结论 |
| `06_next_levers.md` | 下一步方向按 EV 分层排序（证据/成本/kill-risk） | 方向讨论 |
| `07_phase15_full_record.md` | 最近期工作（BTC 教师融合）的原始研究记录 | 深度复核 |
| `code/README_code.md` | **每个脚本 → 思路/实验版本/核心改动的映射** | 代码审查入口 |
| `code/*.py` | 19 个核心脚本（raw 线 6 + idio 线 2 + 基准诊断回测 9 + 依赖 2） | 代码审查 |

## 溯源说明

- 04/05/06 文档的 Source 列引用的 `findings_*.md` 是项目内部研究记录（不在包内）；**包内唯一的原始记录是 07（Phase 15）**，其余文档是经核对的汇总。需要任何一份原始记录可以单独提供。
- 04 文档引用的部分证据脚本（如 `bt_csranker_seq.py`、`universe_audit.py`、`diag_eval_integrity.py`）不在 `code/`（只收录了 19 个核心脚本）；同样可按需提供。

## 数据与环境（包内不含数据/checkpoint）

- 原始数据：服务器 `/mnt/storage/share/bar_data/bar_1s/`（1s bar，14 USDT 永续，**只读**）+ `/mnt/storage/share/23-25-BTCUSDT/`（BTC 25 档 L2 + 逐笔，教师数据源）。
- 加工数据/模型：`/mnt/storage/private/work_hsy/quant_research_multi_asset/`（NPZ mmap、教师流 `data/btc_stream/`、`experiments/*/best.pt`）。
- 单资产教师代码库：`/mnt/storage/private/work_hsy/quant_research/`（完整可运行，含已训 checkpoint）。
- 环境：Python 3.13 + torch 2.7.1+cu126（conda env `hsy_v5push`），RTX 3090。

## 给审查者的核心问题（欢迎挑战）

1. **信息上限结论是否站得住？** 证据链：04 文档 §3（模型类收敛）+ 07 文档（教师融合封顶）+ 05 文档（架构加深证伪）。最薄弱处：单种子（P8）下 <0.005 差异不可分辨。
2. **泄漏防护是否完备？** 03 文档 B6（归一化 14× 教训）、04 文档尾部 caveats、`extract_h_pred.py --validate` 与 future-shift 对照。还有没有我们没想到的泄漏面？
3. **"alt 只吸收 BTC 方向"（q50≈h_pred 对照）是否有其他解释？** 见 07 文档 verdicts §2——这是融合封顶的核心机制判断。
4. **执行层方向（conviction-gate/方向性）的统计强度**：8 折、单种子，Sharpe CI ±1–1.5；z=1.0 是在测试集上调的（OOS-honest 版未跑）。这是下一步 Tier-1 的关键缺口。
5. **快 α（y_120 cs 0.090）能否变现**：715 次/天再平衡 × 2bp 的费用结构 vs 2× 信号；这个 fork 从未回测。
6. **两个决策项**：是否采购多资产 tick L2/funding/OI 数据？是否解锁 P8（GBDT+DL ensemble，预期 +0.005–0.010）？

## 已知约束（审查时请尊重）

- **P8**：单模型单种子(42)纪律，禁 ensemble/SWA/多种子平均——除非明确解锁。
- **共享数据只读**：`/mnt/storage/share` 下原始数据绝不可改动/删除。
- 服务器磁盘曾 100% 满：新构建一律流式/写 `/tmp` 或 root FS。
