# 06 — 下一步方向（按期望价值分层排序，附证据与成本）

> Tier 1 = 高 EV 低成本（执行/校准层、horizon 配置、新数据采购决策）；Tier 2 = 真实但有界/需解锁（P8 ensemble、教师后续、SSL 大赌注、regime 方法）；Tier 3 = 收尾项。末尾列出 4 个已启动未读结果（先收割零成本）。

# Next-Step / Big-Lever Candidates from Project Memory (compiled 2026-06-13)

Sources: all 63 files in `/Users/haosiyu/.claude/projects/-Users-haosiyu-Desktop-multi-asset-crypto/memory/`. Ranked by expected value (EV = headroom × probability-of-working ÷ cost), with reasoning. Context anchors: y_600 idio cs_spear info-ceiling ~0.05-0.059 (GBDT≈DL≈ridge); causal raw y_600 plateau ~0.03-0.045; mission Sharpe ≥1.5 @2bp NOT robustly met after walk-forward correction (the "+1.7 @2bp" was a favorable-2025-window artifact); fast-horizon IC 2× at y_120.

---

## TIER 1 — highest EV

### 1. Execution/strategy layer: conviction-gate + directional reframe + honest calibration (the cheapest path to the mission metric)
- **Claim:** Turnover-reduction + conviction-z tail gating + directional (non-neutral) books is the real path to clearing 2bp — not more IC. (`findings_npz_foundation_audit_2026-05-31`)
- **Evidence:** Conviction-gate z≈1.0 lifted 8-fold walk-forward y_1800 from @2bp −4.02 (naive) to **−0.08 breakeven (5/8 folds positive)**, @1bp +1.22. Directional reframe (per-asset conv-z tail, vol-weighted unit-gross): **@2bp +0.91 (6/8 folds)**, beats market-neutral L/S +0.11 by 8×, passes BOTH controls (sign-flip −3.79, momentum −1.33). Hold/band turnover cuts were "the ONLY real lever"; mag-tilt and tail-K hurt.
- **Untested:** (a) OOS-honest z (z=1.0 was tuned-on-test); (b) the missing calibration piece σ_pred = ρ·σ_act (σ_match target_ratio≈ρ on IDIO target) — neither model is properly calibrated (CCC inflates σ 1.3-2.7×, plain Huber-on-raw σ-collapsed β=50); (c) full-CS turnover-band sweep (was running, unreported); (d) directional objective re-validation of arch conclusions (gated-to-0/fine-LOB-dead were idio-rank-specific).
- **Cost:** LOW — backtest scripts exist (`wf_backtest.py`, `bt_directional.py`), per-fold models trained; days not weeks, mostly CPU.
- **Kill-risks documented:** high per-fold variance (f0 +3.7 / f5 −4.9); net exposure 0.27 = directional/market risk not neutrality; maker fills are "fantasy" per adversarial critic (adverse selection); single-seed Sharpe CI ±1-1.5.
- **EV reasoning:** Only candidate that directly attacks the mission gap (signal real, economics marginal) with positive controls already passed and near-zero cost. Promising-not-banked status is purely calibration+z honesty — finishable.

### 2. Horizon allocation: y_120/y_300 fast-alpha backtest + y_1800/y_3600 tradeable suite (dual optima)
- **Claim:** Alpha is FAST (IC peaks ~2min); two optima exist — y_120/300 for IC/DL-edge (cs 0.090/0.063, DL>GBDT, edge GROWS at fast horizon), y_1800/y_3600 for net PnL (σ_idio∝√h clears cost wall). y_600 is the dead zone. (`findings_ic_term_structure`, `findings_horizon_economics`, `findings_longhorizon_tradeable`)
- **Evidence:** Flagship DL at y_120 cs_spear **0.0902** (all 4 windows 0.082-0.096) = >1.5× the y_600 GBDT ceiling; walk-forward 8/8 folds positive at every horizon (y_120 ridge 0.0664). y_3600@180min-hold most cost-robust (+1.98 @2bp, +1.20 @3bp on favorable window; walk-forward y_3600 @2bp −0.41 = closest of all).
- **Untested:** THE open fork — does a y_120/y_300 model (2× IC) net-beat y_1800 after hold/cost sweep, or is fast alpha sub-economic? Never backtested. Also: shared-encoder multi-horizon (option C); y_300 as parallel deliverable horizon (needs user sign-off — changes deliverable definition); universe re-decision at the tradeable horizon.
- **Cost:** LOW-MED — models for y_120/300 already trained (e_fast120/300), backtest harness exists; ~days.
- **Kill-risks:** y_120 = 715 rebal/day × 2bp = 1430bp/day cost (mechanically brutal); dual-horizon rank-head co-training already DISCARDED at two-point (Δ collapsed +0.0034→+0.0010 = noise); IC-flat claim was earlier conflated — verify with the clean term structure.
- **EV reasoning:** 2× proven signal headroom sitting unmonetized; one cheap backtest resolves the fork either way.

### 3. NEW raw-microstructure data feed (full-depth/tick L2, funding, OI, liquidations) — the only credible ceiling-breaker
- **Claim:** Only NEW INFORMATION (not tuning) reaches cs 0.07+ / per-asset raw >0.07; the binding constraint is data access, not modeling. (`findings_signal_bound_ceiling`, `findings_new_info_audit`, `findings_rawlob3_audit_fixes`)
- **Evidence:** GBDT 0.0587 ≈ DL 0.0550 on same input = information-bound; single-asset BTC 0.0646 is REAL (scores 0.089 on our exact window vs our 0.028) and its gap is decomposed: 64 engineered features from **25-level L2 + per-trade ticks** (true Kyle-λ, VPIN, microprice-dev, Roll spread, depth slope, obi_L5/L25) — UNCOMPUTABLE from pre-agg bar_1s. BTC is feature-bound even in-sample (IS 0.044, lowest of 10 assets).
- **Untested:** Acquiring a multi-asset tick/L2 feed (Tardis exists but BTC-ONLY: `23-25-BTCUSDT`); funding/OI/liquidations integration (ZERO files on /mnt/storage/share — never had them).
- **Cost:** HIGH — external data acquisition (purchase/ops), then a full feature+NPZ program; weeks+ and disk (storage was 100% full at last check).
- **Kill-risks documented:** signed-book-event gate KILLED (sub-10s decay, doesn't survive to y_600); multi-level OFI redundant (+0.0064 < gate); slope_imbalance was a suppressor artifact (false positive); finer-resolution decisively dead at both horizons (E228, fine_lob ±0.0006); new features carry the same regime-drift risk; REG_arch's 0.067 also never had funding/OI (so those three may add less than tick/L2).
- **EV reasoning:** Highest absolute headroom (the only path past the ceiling per three independent decisive audits) but highest cost and outside pure-research control. Rank below the two cheap levers; rank first if the user can procure data.

---

## TIER 2 — medium EV, real but bounded or gated

### 4. GBDT+DL ensemble (P8-gated — needs explicit user unlock)
- **Claim:** Ensembling GBDT (0.0587, tree crossings) with DL (0.055, temporal/LOB info trees can't use) is "the obvious win," +0.005-0.010 cs_spear. (`findings_arch_critique`, `findings_magnitude_pivot` big-lever ranking #2)
- **Evidence:** The two model classes extract partially disjoint signal (DL closed the gap via temporal/LOB; GBDT wins per-snapshot crossing — DCN-V2/FM/GDCN all failed to replicate trees in-net). Single-asset 0.0667 itself was a **5-way ensemble** (single model 0.0646).
- **Untested:** Everything — P8 explicitly forbids it. Memory notes "precondition now met" (single-model genuinely maxxed across ~230 experiments).
- **Cost:** LOW — both models trained; blending + eval is days.
- **Kill-risks:** P8 is a standing user constraint (needs explicit release); gains may be measurement-noise scale (+0.005 ≈ single-seed SE); doesn't break the info ceiling, only approaches it.
- **EV reasoning:** Near-certain modest gain, trivially cheap, but blocked on policy. Raise to user as a decision item.

### 5. BTC-teacher fusion: stack into deliverables + 2nd regime window + β calibration
- **Claim:** Frozen single-asset BTC teacher (h_pred/q50) injected into multi-asset lifts alt raw y_600 0.032→0.045 (validated, causal); three named follow-ons remain. (`findings_phase15_btc_fusion` NEXT-LEVER section)
- **Evidence:** Future-shift control passed (lift needs correct-time BTC); 7/9 alts lifted (XRP .026→.056, SOL .041→.058); coverage proven NOT the bottleneck (full-cov preview 0.0412 ≤ 0.0445, saved a 10h build); teacher reproduced at 0.0664 pooled.
- **Untested:** (a) **deep-idio (E157-class, conv not transformer) + BTC-market-fusion stack** — the orthogonal combo (idio strength + market signal) explicitly flagged untested; (b) higher-signal regime window — teacher was 0.038 on the low-signal eval month vs 0.066 pooled → fusion may give 0.06-0.07 on average regimes (needs fold_2 h_pred + retrain); (c) σ_match/β calibration of fusion output (ALT_beta 2.31 inflated — blocks tradeability, not Pearson); (d) fusion at y_1800 horizon (teacher trained y_600; never injected into the tradeable-horizon ranker).
- **Cost:** MED — h_pred extraction pipeline exists; fold_2 extraction + retrain ≈ days; deep-idio stack is a wiring job on existing code.
- **Kill-risks documented:** plateaus ~0.045 (capped by teacher-quality × alt-beta); multilag≈q50 on alts (alts absorb only BTC DIRECTION — rich h_pred adds nothing for them); transformer-trunk fusion REGRESSED (0.028, gates negative); 0.1 declared unreachable on raw y_600; raw-y_600 directional signal partially cancels in market-neutral L/S.
- **EV reasoning:** Mechanism is validated and causal — rare in this project — but headroom is explicitly bounded (~0.045→maybe 0.06 in better regimes). The untested deep-idio+fusion combo and y_1800 injection are the genuinely new cells.

### 6. SSL streaming pretrain on full 1430d raw bars (transformer masked-patch)
- **Claim:** The only way to use 3.5× more history (raw streams at 0.4s/day, no disk block); SSL on distant 2022-23 regimes can help representations even though supervised training on them hurts; transformer is the right pretrain substrate. (`research_quant_scaling_laws`, `findings_magnitude_pivot` SSL sections)
- **Evidence FOR:** scaling-law lit (D∝N^0.8; our 1.9M params + 1.7B obs underparameterized 30-100×); GRU-SSL same-data weak-positive exactly where predicted (thin-idio BTC 0.016→0.024, XRP 0.028→0.035); masked-patch infra built and smoke-validated (`ssl_pretrain.py`, `--init_transformer`); E215c transformer = best DL arch scratch (cs 0.0526).
- **Evidence AGAINST (the same memories):** E215b transformer + same-data SSL **HURT** (cs 0.0351, −0.0135); E212 GRU same-data ~flat (+0.0014); supervised more-data HURTS (E224 570d: 0.0526→0.0475); E214 (SSL on 570d → fine-tune) launched but **no banked result in memory** — status unknown, check server. 15-agent verdict listed SSL-init as "two-point-dead."
- **Untested:** The actual lever — masked-patch pretrain on the FULL 1430d raw stream (never run; only same-data and 570d-NPZ variants attempted). Streaming branch (raw bars as new input, not cs-z) untested.
- **Cost:** HIGH — ~100 GPU-h pretrain (E51 estimate) + streaming loader build; multi-week.
- **Kill-risks:** masked-recon objective biases init AWAY from ranking (measured); 2022-23 regimes are the documented drift poison; scaling-law papers measure MSE/MAPE not return-Pearson; transfer surface previously a CS-blind 332KB tower; P8 means a noisy single-seed readout on a 100-GPU-h bet.
- **EV reasoning:** The biggest untested model-side swing, but every cheap proxy ran flat-to-negative. Only worth it as a deliberate "big bet" with a pre-registered gate, after Tier-1 items.

### 7. Regime-drift methods: group-DRO (DL), test-time adaptation, regime routing
- **Claim:** Drift is adaptable-not-predictable; needs worst-regime robustness or online adaptation, not data reweighting. Unsolved through-line (2024-12 OOS rawP 0.014 vs 0.043; 18.5-47% feature-IC sign-flips OOS; idio alpha ceiling is HIGHER OOS than in-train — the learned map is regime-STALE, alpha exists). (`findings_regime_drift_methods`)
- **Evidence:** V-REx β=1-1.25 = mild genuine regularizer (+0.005-0.006 per-asset P, zero cs cost — kept as default); offline group-DRO ridge gate passed (worst window +0.0016); recency-weighting decisively HURTS (E164); idio/demean reframe was the one big regime win.
- **Untested:** group-DRO on the DL model (only ridge analogue run); test-time adaptation (RevIN-stats refresh / light-head online update / HRT stateful EMA); change-point/HMM regime detection→routing (distinct from the dead capacity-MoE); IRM/DANN/CORAL invariance; the "stale-map fix" named in the big-lever ranking (#3).
- **Cost:** MED — methods are loss/eval-loop changes on existing trainers; 1-2 weeks.
- **Kill-risks:** every regime lever so far died or was mild (RegimeMoE two-point-dead E186/E184; regime FiLM hurt BTC; FiLM gates modest; V-REx gain at single-seed noise edge); drift detector inverted cross-pair (0.81→0.306) — regimes can't be predicted, capping routing approaches; honest expectation per the workflow: "modest worst-window insurance," not a ceiling break.
- **EV reasoning:** Attacks the largest honest loss (hard-regime OOS folds) with grounded diagnosis, but the empirical track record of regime levers is poor. Medium.

---

## TIER 3 — lower EV / supporting / bounded

### 8. β-calibration paths (CCC-on-residual, per-asset σ de-shrink, post-hoc 1/β, σ_match≈ρ)
- **Claim:** Calibration (β≈1, σ_pred/σ_act≈ρ, bias≈0) is mandatory for sizing/tradeability; multiple validated recipes exist; it never raises Pearson. (`findings_magnitude_pivot`, `findings_multitarget`, `findings_rawlob3_audit_fixes`, `findings_e157`)
- **Evidence:** CCC on demeaned residual + split_mag FIXED calibration (E206/E210: σ_p/a 0.6-1.1, sign-hit 0.51-0.53, bias~0) — the keystone, banked; per-asset σ + clean Huber de-shrunk β 2.15→1.25 (user thesis validated, rl3btc1); σ_match→β 0.95 but cost Pearson; post-hoc ×(1/β) trivial (β stable per E157 diag); transformer heads remain σ-inflated 1.3-2.7; plain-Huber-on-raw σ-collapses (β=50) — why anti-collapse machinery exists.
- **Untested:** σ_match with target_ratio=ρ (the "gold standard" σ_pred=ρσ_act) on the idio target — the named missing piece for conviction-gating; calibrating the fusion model (β 2.31); calibrating transformer mag heads (rescale or σ-control term).
- **Cost:** LOW — loss-flag changes + `predcalib_eval.py` exists.
- **Kill-risks:** known Pearson-vs-β trade-off (σ_match repeatedly cost P: 0.028→0.024 BTC, mid-caps down); anti-pattern #13 (free β-calib parameter bias).
- **EV reasoning:** Necessary enabler for lever #1, near-zero standalone alpha. Do it as part of #1, not separately.

### 9. Universe/breadth: capped at 14 — remaining play is universe re-optimization at the tradeable horizon
- **Claim:** Breadth-via-more-assets is DEAD: raw HDF5 verified to contain only 19 symbols = 14 USDT + 5 USDC dupes (corr 0.9993); no 50-60-perp expansion possible on this feed. Remaining lever: pick the right 10 at the right horizon. (`findings_magnitude_pivot` big-lever check, `findings_universe_audit`)
- **Evidence:** ETH was #2 most predictable (idio 0.063, 4/4 stable) and wrongly dropped — now fixed (canonical UNIV10); BTC worst (idio 0.002) kept as market-anchor only; BCH 0.028/LTC 0.026 (dropped) vs SOL 0.019 (2/4)/DOG 0.021 (kept).
- **Untested:** re-deciding SOL/DOG vs BCH/LTC at y_1800/y_3600 with gross + correlation-aware Sharpe (`universe_audit.py` hardcodes y_600 — needs horizon param); mid-cap-focused portfolio (FIL/SOL/ETC/ETH/DOT at 0.04-0.067 raw, β≈1 — Fork B of the rawlob3 verdict, backtest never run).
- **Cost:** LOW — one script param + reruns.
- **Kill-risks:** y_600 leave-one-out was cost-wall-confounded; small-N universe means selection noise; breadth gain bounded by 14.
- **EV reasoning:** Cheap hygiene with small bounded upside; folds into #2's backtest.

### 10. Residual architecture/feature levers (mostly exhausted — listed for completeness with their status)
All carry the documented meta-risk: ~230 experiments show capacity/crossing/finer-res/MoE/recency/lead-lag/FactorBridge dead or gated-to-0; the biggest documented failure mode is **misallocation onto tuning levers bounded above by the ceiling** (`findings_signal_bound_ceiling`).
- **GBDT-oracle feature distillation** (top tree split-pairs → 5-10 engineered cols): named HIGH-EV in the 8-agent critique, **never executed**. Cost LOW. Kill-risk: DCN-V2-done-right was two-point negative — the interaction signal may simply not transfer.
- **HRT-RNN stateful TBPTT (Track R)**: designed (architecture-variants), faithful port E138/E139 tasks still pending, never completed. Cost MED. Kill-risk: superseded by transformer findings; implicit TTA value overlaps lever #7.
- **rl3btc4 stop-grad basket** (decoupled cross-asset basket for BTC): launched, result not in memory — check server. Basket lifted BTC IS +0.023, OOS +0.014 but regressed mid-caps. Kill-risk: if it caps ~0.03 OOS, BTC raw ceiling confirmed.
- **Conformer/700d-span/trailing-percentile feats for LOBNet3**: explicitly tagged "untested-but-low-EV" (BTC is feature-bound in-sample; 700d NPZ disk-blocked + drift).
- **Multi-horizon aux heads (`--aux_horizons`) walk-forward**: wired, 6/8 folds run at last note, final aux-vs-baseline comparison PENDING. Cheap to finish.
- **SAM / iTransformer / ListNet co-primary / MoE-ALF** (2026-05-22 research): superseded — MoE and crossing since died empirically; SAM never tried (2× compute, low prior now).
- **Per-asset snapshot ridge productionization** (`snapshot_models.py`, raw y_600 champion 0.044, ETC 0.067): deliverable-grade, simpler than the deep model; push of mid-caps >0.07 needs new causal features (Roll spread, true Kyle-λ, bar10m momentum) — expected marginal (+0.005) and partly blocked on lever #3's data.

---

## Cross-cutting cautions (apply to whichever lever is picked)
- Mandatory eval protocol: UNIV10 incl ETH, BOTH idio+raw targets, layered metrics (rank+magnitude+calibration), two-point (140d AND 386d) + per-window sign; single-seed deltas <~0.005 are noise (P8: seed 42, no ensemble without user release of P8).
- tier4 regime cols 30-40 carry a within-day-quantile leak in v23 NPZ unless rebuilt with `--fold-stats` or dropped (`--drop_tier4`) — taints any regime-conditioning experiment.
- Input normalization must be causal (per-day z = 14× Pearson inflation, `findings_norm_lookahead_leak`).
- Disk: /mnt/storage was 100% full at Phase 15; streaming designs only; never touch /mnt/storage/share.
- Two launched-but-unreported results to check on the server before re-running anything: E214 (570d SSL transformer fine-tune), rl3btc4 (stop-grad basket), full-CS turnover-band sweep, multi-horizon-aux WF comparison.