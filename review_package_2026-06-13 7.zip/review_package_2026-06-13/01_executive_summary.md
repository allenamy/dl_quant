# 01 — 执行摘要：当前进展、最佳指标、里程碑、核心结论

> **Doc Meta:** 2026-06-13 | 作者: Siyu Hao + Claude | 供合作者审查
> 项目：Binance 永续合约多资产中高频深度学习预测（主目标 y_600 = 10 分钟对数收益；14 USDT 资产，1s bar 数据）

## 一、项目当前位置（一段话）

经过 ~230 个实验 + 15 个 Phase，项目完成了从"盲目调参"到"精确知道信号在哪里、上限在哪里、瓶颈是什么"的转变。三类**独立**证据一致确认：**y_600 的可提取信号已经被充分提取，剩余差距是信息层面而非建模层面**——(1) GBDT≈DL≈ridge 在同一输入上收敛（cs_spear 0.0587/0.0550/0.0415 量级）；(2) 注入单资产 BTC 教师（外部更丰富数据训练的 0.0664 模型）后 alt 均值封顶 ~0.045；(3) 加深/换 transformer 不增益。最强的真实信号在**快 horizon**（y_120 cs_spear 0.090，8/8 折为正）和**市场中性 idio 的中盘股**（FIL/DOT/ETC 每资产 Pearson 0.07–0.08 已校准（E210）；E215c 至 FIL 0.091 但 σ 偏高未校准）。最大的未完成项是**执行/校准层**：信号是真的，但 2bp 成本墙下的净收益还差最后一步（最佳诚实结果：方向性策略 @2bp Sharpe +0.91，6/8 折为正）。

## 二、最佳指标全景

全部为 **OOS、单种子 42、UNIV10（含 ETH）**。完整目录见 `04_metrics_catalog.md`。

### 信号层

| 维度 | 最佳值 | 模型/配置 | 备注 |
|---|---|---|---|
| 单资产 BTC 教师（复现验证） | **Pearson 0.0664**，β 1.09 | REG_arch 单模型，3 折 pooled | 从服务器现成 artifact 验证；q50 重算逐位一致（median \|Δ\|=2e-7） |
| raw y_600 alt 均值（BTC 融合） | **0.045**（base 0.032） | LOBNet3 conv + 冻结教师融合 | 因果验证通过（future-shift 对照塌回 base）；7/9 alt 提升；alts > BTC |
| idio 每资产 Pearson | AGG **0.044**；FIL **0.091** / DOT 0.075 / ETC 0.070 | E215c transformer（386d） | FIL 超过单资产 BTC 0.067；E157 诚实 clean-OOS 0.037 |
| cs_spear（y_600 排序） | DL **0.0541–0.0550**；GBDT **0.0587**（=信息上限） | E155/E174 vs LightGBM | 三类模型同输入收敛 = 信息界 |
| 快 horizon | **y_120 cs 0.0902**（4 窗口 0.082–0.096）；y_300 0.063 | flagship d320 L6 transformer | 8 折 walk-forward 全正（y_120 ridge 0.0664, 8/8） |
| 快照 ridge（raw y_600 冠军） | 均值 **0.044**；ETC 0.067 | 每资产 ~100 参数 ridge | "快照 > 深度序列(0.030)"；我们的特征比单资产 121 特征强 2× |

### 校准层（可交易性要求 β≈1）

| 指标 | 最佳值 | 配置 |
|---|---|---|
| σ_pred/σ_act | **0.60–1.04**（全资产） | E210：GRU + split_mag + 平衡 CCC |
| sign-hit | **0.51–0.53**（每资产 >0.5），bias ~1e-4 | 同上 |
| raw 校准 | SOL β 1.05、FIL β 1.07 | RevIN + rank0.5 + Huber |

### 交易层（⚠ 含重要修正）

| 配置 | 净 Sharpe | 状态 |
|---|---|---|
| ~~y_1800 "+1.7 @2bp"~~ | — | **已被 8 折 walk-forward 修正为有利窗口 artifact**（8 折最佳 naive @2bp −0.52） |
| **方向性策略（conviction-z 1.0）** | **@2bp +0.91**（6/8 折正） | 通过 sign-flip(−3.79)/momentum(−1.33) 双对照；当前最诚实的最佳交易结果 |
| conviction-gate 市场中性 | @2bp **−0.08 breakeven**（5/8 正）、@1bp +1.22 | 换手率 0.27，首个 ~2bp 打平的配置 |
| y_3600 hold180 | WF @2bp −0.41 | 最接近成本墙的长 horizon |

**结论：mission（组合 Sharpe ≥1.5 @2bp）在严格 walk-forward 口径下尚未达成；gap 在执行/校准层，不在信号层。**

## 三、里程碑时间线

1. **E29/E52/E56**（5 月中）：输入形状对齐（lookback=600 + stride 180 + patch 5）+ PerAssetFiLM + tier4 去泄漏 → 多资产首次稳定，BTC ep 峰值触 0.067
2. **E136 重构**（5/29）：**市场中性 idio 目标** — CS-IC 提升 1.6–1.9×，全项目范式转折
3. **GBDT 范式突破 + E142–E155**：LambdaRank DL ranker 0.024→0.0541，逼近 GBDT 0.0587
4. **E157/E210/E215c**（5/29–30）：深 per-asset 提取使 idio 翻倍（FIL 0.084–0.091）并完成**校准**（σ≈1、sign-hit 0.53）
5. **归一化前视泄漏修复**（6/1）：per-day z 虚高 14×（0.11→0.008），全项目换因果归一化，所有旧 raw 数字重校
6. **信息上限三重定论**（5/30）：GBDT≈DL≈ridge / 数据加量更差(E224) / 新特征 gate 全杀 → "提特征不调参"
7. **Horizon 经济学**（5/31）：α 在 ~2min 达峰；y_600 是经济死区；恒等式 gross/trade = IC × σ_idio
8. **Phase 15 BTC 教师融合**（6 月初，最近期）：教师 0.0664 复现+逐位验证 → 冻结 h_pred 因果注入 → **alts 0.032→0.045（因果对照通过）**；全天覆盖率被便宜排除（省 10h 重建）；transformer 堆叠证伪 → **raw y_600 信息界 ~0.045 定论，0.1 不可达**

## 四、核心世界观结论（审查重点）

1. **y_600 信息界**：idio cs_spear 上限 ~0.055–0.059（GBDT 0.0587 为参照）；raw alt 均值上限 ~0.045（含 BTC 教师融合）。突破只能靠**新信息**（tick 级 L2 / funding / OI），不是建模。
2. **raw = β·market + idio 分解是设计主轴**：market 占方差 65–81% 且基本不可预测（市场因子 probe 上限 ~0.02）；可预测部分集中在 idio 的中盘股。BTC 教师的价值 = 把 market 分量做到 0.038–0.066，alt 只吸收其**方向**（q50 标量 ≈ 32 维 h_pred）。
3. **目标函数决定架构胜负**：Conformer/transformer 在低 SNR 的 cs-rank 上过拟合、在高 SNR 的 magnitude 上赢；E215c 的 transformer 优势不迁移到 raw+fusion（Phase 15-C 证伪）。架构结论都是目标特异的。
4. **α 是快的**：IC 期限结构 y_120 0.080–0.090 → y_600 0.042 → y_3600 0.010–0.015；但费用结构反向 → 双最优（y_120 信号端 / y_1800+3600 净收益端），y_600 居中最差。
5. **泄漏防护是数字可信的前提**：per-day 归一化 14× 虚高、tier4 当日分位泄漏、W1 选择 +0.011 虚高、教师 future-shift 对照——全部已建制度化防护（见 03/04 文档 caveats）。
6. **BTC 弱是结构性的而非 bug**：BTC idio-share 仅 0.34–0.52（市场代理），在市场中性目标上理应弱；BTC>0.07 需要 25 档 L2+逐笔数据（数据获取问题）。

## 五、下一步方向（摘要，详见 06 文档）

- **Tier 1（本周可做）**：① 执行层收尾（OOS-honest conviction-z + σ_match(ρ) 校准 + 换手率带宽）= 攻 mission 最便宜路径；② horizon 配置决断（y_120/300 快 α 净收益回测 vs y_1800/3600）；③ **新数据采购决策**（多资产 tick L2 / funding / OI——唯一的上限突破口，需要拍板）。
- **Tier 2**：④ GBDT+DL ensemble（被 P8 纪律锁定，需明确解锁）；⑤ BTC 教师三个未测格子（conv 版 deep-idio 组合 / fold_2 正常 regime 复验 / 注入 y_1800）；⑥ SSL 1430d 流式预训练（大赌注，需预注册 gate）；⑦ group-DRO/TTA regime 方法。
- **先收割**：4 个已启动未读结果在服务器上（E214 SSL 微调、rl3btc4、换手率带宽扫描、multi-horizon aux WF）。
